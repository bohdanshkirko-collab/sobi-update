'use client';

import { useEffect } from 'react';
import HomeView from './components/v2/HomeView';
import { SobiLoader } from './components/v2/shared';
import { useTranslations } from './hooks/useTranslations';
import { generateStructuredData } from './utils/seo';

export default function ClientPage() {
  const { translations, locale, setLocale, loading, t } = useTranslations();

  useEffect(() => {
    const handleHashScroll = () => {
      const hash = window.location.hash;
      if (hash) {
        const sectionId = hash.substring(1);
        setTimeout(() => {
          const element = document.getElementById(sectionId);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
          }
        }, 100);
      }
    };

    if (!loading) {
      handleHashScroll();
    }

    window.addEventListener('hashchange', handleHashScroll);

    return () => window.removeEventListener('hashchange', handleHashScroll);
  }, [loading]);

  // Generate structured data based on current locale
  const structuredData = generateStructuredData(locale);

  if (loading) {
    return <SobiLoader />;
  }

  return (
    <>
      {/* Dynamic structured data based on user's language */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(structuredData),
        }}
      />
      <HomeView t={t} translations={translations} locale={locale} setLocale={setLocale} />
    </>
  );
}
