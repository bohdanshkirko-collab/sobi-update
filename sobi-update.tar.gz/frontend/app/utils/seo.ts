import { Metadata } from 'next';
import { SITE_URL } from './site-url';

type SupportedLocale = 'uk' | 'ru' | 'pl' | 'en';

// Get SEO translations
export function getSEOTranslations() {
  return {
    uk: {
      title: "SOBI - Партнер Uber і Bolt | Робота водієм таксі в Труймясті",
      description: "Працюй водієм Uber та Bolt в Гданську, Гдині, Сопоті. Надаємо авто, допомагаємо з документами, обслуговування 24/7. Понад 6 років підтримуємо водіїв таксі в Польщі.",
      keywords: "SOBI, водій Uber, водій Bolt, робота таксі Польща, таксі Гданськ, Uber Gdańsk, Bolt Trójmiasto, оренда авто для таксі, партнер Uber Bolt, робота водієм Польща, таксі Труймясто",
      locale: "uk_UA" as const,
      lang: "uk" as const
    },
    ru: {
      title: "SOBI - Партнер Uber и Bolt | Работа водителем такси в Трёхградье",
      description: "Работай водителем Uber и Bolt в Гданьске, Гдыне, Сопоте. Предоставляем авто, помогаем с документами, обслуживание 24/7. Более 6 лет поддерживаем водителей такси в Польше.",
      keywords: "SOBI, водитель Uber, водитель Bolt, работа такси Польша, такси Гданьск, Uber Gdańsk, Bolt Trójmiasto, аренда авто для такси, партнер Uber Bolt, работа водителем Польша, такси Трёхградье",
      locale: "ru_RU" as const,
      lang: "ru" as const
    },
    pl: {
      title: "SOBI - Partner Uber i Bolt | Praca taxi w Trójmieście",
      description: "Praca taxi Uber Bolt w Gdańsku, Gdyni, Sopocie. Wynajem aut, pomoc z dokumentami, serwis 24/7. Partner Uber i Bolt od ponad 6 lat. Dołącz do kierowców taxi w Trójmieście.",
      keywords: "SOBI, praca taxi, taxi Uber, Uber Bolt, praca kierowca Gdańsk, kierowca taxi Trójmiasto, partner Uber Bolt, wynajem auta taxi, praca taxi Gdańsk, Uber Gdańsk, Bolt Gdynia, taxi Sopot, kierowca Uber Bolt",
      locale: "pl_PL" as const,
      lang: "pl" as const
    },
    en: {
      title: "SOBI - Uber & Bolt Partner | Taxi Driver Job in Tri-City Poland",
      description: "Work as Uber and Bolt driver in Gdansk, Gdynia, Sopot. We provide cars, help with documents, 24/7 service. Over 6 years supporting taxi drivers in Poland.",
      keywords: "SOBI, Uber driver Poland, Bolt driver, taxi job Poland, taxi Gdansk, Uber Gdańsk, Bolt Trójmiasto, taxi car rental, Uber Bolt partner, driver job Poland, Tri-City taxi",
      locale: "en_US" as const,
      lang: "en" as const
    }
  };
}


// Generate structured data for each language
export function generateStructuredData(locale: SupportedLocale) {
  const seoData = getSEOTranslations()[locale];
  const baseUrl = SITE_URL;

  const serviceNames = {
    carRental: {
      pl: "Wynajem samochodów dla kierowców Uber i Bolt",
      en: "Car rental for Uber and Bolt drivers",
      uk: "Оренда авто для водіїв Uber та Bolt",
      ru: "Аренда авто для водителей Uber и Bolt"
    },
    carService: {
      pl: "Serwis i obsługa techniczna pojazdów taxi",
      en: "Taxi vehicle service and maintenance",
      uk: "Сервіс та технічне обслуговування таксі",
      ru: "Сервис и техническое обслуживание такси"
    },
    documents: {
      pl: "Pomoc z licencją taxi i dokumentami",
      en: "Taxi license and documentation assistance",
      uk: "Допомога з ліцензією таксі та документами",
      ru: "Помощь с лицензией такси и документами"
    },
    support: {
      pl: "Wsparcie 24/7 dla kierowców taxi",
      en: "24/7 support for taxi drivers",
      uk: "Підтримка водіїв таксі 24/7",
      ru: "Поддержка водителей такси 24/7"
    },
    insurance: {
      pl: "Ubezpieczenie dla kierowców Uber Bolt",
      en: "Insurance for Uber Bolt drivers",
      uk: "Страхування для водіїв Uber Bolt",
      ru: "Страхование для водителей Uber Bolt"
    },
    workshop: {
      pl: "Warsztat samochodowy dla floty taxi",
      en: "Car workshop for taxi fleet",
      uk: "Автомайстерня для таксопарку",
      ru: "Автомастерская для таксопарка"
    }
  };
  
  return {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "LocalBusiness",
        "name": "SOBI - Partner Uber i Bolt",
        "alternateName": "SOBI Partner",
        "url": baseUrl,
        "logo": `${baseUrl}/favicon.svg`,
        "image": `${baseUrl}/og-image.jpg`,
        "description": seoData.description,
        "telephone": "+48791798673",
        "email": "sobi.biuro@gmail.com",
        "address": {
          "@type": "PostalAddress",
          "addressCountry": "PL",
          "addressRegion": "Województwo pomorskie",
          "addressLocality": "Gdańsk"
        },
        "geo": {
          "@type": "GeoCoordinates",
          "latitude": "54.352025",
          "longitude": "18.646638"
        },
        "areaServed": [
          {
            "@type": "City",
            "name": "Gdańsk"
          },
          {
            "@type": "City",
            "name": "Gdynia"
          },
          {
            "@type": "City",
            "name": "Sopot"
          }
        ],
        "openingHours": "Mo-Su 00:00-24:00",
        "priceRange": "$$",
        "paymentAccepted": "Cash, Credit Card, Bank Transfer",
        "currenciesAccepted": "PLN",
        "availableLanguage": ["Polish", "Ukrainian", "Russian", "English"],
        "hasOfferCatalog": {
          "@type": "OfferCatalog",
          "name": locale === 'pl' ? "Usługi dla kierowców taxi" : locale === 'en' ? "Taxi driver services" : locale === 'uk' ? "Послуги для водіїв таксі" : "Услуги для водителей такси",
          "itemListElement": [
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": serviceNames.carRental[locale],
                "description": locale === 'pl' ? "Nowoczesna flota samochodów dostępna od zaraz" : "Modern car fleet available immediately"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": serviceNames.carService[locale],
                "description": locale === 'pl' ? "Pełny serwis techniczny i naprawy" : "Full technical service and repairs"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": serviceNames.documents[locale],
                "description": locale === 'pl' ? "Kompleksowa pomoc w uzyskaniu licencji taxi" : "Comprehensive help in obtaining taxi license"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": serviceNames.support[locale],
                "description": locale === 'pl' ? "Wsparcie techniczne i operacyjne całą dobę" : "Technical and operational support around the clock"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": serviceNames.insurance[locale],
                "description": locale === 'pl' ? "Korzystne pakiety ubezpieczeń" : "Favorable insurance packages"
              }
            },
            {
              "@type": "Offer",
              "itemOffered": {
                "@type": "Service",
                "name": serviceNames.workshop[locale],
                "description": locale === 'pl' ? "Własny warsztat z szybką obsługą" : "Own workshop with fast service"
              }
            }
          ]
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.8",
          "reviewCount": "250"
        }
      },
      {
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": locale === 'pl' ? "Jak zostać kierowcą Uber lub Bolt w Gdańsku?" : "How to become an Uber or Bolt driver in Gdansk?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": locale === 'pl' ? "Skontaktuj się z SOBI - pomagamy z licencją taxi, zapewniamy samochód i pełne wsparcie. Zadzwoń: +48791798673" : "Contact SOBI - we help with taxi license, provide a car and full support. Call: +48791798673"
            }
          },
          {
            "@type": "Question",
            "name": locale === 'pl' ? "Czy mogę wynająć samochód do pracy w Uber?" : "Can I rent a car to work in Uber?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": locale === 'pl' ? "Tak, SOBI oferuje wynajem samochodów specjalnie przygotowanych do pracy w Uber i Bolt. Flota nowoczesnych aut z pełnym serwisem." : "Yes, SOBI offers car rental specially prepared for work in Uber and Bolt. Fleet of modern cars with full service."
            }
          }
        ]
      }
    ]
  };
}