'use client';

import CalcView from '../components/v2/CalcView';
import { SobiLoader } from '../components/v2/shared';
import { useTranslations } from '../hooks/useTranslations';

export default function IncomeCalculator() {
  const { translations, locale, setLocale, loading, t } = useTranslations();

  if (loading) {
    return <SobiLoader />;
  }

  return <CalcView t={t} translations={translations} locale={locale} setLocale={setLocale} />;
}
