import { MetadataRoute } from 'next'
import { SITE_URL } from './utils/site-url'

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = SITE_URL

  return [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'weekly',
      priority: 1,
    },
    {
      url: `${baseUrl}/income-calculator`,
      lastModified: new Date(),
      changeFrequency: 'weekly', 
      priority: 1,
    },
    {
      url: `${baseUrl}/wlasne-auto`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: 0.9,
    },
    {
      url: `${baseUrl}/privacy-policy`,
      lastModified: new Date(),
      changeFrequency: 'monthly', 
      priority: 0,
    },
  ]
}