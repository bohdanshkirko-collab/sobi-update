import { useState } from 'react';

interface FormData {
  name: string;
  phone: string;
  email: string;
  city: string;
  comment: string;
}

interface FormErrors {
  phone: string;
  city: string;
}

interface ContactFormOptions {
  /**
   * Builds the text saved in the "comment" field (e.g. to add extra answers
   * from the own-car form). Receives the typed comment.
   */
  composeComment?: (comment: string) => string;
  /** Hide the "thank you" state automatically after this many ms (0 = never). */
  autoHideMs?: number;
  /** Extra validation of fields kept outside this hook. Return false to stop sending. */
  validate?: () => boolean;
  /** Called after the request was saved. */
  onSuccess?: () => void;
}

const EMPTY: FormData = {
  name: '',
  phone: '',
  email: '',
  city: '',
  comment: '',
};

export const useContactForm = (
  t: (key: string) => string,
  locale: string,
  options: ContactFormOptions = {}
) => {
  const { composeComment, autoHideMs = 3000, validate, onSuccess } = options;
  const [formData, setFormData] = useState<FormData>(EMPTY);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submitError, setSubmitError] = useState('');
  const [formErrors, setFormErrors] = useState<FormErrors>({
    phone: '',
    city: '',
  });

  // Phone validation function
  const validatePhone = (phone: string): string => {
    // Remove all non-digits for validation
    const cleanPhone = phone.replace(/\D/g, '');

    // Polish phone number validation
    if (!cleanPhone) {
      return t('phone_error_required');
    }

    // Polish phone numbers: +48 followed by 9 digits
    if (cleanPhone.length === 11 && cleanPhone.startsWith('48')) {
      return ''; // Valid
    }

    // Or just 9 digits (local format)
    if (cleanPhone.length === 9) {
      return ''; // Valid
    }

    return t('phone_error_format');
  };

  const setField = (name: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (name === 'city' && value) {
      setFormErrors((prev) => ({ ...prev, city: '' }));
    }
    if (name === 'phone') {
      setFormErrors((prev) => ({ ...prev, phone: validatePhone(value) }));
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setField(name as keyof FormData, value);
  };

  const resetSubmitted = () => setIsSubmitted(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError('');

    // Validate before submission
    const phoneError = validatePhone(formData.phone);
    const cityError = formData.city ? '' : t('ui_err_city');
    const extraOk = validate ? validate() : true;
    if (phoneError || cityError || !extraOk) {
      setFormErrors({ phone: phoneError, city: cityError });
      return;
    }

    setIsSubmitting(true);

    try {
      const comment = composeComment ? composeComment(formData.comment) : formData.comment;

      // Submit to Strapi API
      const apiUrl = `${window.location.origin}/api/contact-requests`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          data: {
            name: formData.name,
            phone: formData.phone,
            email: formData.email || undefined,
            city: formData.city,
            comment: comment || undefined,
            language: locale,
          },
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to submit form');
      }

      // Success - show success state
      setIsSubmitted(true);

      // Reset form - ensure values are always defined
      setFormData(EMPTY);
      setFormErrors({ phone: '', city: '' });
      if (onSuccess) onSuccess();

      if (autoHideMs > 0) {
        setTimeout(() => {
          setIsSubmitted(false);
        }, autoHideMs);
      }
    } catch (error) {
      console.error('Form submission error:', error);
      setSubmitError(t('form_error'));
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    formData,
    isSubmitting,
    isSubmitted,
    submitError,
    formErrors,
    setField,
    handleInputChange,
    handleSubmit,
    resetSubmitted,
  };
};
