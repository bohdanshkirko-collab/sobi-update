import DottedBackground from '../DottedBackground';
import { useContactForm } from '../../hooks/useContactForm';
import { useAnalytics } from '../../hooks/useAnalytics';

interface ContactSectionProps {
  t: (key: string) => string;
  locale: string;
}

export const ContactSection = ({ t, locale }: ContactSectionProps) => {
  const { trackFormSubmit } = useAnalytics();
  const {
    formData,
    isSubmitting,
    isSubmitted,
    formErrors,
    handleInputChange,
    handleSubmit
  } = useContactForm(t, locale);

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Track form submission attempt
    trackFormSubmit({
      form_name: 'contact_form',
      language: locale,
      city: formData.city,
    });

    // Call the original form handler
    await handleSubmit(e);
  };

  return (
    <section id="contact" className="py-10 relative overflow-hidden">
      <DottedBackground />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Contact Form */}
        <div className="max-w-2xl mx-auto">
          <form onSubmit={isSubmitted ? (e) => e.preventDefault() : handleFormSubmit} className="bg-white shadow-lg p-8 transition-all duration-500 min-h-[500px] flex flex-col">
            {isSubmitted ? (
              <div className="animate-smoothFade text-center flex-1 flex flex-col items-center justify-center">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-6">
                  <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                </div>
                <h3 className="text-3xl font-bold text-green-600">
                  {t('form_success')}
                </h3>
              </div>
            ) : (
              <div className="animate-smoothFade">
                <div className="text-center mb-8">
                  <h2 className="text-3xl md:text-4xl font-bold text-black mb-4">
                    {t('cta_title')}
                  </h2>
                  <p className="text-xl text-gray-700">
                    {t('cta_form')}
                  </p>
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Name Field */}
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                      {t('form_name')} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name || ''}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 focus:ring-2 focus:ring-black focus:border-transparent outline-none transition-all"
                      placeholder={t('form_name_placeholder')}
                    />
                  </div>

                  {/* Phone Field */}
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                      {t('form_phone')} <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone || ''}
                      onChange={handleInputChange}
                      required
                      className={`w-full px-4 py-2 border focus:ring-2 focus:border-transparent outline-none transition-all ${formErrors.phone
                        ? 'border-red-500 focus:ring-red-500'
                        : 'border-gray-300 focus:ring-black'
                        }`}
                      placeholder="+48 XXX XXX XXX"
                    />
                    {formErrors.phone && (
                      <p className="mt-1 text-sm text-red-500">
                        {formErrors.phone}
                      </p>
                    )}
                  </div>

                  {/* Email Field */}
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                      {t('form_email')}
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email || ''}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 focus:ring-2 focus:ring-black focus:border-transparent outline-none transition-all"
                      placeholder={t('form_email_placeholder')}
                    />
                  </div>

                  {/* City Dropdown */}
                  <div>
                    <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-2">
                      {t('form_city')} <span className="text-red-500">*</span>
                    </label>
                    <select
                      id="city"
                      name="city"
                      value={formData.city || ''}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 border border-gray-300 focus:ring-2 focus:ring-black focus:border-transparent outline-none transition-all bg-white appearance-none cursor-pointer min-h-[40px]"
                    >
                      <option value="">{t('form_city_select')}</option>
                      <option value="gdansk">{t('city_gdansk')}</option>
                      <option value="gdynia">{t('city_gdynia')}</option>
                      <option value="sopot">{t('city_sopot')}</option>
                      <option value="rumia">{t('city_rumia')}</option>
                      <option value="reda">{t('city_reda')}</option>
                      <option value="kosakowo">{t('city_kosakowo')}</option>
                      <option value="pruszcz-gdanski">{t('city_pruszcz_gdanski')}</option>
                    </select>
                  </div>
                </div>

                {/* Comment Field - Full Width */}
                <div className="mt-6">
                  <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-2">
                    {t('form_comment')}
                  </label>
                  <textarea
                    id="comment"
                    name="comment"
                    value={formData.comment || ''}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 focus:ring-2 focus:ring-black focus:border-transparent outline-none resize-none"
                    placeholder={t('form_comment_placeholder')}
                  />
                </div>

                {/* Submit Button */}
                <div className="mt-8 text-center">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className={`px-8 py-3 text-lg font-medium transition-all ${isSubmitting
                      ? 'bg-gray-400 text-gray-200 cursor-not-allowed'
                      : 'bg-black text-white hover:bg-gray-800'
                      }`}
                  >
                    {isSubmitting
                      ? t('form_submitting')
                      : t('form_submit')}
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </section>
  );
};