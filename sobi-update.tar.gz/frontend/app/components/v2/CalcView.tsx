'use client';

import { useEffect, useRef, useState } from 'react';
import Header from '../Header';
import Footer from '../Footer';
import { getCars } from '../../services/carService';
import { Car } from '../../../types/car';
import { Locale, STRAPI_URL, TFn, useMounted, useReveal, useTx } from './shared';

const QUICK = [1000, 1500, 2000, 3000];
const DAYS = [1, 2, 3, 4, 5, 6, 7];
const HOURLY_RATE = 65;
const PERCENT = 0.08;
const FIXED_FEE = 50;
const MAX_INCOME = 999999;

function carImage(c: Car): string {
  const url = c.image?.formats?.small?.url || c.image?.formats?.medium?.url || c.image?.url;
  if (!url) return '';
  return /^https?:\/\//.test(url) ? url : `${STRAPI_URL}${url}`;
}

/** Number formatting like in Poland: 1 800,5 – minus sign as "−". */
const fmt = (n: number) =>
  (Math.round(n * 10) / 10).toLocaleString('pl-PL', { maximumFractionDigits: 1 }).replace('-', '−');
const fmt0 = (n: number) => Math.round(n).toLocaleString('pl-PL').replace('-', '−');

/** Recommendation texts already stored in Strapi (calc_recommendation_*). */
function recommendationKey(car: Car | null, netto: number): string {
  if (!car || netto <= 0) return '';
  const band = netto <= 1000 ? 'low' : netto <= 1500 ? 'medium' : 'high';
  const brand = (car.brand || '').trim().toLowerCase();
  const model = (car.model || '').trim().toLowerCase();
  if (brand === 'toyota' && (model === 'corolla' || model === 'camry')) return `calc_recommendation_toyota_corolla_${band}`;
  if (brand === 'dacia' && model.startsWith('logan')) return `calc_recommendation_dacia_${band}`;
  if (brand === 'toyota' && model.startsWith('prius')) return `calc_recommendation_prius_${band}`;
  return 'calc_recommendation_default';
}

interface CalcViewProps {
  t: TFn;
  translations: Record<string, string>;
  locale: Locale;
  setLocale: (l: Locale) => void;
}

export default function CalcView({ t, translations, locale, setLocale }: CalcViewProps) {
  const tx = useTx(t);
  const mounted = useMounted();
  const rootRef = useRef<HTMLDivElement>(null);
  useReveal(rootRef, mounted);

  const [mode, setMode] = useState<'known' | 'hourly'>('known');
  const [income, setIncomeRaw] = useState('');
  const [touched, setTouched] = useState(false);
  const [incomeMax, setIncomeMax] = useState(false);
  const [hours, setHours] = useState(8);
  const [days, setDays] = useState(5);
  const [own, setOwn] = useState(false);
  const [carIdx, setCarIdx] = useState(0);
  const [hint, setHint] = useState(false);
  const [cars, setCars] = useState<Car[]>([]);

  useEffect(() => {
    getCars()
      .then(setCars)
      .catch((err) => console.error('Error loading cars:', err));
  }, []);

  /* ---- income input (digits only, 0 → 1, max 999 999) ---- */
  const maxTimer = useRef<number | undefined>(undefined);
  const setIncome = (raw: string) => {
    let v = String(raw).replace(/[^0-9]/g, '');
    let max = false;
    if (v.length && parseInt(v, 10) === 0) v = '1';
    if (v.length && parseInt(v, 10) > MAX_INCOME) {
      v = String(MAX_INCOME);
      max = true;
    }
    setIncomeRaw(v);
    setTouched(true);
    setIncomeMax(max);
    window.clearTimeout(maxTimer.current);
    if (max) maxTimer.current = window.setTimeout(() => setIncomeMax(false), 3000);
  };
  useEffect(() => () => window.clearTimeout(maxTimer.current), []);

  /* ---- calculation (same rules as before) ---- */
  const known = mode === 'known';
  const incNum = parseFloat(income) || 0;
  const netto = known ? incNum : HOURLY_RATE * hours * days;
  const car = own ? null : cars[carIdx] || null;
  const rent = car ? car.weeklyPrice || 0 : 0;
  let afterPercent = netto * (1 - PERCENT);
  let afterFixed = afterPercent - FIXED_FEE;
  let profit = afterFixed - rent;
  if (netto === 0) {
    afterPercent = 0;
    afterFixed = 0;
    profit = 0;
  }
  const recKey = recommendationKey(car, netto);

  /* ---- animated result number ---- */
  const target = Math.round(profit);
  const [disp, setDisp] = useState(0);
  const [bump, setBump] = useState(0);
  const [recV, setRecV] = useState(0);
  const dispRef = useRef(0);
  const firstRun = useRef(true);
  useEffect(() => {
    const from = dispRef.current;
    let raf = 0;
    let t0 = 0;
    const step = (t: number) => {
      if (!t0) t0 = t;
      const p = Math.min(1, (t - t0) / 700);
      const e = 1 - Math.pow(1 - p, 3);
      const v = from + (target - from) * e;
      dispRef.current = v;
      setDisp(v);
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    if (!firstRun.current) setBump((b) => (b ? 0 : 1));
    firstRun.current = false;
    return () => cancelAnimationFrame(raf);
  }, [target]);
  const recSig = `${recKey}|${carIdx}`;
  const firstRec = useRef(true);
  useEffect(() => {
    if (!firstRec.current) setRecV((v) => (v ? 0 : 1));
    firstRec.current = false;
  }, [recSig]);

  /* ---- view values ---- */
  const incomeEmpty = known && touched && income === '';
  const incomeSlider = Math.min(5000, incNum);
  const incomePct = ((incomeSlider / 5000) * 100).toFixed(2);
  const hPctN = ((hours - 1) / 23) * 100;
  const hPct = hPctN.toFixed(2);
  const hBubble = `calc(${hPctN.toFixed(2)}% + ${(15 - hPctN * 0.3).toFixed(1)}px)`;

  const parts = {
    p: Math.max(0, profit),
    c: netto * PERCENT,
    f: netto > 0 ? FIXED_FEE : 0,
    r: netto > 0 ? rent : 0,
  };
  const total = Math.max(netto, parts.c + parts.f + parts.r, 1);
  const w = (v: number) => (netto > 0 ? (v / total) * 100 : 0).toFixed(2);
  const wP = w(parts.p);
  const wC = w(parts.c);
  const wF = w(parts.f);
  const wR = w(parts.r);

  const bigValue = fmt0(disp);
  const monthValue = fmt0(disp * 4.33);
  const rNetto = fmt(netto);
  const rPercent = fmt(afterPercent);
  const rFixed = fmt(afterFixed);
  const rProfit = fmt(profit);
  const rentLabel = String(rent);

  return (
    <div className={`sobi p-calc ${mounted ? 'js' : ''}`} ref={rootRef}>
      <Header locale={locale} setLocale={setLocale} translations={translations} current="calc" />

      <main>
        {/* ===== PAGE HEAD ===== */}
        <section className="chead">
          <div className="chead-dots" aria-hidden="true"></div>
          <div className="wrap">
            <p className="kicker ld s1">{tx.calc_k}</p>
            <h1 className="h1"><span className="ln"><span className="s1">{tx.calc_h1}</span></span><span className="ln"><span className="s2">{tx.calc_h2}</span></span></h1>
            <div className="flow ld s4" aria-label={tx.a_flow}>
              <span className="fc">{tx.netto}</span>
              <svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg>
              <span className="fc">− 8%</span>
              <svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg>
              <span className="fc">− 50 zł</span>
              <svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg>
              <span className="fc">{tx.minus_rent}</span>
              <svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg>
              <span className="fc">{tx.eq_profit}</span>
            </div>
          </div>
        </section>

        {/* ===== CALCULATOR ===== */}
        <section className="calc" aria-label={tx.nav_calc}>
          <div className="wrap calc-grid">
            <div>
              {/* step 1 */}
              <div className="step ld s3">
                <div className="step-h"><span className="step-n">01</span><h2>{tx.step1}</h2></div>
                <div className={`seg ${known ? '' : 'r'}`} role="group" aria-label={tx.a_mode}>
                  <span className="seg-pill" aria-hidden="true"></span>
                  <button type="button" className={known ? 'on' : ''} aria-pressed={known} onClick={() => setMode('known')}>{tx.mode_known}</button>
                  <button type="button" className={known ? '' : 'on'} aria-pressed={!known} onClick={() => setMode('hourly')}>{tx.mode_hourly}</button>
                </div>

                {known ? (<>
                  <div>
                    <label className="lbl" htmlFor="c-income">{tx.inc_label} <em>*</em></label>
                    <div className={`money ${incomeEmpty ? 'err' : ''}`}>
                      <input id="c-income" type="text" inputMode="numeric" placeholder={tx.inc_ph} value={income} onChange={(e) => setIncome(e.target.value)} aria-invalid={incomeEmpty} />
                      <span>zł</span>
                    </div>
                    {incomeEmpty ? (<>
                      <p className="msg"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><path d="M12 8v5"></path><path d="M12 16.5v.01"></path></svg>{tx.err_empty}</p>
                    </>) : null}
                    {incomeMax ? (<>
                      <p className="msg"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><path d="M12 8v5"></path><path d="M12 16.5v.01"></path></svg>{tx.err_max}</p>
                    </>) : null}
                    <input className="range" type="range" min="0" max="5000" step="50" value={incomeSlider} onChange={(e) => setIncome(e.target.value)} aria-label={tx.a_slider} style={{ backgroundSize: `${incomePct}% 100%` }} />
                    <div className="ticks" aria-hidden="true"><span>0</span><span>1 000</span><span>2 000</span><span>3 000</span><span>4 000</span><span>5 000</span></div>
                    <div className="quick" role="group" aria-label={tx.a_quick}>
                      {QUICK.map((q) => (
                        <button key={q} type="button" className={incNum === q ? 'on' : ''} onClick={() => setIncome(String(q))}>{fmt0(q)} zł</button>
                      ))}
                    </div>
                  </div>
                </>) : null}

                {!known ? (<>
                  <div>
                    <p className="lbl">{tx.rate_l}</p>
                    <div className="rate">
                      <div className="rate-l">
                        <span className="lock" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><rect x="5" y="10.5" width="14" height="10" rx="2.5"></rect><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"></path></svg></span>
                        <b>65 <small>zł / {tx.h}</small></b>
                      </div>
                      <button className={`hint ${hint ? 'on' : ''}`} type="button" onClick={() => setHint(!hint)} aria-label={tx.a_rate} aria-expanded={hint}>i</button>
                      {hint ? (<>
                        <div className="tip" role="note">{tx.rate_tip}</div>
                      </>) : null}
                    </div>
                    <p className="lbl">{tx.days_l} <em>*</em></p>
                    <div className="days" role="group" aria-label={tx.days_l}>
                      {DAYS.map((n) => (
                        <button key={n} type="button" className={`day ${n <= days ? 'on' : ''} ${n === days ? 'cur' : ''}`} aria-pressed={n === days} onClick={() => setDays(n)} style={{ transitionDelay: `${(n * 0.035).toFixed(3)}s` }}>{n}</button>
                      ))}
                    </div>
                    <label className="lbl" htmlFor="c-hours">{tx.hours_l} <em>*</em></label>
                    <div className="hwrap">
                      <span className="bubble" style={{ left: hBubble }} aria-hidden="true">{hours} {tx.h}</span>
                      <input id="c-hours" className="range" type="range" min="1" max="24" step="1" value={hours} onChange={(e) => setHours(parseInt(e.target.value, 10) || 1)} style={{ backgroundSize: `${hPct}% 100%` }} />
                    </div>
                    <div className="ticks" aria-hidden="true"><span>1 {tx.h}</span><span>6 {tx.h}</span><span>12 {tx.h}</span><span>18 {tx.h}</span><span>24 {tx.h}</span></div>
                  </div>
                </>) : null}
              </div>

              {/* step 2 */}
              <div className="step ld s4">
                <div className="step-h"><span className="step-n">02</span><h2>{tx.step2}</h2></div>
                <div className={`seg ${own ? 'r' : ''}`} role="group" aria-label={tx.step2}>
                  <span className="seg-pill" aria-hidden="true"></span>
                  <button type="button" className={own ? '' : 'on'} aria-pressed={!own} onClick={() => setOwn(false)}>{tx.rent}</button>
                  <button type="button" className={own ? 'on' : ''} aria-pressed={own} onClick={() => setOwn(true)}>{tx.own}</button>
                </div>

                {!own ? (<>
                  <div>
                    <p className="sel-h">{tx.pick_car}</p>
                    <div className="tiles">
                      {cars.map((c, i) => (
                        <button key={c.id} type="button" className={`tile ${!own && carIdx === i ? 'on' : ''}`} aria-pressed={!own && carIdx === i} onClick={() => { setCarIdx(i); setOwn(false); }}>
                          <span className="tick" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>
                          <span className="ti-img">
                            {carImage(c) ? (<><img src={carImage(c)} alt="" /></>) : (<><svg className="ti-ph" viewBox="0 0 300 130" aria-hidden="true"><path d="M20 100 L16 82 Q16 72 26 69 L74 58 L120 28 Q127 23 137 23 L262 25 Q276 26 280 36 L288 68 Q291 78 288 100 Z"></path><circle cx="74" cy="100" r="17"></circle><circle cx="236" cy="100" r="17"></circle></svg></>)}
                          </span>
                          <b>{c.brand} {c.model}</b>
                          <small>{fmt0(c.weeklyPrice)} {tx.per_week}</small>
                        </button>
                      ))}
                    </div>
                  </div>
                </>) : null}

                {own ? (<>
                  <div className="own">
                    <span className="own-ic" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M5 17H3v-4.5l2-5.5h14l2 5.5V17h-2"></path><path d="M3 12.5h18"></path><circle cx="7.5" cy="17" r="2"></circle><circle cx="16.5" cy="17" r="2"></circle><path d="M9.5 17h5"></path></svg></span>
                    <div><p>{tx.own_note}</p><a className="own-more" href="/wlasne-auto/">{tx.own_more}<svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></a></div>
                  </div>
                </>) : null}

                {recKey ? (<>
                  <div className={`rec ${recV ? 'va' : 'vb'}`} role="status">
                    <span className="rec-ic" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M12 2c.6 5.4 4.6 9.4 10 10-5.4.6-9.4 4.6-10 10-.6-5.4-4.6-9.4-10-10 5.4-.6 9.4-4.6 10-10z"></path></svg></span>
                    <div>
                      <h3>{tx.rec_t}</h3>
                      <p>{t(recKey)}</p>
                    </div>
                  </div>
                </>) : null}
              </div>
            </div>

            {/* results */}
            <aside id="wyniki" className="res" aria-label={tx.res_h}>
              <div className="res-glow" aria-hidden="true"></div>
              <div className="res-top">
                <h2>{tx.res_h}</h2>
                <span className="live"><i></i>{tx.live}</span>
              </div>
              <p className="res-lbl">{tx.weekly}</p>
              <p className={`big ${bump ? 'ba' : 'bb'}`} aria-live="polite"><span>{bigValue}</span><small>zł</small></p>
              <p className="month">{tx.monthly} <b>≈ {monthValue} zł</b></p>

              <div className="stack" aria-hidden="true">
                <i className="sg-p" style={{ width: `${wP}%` }}></i>
                <i className="sg-c" style={{ width: `${wC}%` }}></i>
                <i className="sg-f" style={{ width: `${wF}%` }}></i>
                <i className="sg-r" style={{ width: `${wR}%` }}></i>
              </div>
              <div className="legend" aria-hidden="true">
                <span><i className="sg-p"></i>{tx.leg_profit}</span>
                <span><i className="sg-c"></i>8%</span>
                <span><i className="sg-f"></i>50 zł</span>
                {!own ? (<><span><i className="sg-r"></i>{tx.leg_rent}</span></>) : null}
              </div>

              <ul className="rows">
                <li><span>{tx.r_netto}</span><b>{rNetto} zł</b></li>
                <li><span>{tx.r_pct}</span><b>{rPercent} zł</b></li>
                <li><span>{tx.r_fixed}</span><b>{rFixed} zł</b></li>
                {!own ? (<>
                  <li><span>{tx.r_rent} {rentLabel} zł:</span><b>{rProfit} zł</b></li>
                </>) : null}
                <li className="total"><span>{tx.weekly}</span><b>{rProfit} zł</b></li>
              </ul>

              <div className="fair">
                <span className="fair-ic" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M12 3l8 3v6c0 4.5-3.4 8.2-8 9-4.6-.8-8-4.5-8-9V6z"></path><path d="M8.5 12l2.5 2.5 4.5-5"></path></svg></span>
                <div><b>{tx.fair_b}</b><span>{tx.fair_s}</span></div>
              </div>

              <a className="btn btn-light wide" href="/#contact"><span>{tx.join}</span><span className="arr"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span></a>
            </aside>
          </div>
        </section>
      </main>

      <a className="mbar" href="#wyniki"><span>{tx.weekly2}</span><b>{bigValue} zł</b></a>

      <Footer translations={translations} />
    </div>
  );
}
