'use client';

import { useEffect, useMemo, useRef, useState } from 'react';

export type Locale = 'pl' | 'uk' | 'ru' | 'en';
export type TFn = (key: string, fallback?: string) => string;

/**
 * Access to the new-design texts. `tx.hero_sub` returns t('ui_hero_sub').
 * All texts of the new design live in Strapi under keys prefixed with "ui_".
 */
export function useTx(t: TFn): Record<string, string> {
  return useMemo(
    () => new Proxy({} as Record<string, string>, { get: (_o, k) => t('ui_' + String(k)) }),
    [t]
  );
}

/** Adds the "js" class after mount so CSS can hide elements that animate in on scroll. */
export function useMounted() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  return mounted;
}

/**
 * Reveal-on-scroll: every element with a data-rv attribute inside `root`
 * gets the class "in" once it enters the viewport.
 */
export function useReveal(root: React.RefObject<HTMLElement | null>, ready = true) {
  useEffect(() => {
    const el = root.current;
    if (!el || !ready) return;
    if (typeof IntersectionObserver === 'undefined') {
      el.querySelectorAll('[data-rv]').forEach((n) => n.classList.add('in'));
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add('in');
            io.unobserve(en.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -6% 0px' }
    );
    const seen = new WeakSet<Element>();
    const scan = () => {
      el.querySelectorAll('[data-rv]').forEach((n) => {
        if (!seen.has(n) && !n.classList.contains('in')) {
          seen.add(n);
          io.observe(n);
        }
      });
    };
    scan();
    const mo = new MutationObserver(scan);
    mo.observe(el, { childList: true, subtree: true });
    // Safety net: never leave content hidden.
    const fallback = window.setTimeout(() => {
      el.querySelectorAll('[data-rv]').forEach((n) => {
        const r = n.getBoundingClientRect();
        if (r.top < window.innerHeight && r.bottom > 0) n.classList.add('in');
      });
    }, 2500);
    return () => {
      io.disconnect();
      mo.disconnect();
      window.clearTimeout(fallback);
    };
  }, [root, ready]);
}

/** Returns true once the referenced element has been visible. */
export function useSeen<T extends Element>(threshold = 0.2) {
  const ref = useRef<T | null>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || seen) return;
    if (typeof IntersectionObserver === 'undefined') {
      setSeen(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setSeen(true);
          io.disconnect();
        }
      },
      { threshold }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [seen, threshold]);
  return [ref, seen] as const;
}

/** Number that counts up from 0 when it scrolls into view. */
export function CountUp({ to, duration = 1700, delay = 0 }: { to: number; duration?: number; delay?: number }) {
  const [ref, seen] = useSeen<HTMLSpanElement>(0.3);
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!seen) return;
    let raf = 0;
    let t0 = 0;
    const timer = window.setTimeout(() => {
      const step = (t: number) => {
        if (!t0) t0 = t;
        const p = Math.min(1, (t - t0) / duration);
        const e = 1 - Math.pow(1 - p, 3);
        setVal(Math.round(to * e));
        if (p < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    }, delay);
    return () => {
      window.clearTimeout(timer);
      cancelAnimationFrame(raf);
    };
  }, [seen, to, duration, delay]);
  return <span ref={ref}>{val}</span>;
}

/* ---------- small icons ---------- */
export const ArrowIcon = () => (
  <svg className="ic" viewBox="0 0 24 24" aria-hidden="true">
    <path d="M5 12h14"></path>
    <path d="M13 6l6 6-6 6"></path>
  </svg>
);

export const ArrowPair = () => (
  <span className="arr">
    <ArrowIcon />
    <ArrowIcon />
  </span>
);

export const StarIcon = ({ className = 'ic fill' }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
    <path d="M12 2c.6 5.4 4.6 9.4 10 10-5.4.6-9.4 4.6-10 10-.6-5.4-4.6-9.4-10-10 5.4-.6 9.4-4.6 10-10z"></path>
  </svg>
);

export const CheckIcon = ({ className = 'ic' }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
    <path d="M5 12.5l4.5 4.5L19 7.5"></path>
  </svg>
);

/** The eye-catching "Calculate earnings" button with rolling digits. */
export function CalcButton({ label, className = '' }: { label: string; className?: string }) {
  return (
    <a className={`btn btn-calc ${className}`} href="/income-calculator/">
      <span className="cb-ic" aria-hidden="true">
        <svg className="ic" viewBox="0 0 24 24">
          <rect x="5" y="3" width="14" height="18" rx="2.5"></rect>
          <path d="M8 7.5h8"></path>
          <path d="M8.5 12h.01"></path>
          <path d="M12 12h.01"></path>
          <path d="M15.5 12h.01"></path>
          <path d="M8.5 15.5h.01"></path>
          <path d="M12 15.5h.01"></path>
          <path d="M15.5 15.5v2"></path>
        </svg>
      </span>
      <span>{label}</span>
      <span className="cb-odo" aria-hidden="true">
        <span className="dg"><span className="dg-t">0123456789</span></span>
        <span className="dg"><span className="dg-t">0123456789</span></span>
        <span className="dg"><span className="dg-t">0123456789</span></span>
        <span className="cb-zl">zł</span>
      </span>
    </a>
  );
}

/** Schematic map of the 7 towns covered by SOBI's licence extracts (animated). */
export function CityMap({ tx }: { tx: Record<string, string> }) {
  const route = 'M131,91 L157,128 L215,113 L248,186 L266,271 L321,369 L315,468';
  const cities: { c: string; x: number; y: number; k: string; tx: number; ty: number; anchor?: 'end' | 'middle' }[] = [
    { c: 'c1', x: 131, y: 91, k: 'city_reda', tx: 117, ty: 95, anchor: 'end' },
    { c: 'c2', x: 157, y: 128, k: 'city_rumia', tx: 143, ty: 132, anchor: 'end' },
    { c: 'c3', x: 215, y: 113, k: 'city_kosakowo', tx: 215, ty: 94, anchor: 'middle' },
    { c: 'c4', x: 248, y: 186, k: 'city_gdynia', tx: 234, ty: 190, anchor: 'end' },
    { c: 'c5', x: 266, y: 271, k: 'city_sopot', tx: 252, ty: 275, anchor: 'end' },
    { c: 'c6', x: 321, y: 369, k: 'city_gdansk', tx: 335, ty: 373 },
    { c: 'c7', x: 315, y: 468, k: 'city_pruszcz', tx: 329, ty: 472 },
  ];
  return (
    <>
      <svg viewBox="0 0 480 520" role="img" aria-label={tx.a_map}>
        <defs>
          <pattern id="sobi-sea" width="14" height="14" patternUnits="userSpaceOnUse">
            <circle cx="2" cy="2" r="1.3" fill="#3a3a3a"></circle>
          </pattern>
        </defs>
        <path className="sea" d="M209,-20 L228,52 L244,96 L257,140 L264,184 L274,239 L289,283 L324,311 L388,327 L500,333 L500,-20 Z" fill="url(#sobi-sea)"></path>
        <path className="coast" d="M209,-20 L228,52 L244,96 L257,140 L264,184 L274,239 L289,283 L324,311 L388,327 L500,333"></path>
        <text className="sea-t" x="392" y="190">{tx.sea1}</text>
        <text className="sea-t" x="392" y="208">{tx.sea2}</text>
        <path className="ct-route" d={route}></path>
        {cities.map((c) => (
          <g key={c.c} className={`cty ${c.c}`}>
            <circle className="cp" cx={c.x} cy={c.y} r="8"></circle>
            <circle className="cd" cx={c.x} cy={c.y} r="7"></circle>
            <text x={c.tx} y={c.ty} textAnchor={c.anchor}>{tx[c.k]}</text>
          </g>
        ))}
        <circle className="ct-car" r="6">
          <animateMotion dur="9s" repeatCount="indefinite" keyPoints="0;1;0" keyTimes="0;0.5;1" calcMode="linear" path={route}></animateMotion>
        </circle>
      </svg>
      <div className="ct-badge">
        <b>7</b>
        <span>
          {tx.badge1}
          <br />
          {tx.badge2}
        </span>
      </div>
    </>
  );
}

/** Full-screen black loader shown while texts are loading (same look as the intro). */
export function SobiLoader() {
  return (
    <div className="sobi-loader" aria-label="SOBI">
      <div className="sobi-loader-word">
        <span>S</span>
        <span>O</span>
        <span>B</span>
        <span>I</span>
      </div>
      <div className="sobi-loader-bar"><i></i></div>
    </div>
  );
}

/** Mouse tilt for cards – updates the DOM directly (no re-render). */
export function tiltMove(e: React.MouseEvent<HTMLElement>) {
  const el = e.currentTarget;
  const r = el.getBoundingClientRect();
  const px = (e.clientX - r.left) / r.width - 0.5;
  const py = (e.clientY - r.top) / r.height - 0.5;
  el.style.transform = `perspective(1000px) rotateX(${(-py * 9).toFixed(2)}deg) rotateY(${(px * 11).toFixed(2)}deg)`;
}
export function tiltLeave(e: React.MouseEvent<HTMLElement>) {
  e.currentTarget.style.transform = '';
}

/** City values saved in Strapi (same as in the old form) + their translation keys. */
export const FORM_CITIES = [
  { id: 'gdansk', label: 'city_gdansk' },
  { id: 'gdynia', label: 'city_gdynia' },
  { id: 'sopot', label: 'city_sopot' },
  { id: 'rumia', label: 'city_rumia' },
  { id: 'reda', label: 'city_reda' },
  { id: 'kosakowo', label: 'city_kosakowo' },
  { id: 'pruszcz-gdanski', label: 'city_pruszcz' },
];


export const STRAPI_URL = process.env.NEXT_PUBLIC_STRAPI_URL;
