'use client';

import { useEffect, useRef, useState } from 'react';
import Header from '../Header';
import Footer from '../Footer';
import { useContactForm } from '../../hooks/useContactForm';
import { useAnalytics } from '../../hooks/useAnalytics';
import { CalcButton, CityMap, FORM_CITIES, Locale, StarIcon, TFn, useMounted, useReveal, useTx } from './shared';

const DRV_CHECKS = ['d1', 'd2', 'd3', 'd4'];
const CAR_CHECKS = ['c1', 'c2', 'c3'];
const TOTAL = DRV_CHECKS.length + CAR_CHECKS.length;
const FAQ = [1, 2, 3, 4, 5];
const TAXI_OPTS = [
  { id: 'yes', label: 'opt_yes', pl: 'Tak' },
  { id: 'no', label: 'opt_notyet', pl: 'Jeszcze nie' },
  { id: 'dk', label: 'opt_dk', pl: 'Nie wiem' },
];
const TICKER = ['t_48', 't_lic', 't_ref', 'b5h', 't_fuel', 't_shop2', 'p3h', 't_help'];

interface OwnViewProps {
  t: TFn;
  translations: Record<string, string>;
  locale: Locale;
  setLocale: (l: Locale) => void;
}

export default function OwnView({ t, translations, locale, setLocale }: OwnViewProps) {
  const tx = useTx(t);
  const mounted = useMounted();
  const rootRef = useRef<HTMLDivElement>(null);
  useReveal(rootRef, mounted);
  const { trackFormSubmit } = useAnalytics();

  const tick = TICKER.map((k) => tx[k]);
  const ticker = tick.concat(tick, tick, tick);

  /* ---- 4 steps: light up when seen ---- */
  const [lit, setLit] = useState([false, false, false, false]);
  const stepRefs = useRef<(HTMLElement | null)[]>([]);
  useEffect(() => {
    if (!mounted) return;
    if (typeof IntersectionObserver === 'undefined') {
      setLit([true, true, true, true]);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (!en.isIntersecting) return;
          const i = Number((en.target as HTMLElement).dataset.step);
          setLit((prev) => {
            if (prev[i]) return prev;
            const next = [...prev];
            next[i] = true;
            return next;
          });
          io.unobserve(en.target);
        });
      },
      { threshold: 0.2, rootMargin: '0px 0px -10% 0px' }
    );
    stepRefs.current.forEach((el) => el && io.observe(el));
    return () => io.disconnect();
  }, [mounted]);
  let curStep = 1;
  lit.forEach((on, i) => {
    if (on) curStep = i + 1;
  });

  /* ---- timeline line follows scrolling (DOM only, no re-render) ---- */
  const lineRef = useRef<HTMLDivElement>(null);
  const fillRef = useRef<HTMLDivElement>(null);
  const carRef = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    let raf = 0;
    const update = () => {
      raf = 0;
      const line = lineRef.current;
      if (!line) return;
      const r = line.getBoundingClientRect();
      const f = Math.max(0, Math.min(1, (window.innerHeight * 0.6 - r.top) / Math.max(1, r.height)));
      if (fillRef.current) fillRef.current.style.transform = `scaleY(${f.toFixed(4)})`;
      if (carRef.current) carRef.current.style.top = `${(f * 100).toFixed(2)}%`;
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  /* ---- readiness checklist ---- */
  const [checks, setChecks] = useState<Record<string, boolean>>({});
  const toggleCheck = (id: string) => setChecks((c) => ({ ...c, [id]: !c[id] }));
  const done = DRV_CHECKS.concat(CAR_CHECKS).filter((id) => checks[id]).length;
  const pct = Math.round((done / TOTAL) * 100);
  const ringOff = (326.73 * (1 - done / TOTAL)).toFixed(2);
  const fillText = (str: string) => str.replace('{n}', String(TOTAL - done)).replace('{t}', String(TOTAL));
  let readyTitle: string;
  let readyText: string;
  if (done === TOTAL) {
    readyTitle = tx.rd_all_t;
    readyText = tx.rd_all_p;
  } else if (done >= 5) {
    readyTitle = tx.rd_most_t;
    readyText = fillText(tx.rd_most_p);
  } else if (done >= 1) {
    readyTitle = tx.rd_some_t;
    readyText = fillText(tx.rd_some_p);
  } else {
    readyTitle = tx.rd_none_t;
    readyText = tx.rd_none_p;
  }

  /* ---- FAQ ---- */
  const [faq, setFaq] = useState(0);

  /* ---- form (saved as a normal contact request) ---- */
  const [carName, setCarName] = useState('');
  const [carYear, setCarYear] = useState('');
  const [taxi, setTaxi] = useState('');
  const [taxiErr, setTaxiErr] = useState('');

  const { formData, isSubmitting, isSubmitted, submitError, formErrors, setField, handleInputChange, handleSubmit, resetSubmitted } =
    useContactForm(t, locale, {
      autoHideMs: 0,
      validate: () => {
        if (!taxi) {
          setTaxiErr(tx.err_taxi);
          return false;
        }
        return true;
      },
      composeComment: (comment) => {
        const taxiPl = TAXI_OPTS.find((o) => o.id === taxi)?.pl || taxi;
        const lines = [`[WŁASNE AUTO] Auto: ${carName.trim()}, rok: ${carYear}, wpis TAXI w dowodzie: ${taxiPl}`];
        if (comment.trim()) lines.push(comment.trim());
        return lines.join('\n');
      },
      onSuccess: () => {
        setCarName('');
        setCarYear('');
        setTaxi('');
      },
    });

  const onSubmit = (e: React.FormEvent) => {
    trackFormSubmit({ form_name: 'own_car_form', language: locale, city: formData.city });
    handleSubmit(e);
  };

  return (
    <div className={`sobi p-own ${mounted ? 'js' : ''}`} ref={rootRef}>
      <Header locale={locale} setLocale={setLocale} translations={translations} current="own" />

        {/* ===== HERO ===== */}
        <section className="hero">
          <div className="hero-dots" aria-hidden="true"></div>
          <div className="hero-in">
            <div>
              <p className="eyebrow ld s1"><span className="pulse"></span>{tx.own_eyebrow}</p>
              <h1 className="h1">
                <span className="ln"><span className="s2">{tx.oh1}</span></span>
                <span className="ln"><span className="s3">{tx.oh2}</span></span>
                <span className="ln"><span className="out s4">{tx.oh3}</span></span>
              </h1>
              <p className="h-sub ld s5">{tx.own_sub}</p>
              <div className="promise ld s6">
                <div className="pr"><span className="pr-ic" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path className="pr-hand" d="M12 12V6.5"></path><path d="M12 12h3.5"></path></svg></span><div><span className="pr-v">{tx.pr_48}</span><span className="pr-l">{tx.own_48_l}</span></div></div>
                <div className="pr"><span className="pr-ic pr-coin" aria-hidden="true"><span className="pr-c">0</span></span><div><span className="pr-v">0 zł</span><span className="pr-l">{tx.pr0_star}</span></div></div>
              </div>
              <p className="pr-note ld s6">{tx.pr_note}</p>
              <div className="h-cta ld s7">
                <a className="btn btn-light" href="#kroki"><span>{tx.see4}</span><span className="arr"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14"></path><path d="M6 13l6 6 6-6"></path></svg><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14"></path><path d="M6 13l6 6 6-6"></path></svg></span></a>
                <a className="btn btn-ghost" href="#zgloszenie">{tx.report_car}</a>
              </div>
            </div>
            <div className="doc-stage" aria-hidden="true">
              <div className="ring-deco"></div>
              <span className="chipf cf1"><i><svg className="ic" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></i>Uber</span>
              <span className="chipf cf2"><i><svg className="ic" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></i>Bolt</span>
              <span className="chipf cf3"><i><svg className="ic" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></i>FreeNow</span>
              <span className="chipf cf4"><i><svg className="ic" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></i>iTaxi</span>
              <div className="doc">
                <div className="doc-in">
                  <div className="doc-h"><span>{tx.doc_h}</span><span>{tx.doc_your}</span></div>
                  <div className="doc-row"><span>{tx.doc_make}</span><span className="bar" style={{ width: '80%' }}></span></div>
                  <div className="doc-row"><span>{tx.doc_type}</span><b>{tx.doc_type_v}</b></div>
                  <div className="doc-row"><span>{tx.doc_seats}</span><b>5</b></div>
                  <div className="doc-ann">
                    <span>{tx.doc_ann}</span>
                    <div className="stamp">TAXI</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="road" aria-hidden="true"></div>
        </section>

        {/* ===== TAPE ===== */}
        <div className="tape" aria-label={tx.a_tape_own}>
          <div className="track">
            {ticker.map((item, i) => (
              <span className="ti" key={i}>{item}<StarIcon /></span>
            ))}
          </div>
        </div>

        {/* ===== STEPS ===== */}
        <section id="kroki" className="steps">
          <div className="wrap steps-grid">
            <div className="steps-side rvw" data-rv="stephead">
              <p className="kicker fu s1">{tx.steps_k}</p>
              <h2 className="h2"><span className="mk s2"><span>{tx.steps_h}</span></span></h2>
              <p className="lead fu s3">{tx.steps_p}</p>
              <div className="side-num fu s4">{curStep}<small>{tx.of4}</small></div>
            </div>

            <div className="tl" ref={lineRef}>
              <div className="tl-line" aria-hidden="true">
                <div className="tl-fill" ref={fillRef} style={{ transform: 'scaleY(0)' }}></div>
                <span className="tl-car" ref={carRef} style={{ top: '0%' }}></span>
              </div>

              <article className={`st ${lit[0] ? 'lit' : ''}`} data-step="0" ref={(el) => { stepRefs.current[0] = el; }}>
                <span className="st-n" aria-hidden="true">1</span>
                <h3>{tx.s1h}</h3>
                <p>{tx.s1p}</p>
                <ul className="req-chips">
                  <li><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg>{tx.rq1}</li>
                  <li><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg>{tx.rq2}</li>
                  <li><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg>{tx.rq3}</li>
                  <li><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg>{tx.rq4}</li>
                  <li><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg>{tx.rq5}</li>
                </ul>
                <div className="links">
                  <a className="lk" href="https://www.uber.com/pl/pl/drive/requirements/vehicle-requirements" target="_blank" rel="noopener">
                    <span className="lk-app">Uber</span><b>{tx.lk1}</b>
                    <span className="lk-go" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span>
                  </a>
                  <a className="lk" href="https://www.uber.com/global/pl/eligible-vehicles/" target="_blank" rel="noopener">
                    <span className="lk-app">Uber</span><b>{tx.lk2}</b>
                    <span className="lk-go" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span>
                  </a>
                  <a className="lk" href="https://bolt.eu/pl-pl/driver/guide/categories/" target="_blank" rel="noopener">
                    <span className="lk-app">Bolt</span><b>{tx.lk3}</b>
                    <span className="lk-go" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span>
                  </a>
                  <a className="lk" href="https://docs.google.com/spreadsheets/d/1a7lD29VrA4IKla9oizCRjkWhoztw_lwKAU5tDl980zs/edit?gid=1136144408#gid=1136144408" target="_blank" rel="noopener">
                    <span className="lk-app">Bolt</span><b>{tx.lk4}</b>
                    <span className="lk-go" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span>
                  </a>
                </div>
              </article>

              <article className={`st ${lit[1] ? 'lit' : ''}`} data-step="1" ref={(el) => { stepRefs.current[1] = el; }}>
                <span className="st-n" aria-hidden="true">2</span>
                <h3>{tx.s2h}</h3>
                <p>{tx.s2p}</p>
                <div className="subs">
                  <div className="sub">
                    <div className="sub-h"><span className="sub-l">a</span><h4>{tx.s2a_h}</h4></div>
                    <p>{tx.s2a_1} <b>{tx.s2a_b}</b>{tx.s2a_2}</p>
                  </div>
                  <div className="sub">
                    <div className="sub-h"><span className="sub-l">b</span><h4>{tx.s2b_h}</h4></div>
                    <p>{tx.s2b_1} <b>{tx.s2b_b}</b>.</p>
                  </div>
                </div>
                <p className="note">{tx.s2_note}</p>
              </article>

              <article className={`st ${lit[2] ? 'lit' : ''}`} data-step="2" ref={(el) => { stepRefs.current[2] = el; }}>
                <span className="st-n" aria-hidden="true">3</span>
                <h3>{tx.s3h}</h3>
                <p>{tx.s3p}</p>
                <div className="help">
                  <span className="help-ic" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M12 3.5l2.6 5.3 5.9.9-4.25 4.1 1 5.8L12 16.9l-5.25 2.7 1-5.8L3.5 9.7l5.9-.9z"></path></svg></span>
                  <div><b>{tx.help_b}</b><span>{tx.help_s}</span></div>
                </div>
              </article>

              <article className={`st ${lit[3] ? 'lit' : ''}`} data-step="3" ref={(el) => { stepRefs.current[3] = el; }}>
                <span className="st-n" aria-hidden="true">4</span>
                <h3>{tx.s4h}</h3>
                <p>{tx.s4p}</p>
              </article>
            </div>
          </div>
        </section>

        {/* ===== CITIES ===== */}
        <section className="cities" aria-labelledby="ct-h">
          <div className="wrap ct-grid">
            <div className="rvw" data-rv="cities">
              <p className="kicker light fu s1">{tx.benefit_k}</p>
              <h2 id="ct-h" className="h2"><span className="mk s2"><span>{tx.t_lic}</span></span></h2>
              <p className="lead light fu s3">{tx.own_lic_p}</p>
              <p className="ct-l fu s4">{tx.tricity}</p>
              <ul className="ct-chips">
                <li className="on fu s4">{tx.city_gdansk}</li>
                <li className="on fu s5">{tx.city_gdynia}</li>
                <li className="on fu s5">{tx.city_sopot}</li>
              </ul>
              <p className="ct-l fu s6">{tx.around}</p>
              <ul className="ct-chips">
                <li className="fu s6">{tx.city_rumia}</li>
                <li className="fu s7">{tx.city_reda}</li>
                <li className="fu s7">{tx.city_kosakowo}</li>
                <li className="fu s8">{tx.city_pruszcz}</li>
              </ul>
            </div>

            <div className="ct-map rvw" data-rv="ctmap">
              <CityMap tx={tx} />
            </div>
          </div>
        </section>

        {/* ===== DRIVER DOCS ===== */}
        <section className="docs">
          <div className="wrap rvw" data-rv="docs">
            <div className="docs-head">
              <div>
                <p className="kicker fu s1">{tx.drv_k}</p>
                <h2 className="h2"><span className="mk s2"><span>{tx.drv_h}</span></span></h2>
              </div>
              <span className="same fu s3"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg>{tx.same}</span>
            </div>
            <div className="dgrid">
              <div className="dcard fu s2"><span className="dnum">01</span><p>{tx.req_age}</p></div>
              <div className="dcard fu s3"><span className="dnum">02</span><p>{tx.req_lic}</p></div>
              <div className="dcard fu s4"><span className="dnum">03</span><p>{tx.req_crim}</p></div>
              <div className="dcard fu s5"><span className="dnum">04</span><p>{tx.req_med}</p></div>
            </div>
          </div>
        </section>

        {/* ===== CHECKLIST ===== */}
        <section className="check" aria-labelledby="ck-h">
          <div className="wrap">
            <div className="rvw" data-rv="ckhead">
              <p className="kicker fu s1">{tx.ck_k}</p>
              <h2 id="ck-h" className="h2"><span className="mk s2"><span>{tx.ck_h}</span></span></h2>
              <p className="lead fu s3">{tx.ck_p}</p>
            </div>
            <div className="ck-grid">
              <div className="ck-cols">
                <div className="ck-col">
                  <h3>{tx.drv_k}</h3>
                  {DRV_CHECKS.map((id) => (
                    <button key={id} type="button" className={`cb ${checks[id] ? 'on' : ''}`} aria-pressed={!!checks[id]} onClick={() => toggleCheck(id)}><span className="box" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>{tx[id]}</button>
                  ))}
                </div>
                <div className="ck-col">
                  <h3>{tx.step2}</h3>
                  {CAR_CHECKS.map((id) => (
                    <button key={id} type="button" className={`cb ${checks[id] ? 'on' : ''}`} aria-pressed={!!checks[id]} onClick={() => toggleCheck(id)}><span className="box" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span>{tx[id]}</button>
                  ))}
                  <p className="ck-note"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.5l2.6 5.3 5.9.9-4.25 4.1 1 5.8L12 16.9l-5.25 2.7 1-5.8L3.5 9.7l5.9-.9z"></path></svg>{tx.ck_note}</p>
                </div>
              </div>
              <aside className={`ready ${done === TOTAL ? 'done' : ''}`} aria-live="polite">
                <div className="rdy-ring">
                  <svg viewBox="0 0 120 120" aria-hidden="true"><circle className="rg-bg" cx="60" cy="60" r="52"></circle><circle className="rg-fg" cx="60" cy="60" r="52" style={{ strokeDashoffset: ringOff }}></circle></svg>
                  <div className="ring-v"><b>{pct}%</b><span>{tx.readiness}</span></div>
                </div>
                <h3>{readyTitle}</h3>
                <p>{readyText}</p>
                <a className="btn btn-light wide" href="#zgloszenie"><span>{tx.report_car}</span><span className="arr"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span></a>
              </aside>
            </div>
          </div>
        </section>

        {/* ===== CALC BAND ===== */}
        <section className="band">
          <div className="band-gear" aria-hidden="true"></div>
          <div className="wrap band-in rvw" data-rv="band">
            <div>
              <h2 className="fu s1">{tx.band_h}</h2>
              <p className="fu s2">{tx.own_note}</p>
              <div className="eq fu s3" aria-hidden="true"><span>{tx.netto}</span><span>− 8%</span><span>− 50 zł</span><span className="x">{tx.minus_rent}</span></div>
            </div>
            <span className="on-dark fu s4"><CalcButton label={tx.calc_btn} /></span>
          </div>
        </section>

        {/* ===== FAQ ===== */}
        <section className="faq">
          <div className="wrap faq-grid">
            <div className="rvw" data-rv="faqhead">
              <p className="kicker fu s1">{tx.faq_k}</p>
              <h2 className="h2"><span className="mk s2"><span>{tx.faq_h}</span></span></h2>
            </div>
            <div>
              {FAQ.map((n, i) => (
                <div key={n} className={`qa ${faq === i ? 'open' : ''}`}>
                  <button className="q" type="button" aria-expanded={faq === i} onClick={() => setFaq(faq === i ? -1 : i)}>{tx['q' + n]}<span className="pm" aria-hidden="true"></span></button>
                  <div className="a"><div><p>{tx['a' + n]}</p></div></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ===== FORM ===== */}
        <section id="zgloszenie" className="contact">
          <div className="wrap contact-grid">
            <div className="rvw" data-rv="contact">
              <p className="kicker fu s1">{tx.form_k}</p>
              <h2 className="h2"><span className="mk s2"><span>{tx.report_car}</span></span></h2>
              <p className="lead fu s3">{tx.form_p}</p>
              <div className="phones fu s4">
                <a className="phone" href="tel:+48791798673"><span>+48 791 798 673</span><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></a>
                <a className="phone" href="tel:+48791798685"><span>+48 791 798 685</span><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></a>
              </div>
            </div>

            <div className="form-card rvw" data-rv="form">
              {isSubmitted ? (<>
                <div className="done" role="status">
                  <div className="done-ring"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></div>
                  <h3>{tx.thanks}</h3>
                  <button className="back" type="button" onClick={resetSubmitted}>{tx.back}</button>
                </div>
              </>) : null}
              {!isSubmitted ? (<>
                <form onSubmit={onSubmit}>
                  <p className="form-title">{tx.form_t}</p>
                  <div className="fgrid">
                    <div className="field"><input id="w-name" name="name" type="text" placeholder=" " required autoComplete="name" value={formData.name} onChange={handleInputChange} /><label htmlFor="w-name">{tx.f_name} <em>*</em></label><span className="uline"></span></div>
                    <div className="field"><input id="w-phone" name="phone" type="tel" placeholder=" " required autoComplete="tel" value={formData.phone} onChange={handleInputChange} aria-invalid={!!formErrors.phone} /><label htmlFor="w-phone">{tx.f_phone} <em>*</em></label><span className="uline"></span>{formErrors.phone ? <span className="ferr">{formErrors.phone}</span> : null}</div>
                    <div className="field"><input id="w-car" name="car" type="text" placeholder=" " required value={carName} onChange={(e) => setCarName(e.target.value)} /><label htmlFor="w-car">{tx.f_car} <em>*</em></label><span className="uline"></span></div>
                    <div className="field"><input id="w-year" name="year" type="text" inputMode="numeric" placeholder=" " required maxLength={4} value={carYear} onChange={(e) => setCarYear(e.target.value.replace(/[^0-9]/g, '').slice(0, 4))} /><label htmlFor="w-year">{tx.f_year} <em>*</em></label><span className="uline"></span></div>
                  </div>
                  <p className="chip-l" id="w-taxi">{tx.f_taxi} <em>*</em></p>
                  <div className="chips" role="group" aria-labelledby="w-taxi">
                    {TAXI_OPTS.map((o) => (
                      <button key={o.id} type="button" className={`chip ${taxi === o.id ? 'on' : ''}`} aria-pressed={taxi === o.id} onClick={() => { setTaxi(o.id); setTaxiErr(''); }}>{tx[o.label]}</button>
                    ))}
                  </div>
                  {taxiErr ? <p className="ferr">{taxiErr}</p> : null}
                  <p className="chip-l" id="w-city">{tx.f_city} <em>*</em></p>
                  <div className="chips" role="group" aria-labelledby="w-city">
                    {FORM_CITIES.map((o) => (
                      <button key={o.id} type="button" className={`chip ${formData.city === o.id ? 'on' : ''}`} aria-pressed={formData.city === o.id} onClick={() => setField('city', o.id)}>{tx[o.label]}</button>
                    ))}
                  </div>
                  {formErrors.city ? <p className="ferr">{formErrors.city}</p> : null}
                  <div className="field full"><textarea id="w-msg" name="comment" rows={3} placeholder=" " value={formData.comment} onChange={handleInputChange}></textarea><label htmlFor="w-msg">{tx.f_comment}</label><span className="uline"></span></div>
                  <div className="form-actions">
                    <button className="btn btn-dark wide" type="submit" disabled={isSubmitting}><span>{isSubmitting ? tx.sending : tx.f_submit}</span><span className="arr"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span></button>
                  </div>
                  {submitError ? <p className="ferr" role="alert">{submitError}</p> : null}
                </form>
              </>) : null}
            </div>
          </div>
        </section>

      <Footer translations={translations} />
    </div>
  );
}
