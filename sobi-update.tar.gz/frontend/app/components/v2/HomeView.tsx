'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import Header from '../Header';
import Footer from '../Footer';
import { useContactForm } from '../../hooks/useContactForm';
import { useAnalytics } from '../../hooks/useAnalytics';
import { getCars } from '../../services/carService';
import { Car } from '../../../types/car';
import {
  CalcButton,
  CityMap,
  CountUp,
  FORM_CITIES,
  Locale,
  STRAPI_URL,
  StarIcon,
  TFn,
  tiltLeave,
  tiltMove,
  useMounted,
  useReveal,
  useSeen,
  useTx,
} from './shared';

const WORKSHOP_URL =
  'https://www.google.com/maps/dir/?api=1&destination=54.43381987085451,18.562095783661377&destination_place_id=ChIJo6cvrcK4yEcRT7OdHV5gh1g&travelmode=driving';

const FILTERS = [
  { id: 'all', label: 'flt_all' },
  { id: 'hyb', label: 'flt_hyb' },
  { id: 'lpg', label: 'flt_lpg' },
] as const;
type FilterId = (typeof FILTERS)[number]['id'];

const APPS = ['Uber', 'Bolt', 'FreeNow', 'iTaxi'];
const APPS_B = ['iTaxi', 'FreeNow', 'Bolt', 'Uber'];
const x4 = <T,>(a: T[]) => a.concat(a, a, a);

const isHybrid = (c: Car) =>
  /hybr/i.test(c.fuelType || '') || /prius/i.test(c.model || '') || [c.feature1, c.feature2, c.feature3].includes('car_hybrid');
const isLpg = (c: Car) => /lpg/i.test(c.fuelType || '');

function carImage(c: Car): string {
  const url = c.image?.formats?.medium?.url || c.image?.url;
  if (!url) return '';
  return /^https?:\/\//.test(url) ? url : `${STRAPI_URL}${url}`;
}

interface HomeViewProps {
  t: TFn;
  translations: Record<string, string>;
  locale: Locale;
  setLocale: (l: Locale) => void;
}

export default function HomeView({ t, translations, locale, setLocale }: HomeViewProps) {
  const tx = useTx(t);
  const mounted = useMounted();
  const rootRef = useRef<HTMLDivElement>(null);
  useReveal(rootRef, mounted);
  const { trackCarClick, trackFormSubmit } = useAnalytics();

  /* ---- hero cursor blob ---- */
  const blobRef = useRef<HTMLDivElement>(null);
  const blobRaf = useRef(0);
  const heroMove = (e: React.MouseEvent<HTMLElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = Math.round(e.clientX - r.left);
    const y = Math.round(e.clientY - r.top);
    if (blobRaf.current) return;
    blobRaf.current = requestAnimationFrame(() => {
      blobRaf.current = 0;
      if (blobRef.current) blobRef.current.style.transform = `translate(${x}px, ${y}px) scale(1)`;
    });
  };
  const heroLeave = () => {
    if (blobRef.current) blobRef.current.style.transform = blobRef.current.style.transform.replace(/scale\([^)]*\)/, 'scale(0)');
  };

  /* ---- requirements road ---- */
  const [roadRef, roadSeen] = useSeen<HTMLDivElement>(0.12);
  const [roadOn, setRoadOn] = useState(true);
  const roadGo = roadSeen && roadOn;
  const replayRoad = () => {
    setRoadOn(false);
    window.setTimeout(() => setRoadOn(true), 80);
  };

  /* ---- tickers ---- */
  const tickerA = useMemo(
    () => x4(['t_48', 't_zero', 't_ref', 'b5h', 't_lic', 'p3h', 't_fuel', 't_mandate', 't_shop', 'ref_k'].map((k) => tx[k])),
    [tx]
  );
  const tickerB = useMemo(
    () =>
      x4(
        ['city_gdansk', 'city_gdynia', 'city_sopot', 'city_rumia', 'city_reda', 'city_kosakowo', 'city_pruszcz']
          .map((k) => tx[k])
          .concat(APPS)
      ),
    [tx]
  );
  const appsLoop = x4(APPS);
  const appsLoopB = x4(APPS_B);

  /* ---- fleet (from Strapi) ---- */
  const [allCars, setAllCars] = useState<Car[]>([]);
  const [filter, setFilter] = useState<FilterId>('all');
  useEffect(() => {
    getCars()
      .then(setAllCars)
      .catch((err) => console.error('Error loading cars:', err));
  }, []);

  const cars = allCars
    .filter((c) => filter === 'all' || (filter === 'hyb' ? isHybrid(c) : isLpg(c)))
    .map((c, i) => {
      const lpg = isLpg(c);
      const fuel = lpg ? tx.fuel_lpg : isHybrid(c) ? tx.fuel_hyb : /benzyn/i.test(c.fuelType || '') ? tx.fuel_pb : c.fuelType;
      const price = c.weeklyPrice >= 1000 ? String(c.weeklyPrice).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') : String(c.weeklyPrice);
      return {
        raw: c,
        id: c.id,
        brand: c.brand,
        model: c.model,
        year: c.year,
        fuel,
        img: carImage(c),
        available: c.available !== false,
        features: [c.feature1, c.feature2, c.feature3].filter(Boolean).map((k) => t(k)),
        price,
        label: `${c.brand} ${c.model} ${c.year || ''} – ${c.weeklyPrice} ${tx.per_week_long}`,
        delay: (i * 0.09).toFixed(2),
      };
    });

  /* ---- contact form ---- */
  const { formData, isSubmitting, isSubmitted, submitError, formErrors, setField, handleInputChange, handleSubmit, resetSubmitted } =
    useContactForm(t, locale, { autoHideMs: 0 });

  const onCarClick = (car: (typeof cars)[number]) => {
    trackCarClick({
      car_brand: car.raw.brand,
      car_model: car.raw.model,
      car_year: car.raw.year,
      weekly_price: car.raw.weeklyPrice,
    });
    if (!formData.comment.trim()) setField('comment', `${tx.interest_car} ${car.brand} ${car.model}`);
  };

  const onSubmit = (e: React.FormEvent) => {
    trackFormSubmit({ form_name: 'contact_form', language: locale, city: formData.city });
    handleSubmit(e);
  };

  return (
    <div className={`sobi p-home intro-on ${mounted ? 'js' : ''}`} ref={rootRef}>
      <div className="intro intro-exit" aria-hidden="true">
        <div className="intro-word">
          <span>S</span>
          <span>O</span>
          <span>B</span>
          <span>I</span>
        </div>
        <div className="intro-bar"><i></i></div>
      </div>

      <Header locale={locale} setLocale={setLocale} translations={translations} current="home" />

      <main>
      {/* ===== HERO ===== */}
      <section id="hero" className="hero" onMouseMove={heroMove} onMouseLeave={heroLeave}>
        <div className="hero-dots" aria-hidden="true"></div>
        <div className="blob" aria-hidden="true" ref={blobRef} style={{ transform: 'translate(0px, 0px) scale(0)' }}></div>
        <div className="hero-in">
          <div className="hero-copy">
            <p className="eyebrow hfu s1"><span className="pulse"></span>{tx.eyebrow}</p>
            <h1 className="h-title">
              <span className="ln"><span className="s2">{tx.h_l1}</span></span>
              <span className="ln"><span className="s3">{tx.h_l2}</span></span>
              <span className="ln"><span className="rot s4"><span className="rot-track"><span>Uber</span><span>Bolt</span><span>FreeNow</span><span>iTaxi</span><span>Uber</span></span></span></span>
            </h1>
            <p className="h-sub hfu s5">{tx.hero_sub}</p>
            <div className="promise hfu s6">
              <div className="pr"><span className="pr-ic" aria-hidden="true"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path className="pr-hand" d="M12 12V6.5"></path><path d="M12 12h3.5"></path></svg></span><div><span className="pr-v">{tx.pr_48}</span><span className="pr-l">{tx.pr_48_l}</span></div></div>
              <div className="pr"><span className="pr-ic pr-coin" aria-hidden="true"><span className="pr-c">0</span></span><div><span className="pr-v">0 zł</span><span className="pr-l">{tx.pr_0_l}</span></div></div>
            </div>
            <div className="h-cta hfu s7">
              <a className="btn btn-dark" href="#contact"><span>{tx.join}</span><span className="arr"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span></a>
              <CalcButton label={tx.calc_btn} />
            </div>
            <a className="cue hfu s8" href="#about"><span className="mouse" aria-hidden="true"></span>{tx.scroll}</a>
          </div>
          <div className="hero-vis">
            <div className="spin-badge" aria-hidden="true">
              <svg viewBox="0 0 150 150">
                <defs><path id="sobi-circ-a" d="M75,75 m-60,0 a60,60 0 1,1 120,0 a60,60 0 1,1 -120,0"></path></defs>
                <text><textPath href="#sobi-circ-a" textLength="372">{tx.badge_ring} </textPath></text>
              </svg>
              <div className="spin-core"><b>6</b><span>{tx.years}</span></div>
            </div>
            <div className="speed" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div>
            <div className="car-wrap"><img src="/cars/toyota-camry-2020.png" alt={tx.alt_camry} /></div>
          </div>
        </div>
        <div className="road" aria-hidden="true"></div>
      </section>

      {/* ===== TAPES ===== */}
      <section className="tapes" aria-label={tx.a_tapes}>
        <div className="tape tape-b" aria-hidden="true">
          <div className="track rev">
            {tickerB.map((item, i) => (
              <span className="ti" key={i}>{item}<StarIcon /></span>
            ))}
          </div>
        </div>
        <div className="tape tape-a">
          <div className="track">
            {tickerA.map((item, i) => (
              <span className="ti" key={i}>{item}<StarIcon /></span>
            ))}
          </div>
        </div>
      </section>

      {/* ===== STATS ===== */}
      <section className="stats" aria-label={tx.a_stats}>
        <div className="wrap">
          <div className="stats-grid rvw" data-rv="stats">
            <div className="stat fu s1"><div className="stat-bar s1"></div><div className="stat-num"><CountUp to={6} /><small>{tx.years}</small></div><p>{tx.st1}</p></div>
            <div className="stat fu s2"><div className="stat-bar s2"></div><div className="stat-num"><CountUp to={4} /><small>{tx.st_apps}</small></div><p>{tx.st2}</p></div>
            <div className="stat fu s3"><div className="stat-bar s3"></div><div className="stat-num"><CountUp to={4} /><small>{tx.st_langs}</small></div><p>{tx.st3}</p></div>
            <div className="stat fu s4"><div className="stat-bar s4"></div><div className="stat-num"><span><CountUp to={24} />/7</span><small>{tx.st_support}</small></div><p>{tx.st4}</p></div>
          </div>
        </div>
      </section>

      {/* ===== CITIES ===== */}
      <section className="lic" aria-labelledby="ct-h">
        <div className="wrap ct-grid">
          <div className="rvw" data-rv="cities">
            <p className="kicker light fu s1">{tx.lic_k}</p>
            <h2 id="ct-h" className="h2 light"><span className="mk s2"><span>{tx.lic_h}</span></span></h2>
            <p className="lead light fu s3">{tx.lic_p}</p>
            <p className="ct-l fu s4">{tx.tricity}</p>
            <ul className="ct-chips">
              <li className="on fu s4">{tx.city_gdansk}</li>
              <li className="on fu s5">{tx.city_gdynia}</li>
              <li className="on fu s5">{tx.city_sopot}</li>
            </ul>
            <p className="ct-l fu s6">{tx.around}</p>
            <ul className="ct-chips">
              <li className="fu s6">{tx.city_rumia}</li>
              <li className="fu s7">{tx.city_reda}</li>
              <li className="fu s7">{tx.city_kosakowo}</li>
              <li className="fu s8">{tx.city_pruszcz}</li>
            </ul>
          </div>
          <div className="ct-map rvw" data-rv="ctmap">
            <CityMap tx={tx} />
          </div>
        </div>
      </section>

      {/* ===== ABOUT / BENEFITS ===== */}
      <section id="about" className="about">
        <div className="wrap">
          <div className="rvw" data-rv="abouthead">
            <p className="kicker fu s1">{tx.k_about}</p>
            <h2 className="h2"><span className="mk s2"><span>{tx.why}</span></span></h2>
            <p className="lead fu s3">{tx.years_exp}</p>
          </div>

          <div className="about-grid">
            <div className="photo rvw" data-rv="photo">
              <div className="photo-clip"><img src="/benefits-photo.jpg" alt={tx.alt_driver} /></div>
              <div className="lang-card">
                <p>{tx.lang_card}</p>
                <div className="chips-cycle"><span>PL</span><span>UA</span><span>RU</span><span>EN</span></div>
              </div>
            </div>

            <div className="bgrid rvw" data-rv="bgrid">
              <div className="bcard fu s1">
                <div className="bcard-top"><span className="bic"><svg className="ic lg" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h8l5 5v13H6z"></path><path d="M14 3v5h5"></path><path d="M9 13h7"></path><path d="M9 17h5"></path></svg></span><span className="bnum">01</span></div>
                <h3>{tx.b1h}</h3>
                <p>{tx.b1p}</p>
              </div>
              <div className="bcard fu s2">
                <div className="bcard-top"><span className="bic"><svg className="ic lg" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3.5l2.6 5.3 5.9.9-4.25 4.1 1 5.8L12 16.9l-5.25 2.7 1-5.8L3.5 9.7l5.9-.9z"></path></svg></span><span className="bnum">02</span></div>
                <h3>{tx.b2h}</h3>
              </div>
              <div className="bcard fu s3">
                <div className="bcard-top"><span className="bic"><svg className="ic lg" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 17H3v-4.5l2-5.5h14l2 5.5V17h-2"></path><path d="M3 12.5h18"></path><circle cx="7.5" cy="17" r="2"></circle><circle cx="16.5" cy="17" r="2"></circle><path d="M9.5 17h5"></path></svg></span><span className="bnum">03</span></div>
                <h3>{tx.b3h}</h3>
                <p>{tx.b3p}</p>
              </div>
              <div className="bcard fu s4">
                <div className="bcard-top"><span className="bic"><svg className="ic lg" viewBox="0 0 24 24" aria-hidden="true"><path d="M14.5 6.5a4 4 0 0 0-5.3 5.3L3.8 17.2a1.6 1.6 0 0 0 2.3 2.3l5.4-5.4a4 4 0 0 0 5.3-5.3l-2.5 2.5-2.1-.3-.3-2.1z"></path></svg></span><span className="bnum">04</span></div>
                <h3>{tx.b4h}</h3>
                <p>{tx.b4p}</p>
              </div>
              <div className="bcard fu s5">
                <div className="bcard-top"><span className="bic"><svg className="ic lg" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="6" width="18" height="13" rx="2.5"></rect><path d="M3 10h18"></path><path d="M15.5 14.5h2.5"></path></svg></span><span className="bnum">05</span></div>
                <h3>{tx.b5h}</h3>
                <p>{tx.b5p}</p>
              </div>
              <div className="bcard fu s6">
                <div className="bcard-top"><span className="bic"><svg className="ic lg" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h11v8H8l-4 3z"></path><path d="M15 9h5v8l-3-2.5h-6V13"></path></svg></span><span className="bnum">06</span></div>
                <h3>{tx.lang_card}</h3>
                <p>{tx.st3}</p>
              </div>
            </div>
          </div>

          <div className="partners rvw" data-rv="partners">
            <div className="partners-head">
              <h3 className="ph fu s1">{tx.partners_h}</h3>
            </div>
            <div className="pgrid">
              <div className="pcard fu s2">
                <span className="pic"><svg className="ic lg" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 20V5a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v15"></path><path d="M3.5 20h12"></path><path d="M7.5 8h4"></path><path d="M14 10h2a1.5 1.5 0 0 1 1.5 1.5V16a1.5 1.5 0 0 0 3 0V8.5L18 6"></path></svg></span>
                <h4>{tx.p1h}</h4>
                <p>{tx.p1p}</p>
              </div>
              <div className="pcard fu s3">
                <span className="pic"><svg className="ic lg" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h8l4 4v6"></path><path d="M6 3v18h7"></path><path d="M9 9h5"></path><path d="M9 13h4"></path><path d="M15 19l2 2 4-4"></path></svg></span>
                <h4>{tx.p2h}</h4>
                <p>{tx.p2p}</p>
              </div>
              <div className="pcard fu s4">
                <span className="pic"><svg className="ic lg" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 14v-2a8 8 0 0 1 16 0v2"></path><rect x="3" y="13" width="4" height="6" rx="1.5"></rect><rect x="17" y="13" width="4" height="6" rx="1.5"></rect><path d="M19 19a3 3 0 0 1-3 3h-3"></path></svg></span>
                <h4>{tx.p3h}</h4>
                <p>{tx.st4}</p>
              </div>
              <div className="pcard fu s5">
                <span className="pic"><svg className="ic lg" viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3.5"></circle><path d="M3 20a6 6 0 0 1 12 0"></path><path d="M19 8v6"></path><path d="M16 11h6"></path></svg></span>
                <h4>{tx.p4h}</h4>
                <p>{tx.p4p}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== APPS ===== */}
      <section className="apps" aria-labelledby="apps-h">
        <div className="wrap rvw" data-rv="apps">
          <p className="kicker light fu s1">{tx.k_apps}</p>
          <h2 id="apps-h" className="h2 light"><span className="mk s2"><span>{tx.apps_h}</span></span></h2>
          <p className="lead light fu s3">{tx.apps_p}</p>
        </div>
        <div className="app-rows" aria-label="Uber, Bolt, FreeNow, iTaxi">
          <div className="app-row o" aria-hidden="true">
            <div className="track">
              {appsLoop.map((a, i) => (
                <span className="aw" key={i}>{a}<StarIcon /></span>
              ))}
            </div>
          </div>
          <div className="app-row f" aria-hidden="true">
            <div className="track rev">
              {appsLoopB.map((a, i) => (
                <span className="aw" key={i}>{a}<StarIcon /></span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ===== REQUIREMENTS ===== */}
      <section id="req" className="req">
        <div className="wrap">
          <div className="rvw" data-rv="reqhead">
            <p className="kicker fu s1">{tx.k_req}</p>
            <h2 className="h2"><span className="mk s2"><span>{tx.req_h}</span></span></h2>
          </div>

          <div className={`road2 ${roadGo ? 'go' : ''}`} ref={roadRef}>
            <div className="lane" aria-hidden="true"><div className="finish"></div></div>
            <div className="rcar" aria-hidden="true">
              <svg viewBox="0 0 96 40">
                <path className="cb" d="M6 28 L6 21 Q6 18 9 17.5 L24 16 L34 8 Q36 6.5 39 6.5 L60 6.5 Q63 6.5 65 8.5 L73 16 L86 17.5 Q91 18.5 91 23 L91 28 Z"></path>
                <path className="cw" d="M37 10 L32.5 16 L48 16 L48 10 Z"></path>
                <path className="cw" d="M51 10 L51 16 L69.5 16 L63 10 Z"></path>
                <rect className="cl" x="86" y="19.5" width="4" height="3" rx="1"></rect>
                <g className="wheel"><circle className="wt" cx="24" cy="29" r="7"></circle><path className="ws" d="M24 23.5 V34.5 M18.5 29 H29.5"></path></g>
                <g className="wheel"><circle className="wt" cx="74" cy="29" r="7"></circle><path className="ws" d="M74 23.5 V34.5 M68.5 29 H79.5"></path></g>
              </svg>
            </div>
            <ol className="stops">
              <li className="stop"><span className="sn">1</span><p>{tx.req_age}</p></li>
              <li className="stop"><span className="sn">2</span><p>{tx.req_lic}</p></li>
              <li className="stop"><span className="sn">3</span><p>{tx.req_crim}</p></li>
              <li className="stop"><span className="sn">4</span><p>{tx.req_med}</p></li>
              <li className="stop"><span className="sn">5</span><p>{tx.req_car}</p></li>
            </ol>
          </div>
          <div className="req-foot">
            <button className="replay" type="button" onClick={replayRoad}><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 12a8 8 0 1 1-2.3-5.6"></path><path d="M20 4v5h-5"></path></svg>{tx.replay}</button>
            <a className="own-link" href="/wlasne-auto/">{tx.own_link}<svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></a>
          </div>
        </div>
      </section>

      {/* ===== FLEET ===== */}
      <section id="fleet" className="fleet">
        <div className="wrap">
          <div className="fleet-head rvw" data-rv="fleethead">
            <div>
              <p className="kicker fu s1">{tx.k_fleet}</p>
              <h2 className="h2"><span className="mk s2"><span>{tx.fleet_h}</span></span></h2>
              <p className="lead fu s3">{tx.fleet_p}</p>
            </div>
            <div className="chips fu s4" role="group" aria-label={tx.a_filter}>
              {FILTERS.map((f) => (
                <button key={f.id} className={`chip ${filter === f.id ? 'on' : ''}`} type="button" aria-pressed={filter === f.id} onClick={() => setFilter(f.id)}>{tx[f.label]}</button>
              ))}
            </div>
          </div>

          <div className="cars" data-rv="cars">
            {cars.map((car) => (
              <a key={car.id} className="car" href="#contact" onClick={() => onCarClick(car)} onMouseMove={tiltMove} onMouseLeave={tiltLeave} style={{ animationDelay: `${car.delay}s` }} aria-label={car.label}>
                <div className="car-top">
                  <span className={`avail ${car.available ? '' : 'off'}`}><i></i>{car.available ? tx.avail : t('car_unavailable')}</span>
                  <span className="car-year">{car.year}</span>
                </div>
                <div className="car-img">
                  <span className="car-lines" aria-hidden="true"><i></i><i></i><i></i></span>
                  {car.img ? (
                    <img src={car.img} alt={car.label} loading="lazy" />
                  ) : (<>
                    <div className="ph-car">
                      <svg viewBox="0 0 300 130" aria-hidden="true">
                        <path className="ph-body" d="M20 100 L16 82 Q16 72 26 69 L74 58 L120 28 Q127 23 137 23 L262 25 Q276 26 280 36 L288 68 Q291 78 288 100 Z"></path>
                        <path className="ph-win" d="M128 34 L92 58 L170 58 L170 34 Z"></path>
                        <path className="ph-win" d="M180 34 L180 58 L272 58 L266 34 Z"></path>
                        <circle className="ph-wh" cx="74" cy="100" r="17"></circle>
                        <circle className="ph-wh" cx="236" cy="100" r="17"></circle>
                      </svg>
                      <span>{tx.ph_photo}</span>
                    </div>
                  </>)}
                </div>
                <div className="car-body">
                  <h3>{car.brand} <span>{car.model}</span></h3>
                  <p className="car-fuel">{car.fuel}</p>
                  <ul className="car-feat">
                    {car.features.map((ft) => (
                      <li key={ft}>{ft}</li>
                    ))}
                  </ul>
                  <div className="car-foot">
                    <p className="price"><b>{car.price}</b> {tx.per_week}</p>
                    <span className="car-go" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ===== WORKSHOP ===== */}
      <section id="workshop" className="shop">
        <svg className="gear g1" viewBox="0 0 240 240" aria-hidden="true"><path d="M216.0,120.0 L235.7,128.8 L233.1,145.8 L211.7,148.4 L206.5,161.7 L220.4,178.2 L210.7,192.3 L190.3,185.4 L179.9,195.1 L185.2,215.9 L170.3,224.5 L154.9,209.4 L141.4,213.6 L137.1,234.7 L120.0,236.0 L112.7,215.7 L98.6,213.6 L85.6,230.8 L69.7,224.5 L71.9,203.1 L60.1,195.1 L41.0,204.9 L29.3,192.3 L40.6,174.0 L33.5,161.7 L12.0,162.2 L6.9,145.8 L25.1,134.2 L24.0,120.0 L4.3,111.2 L6.9,94.2 L28.3,91.6 L33.5,78.3 L19.6,61.8 L29.3,47.7 L49.7,54.6 L60.1,44.9 L54.8,24.1 L69.7,15.5 L85.1,30.6 L98.6,26.4 L102.9,5.3 L120.0,4.0 L127.3,24.3 L141.4,26.4 L154.4,9.2 L170.3,15.5 L168.1,36.9 L179.9,44.9 L199.0,35.1 L210.7,47.7 L199.4,66.0 L206.5,78.3 L228.0,77.8 L233.1,94.2 L214.9,105.8 Z M160,120 A40,40 0 1,0 80,120 A40,40 0 1,0 160,120 Z"></path></svg>
        <svg className="gear g2" viewBox="0 0 160 160" aria-hidden="true"><path d="M142.0,80.0 L155.6,88.1 L152.3,103.5 L136.6,105.3 L130.2,116.4 L136.4,131.0 L124.7,141.5 L110.9,133.8 L99.2,139.0 L95.6,154.4 L80.0,156.0 L73.4,141.6 L60.8,139.0 L48.9,149.4 L35.3,141.5 L38.4,126.0 L29.8,116.4 L14.1,117.9 L7.7,103.5 L19.3,92.8 L18.0,80.0 L4.4,71.9 L7.7,56.5 L23.4,54.7 L29.8,43.6 L23.6,29.0 L35.3,18.5 L49.1,26.2 L60.8,21.0 L64.4,5.6 L80.0,4.0 L86.6,18.4 L99.2,21.0 L111.1,10.6 L124.7,18.5 L121.6,34.0 L130.2,43.6 L145.9,42.1 L152.3,56.5 L140.7,67.2 Z M106,80 A26,26 0 1,0 54,80 A26,26 0 1,0 106,80 Z"></path></svg>
        <div className="wrap">
          <div className="shop-grid">
            <div className="rvw" data-rv="shop">
              <p className="kicker light fu s1">{tx.k_shop}</p>
              <h2 className="h2 light"><span className="mk s2"><span>{tx.shop_h}</span></span></h2>
              <p className="lead light fu s3">{tx.shop_p}</p>
              <ul className="checks">
                <li className="fu s3"><span className="ck"><svg viewBox="0 0 24 24" aria-hidden="true"><path className="ckp" d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span><div><h3>{tx.w1h}</h3><p>{tx.w1p}</p></div></li>
                <li className="fu s4"><span className="ck"><svg viewBox="0 0 24 24" aria-hidden="true"><path className="ckp" d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span><div><h3>{tx.w2h}</h3><p>{tx.w2p}</p></div></li>
                <li className="fu s5"><span className="ck"><svg viewBox="0 0 24 24" aria-hidden="true"><path className="ckp" d="M5 12.5l4.5 4.5L19 7.5"></path></svg></span><div><h3>{tx.w3h}</h3><p>{tx.w3p}</p></div></li>
              </ul>
              <a className="btn btn-light fu s6" href={WORKSHOP_URL} target="_blank" rel="noopener"><span>{tx.maps_btn}</span><span className="arr"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span></a>
            </div>

            <div className="map rvw" data-rv="map">
              <svg className="mapsvg" viewBox="0 0 520 460" aria-hidden="true">
                <g transform="rotate(-8 260 230)">
                  <rect className="m-blk" x="-60" y="-60" width="120" height="110" rx="6"></rect>
                  <rect className="m-blk" x="86" y="74" width="88" height="66" rx="6"></rect>
                  <rect className="m-blk" x="206" y="-60" width="90" height="196" rx="6"></rect>
                  <rect className="m-blk" x="326" y="164" width="84" height="80" rx="6"></rect>
                  <rect className="m-blk" x="86" y="276" width="88" height="70" rx="6"></rect>
                  <rect className="m-blk" x="436" y="40" width="140" height="100" rx="6"></rect>
                  <rect className="m-blk" x="206" y="380" width="200" height="120" rx="6"></rect>
                  <path className="m-st2" d="M-80 60 H600"></path>
                  <path className="m-st2" d="M-80 150 H600"></path>
                  <path className="m-st2" d="M-80 360 H600"></path>
                  <path className="m-st2" d="M70 -80 V560"></path>
                  <path className="m-st2" d="M190 -80 V560"></path>
                  <path className="m-st2" d="M420 -80 V560"></path>
                  <path className="m-st" d="M-80 260 H600"></path>
                  <path className="m-st" d="M310 -80 V560"></path>
                  <path className="m-route" d="M70 520 V360 H190 V260 H310 V150 H372"></path>
                  <circle className="m-car" r="7">
                    <animateMotion dur="7s" repeatCount="indefinite" path="M70 520 V360 H190 V260 H310 V150 H372"></animateMotion>
                  </circle>
                  <circle className="m-pulse" cx="380" cy="150" r="12"></circle>
                  <circle className="m-pulse b" cx="380" cy="150" r="12"></circle>
                  <circle className="m-pin" cx="380" cy="150" r="12"></circle>
                  <circle className="m-pin-in" cx="380" cy="150" r="4.5"></circle>
                </g>
              </svg>
              <a className="map-card" href={WORKSHOP_URL} target="_blank" rel="noopener">
                <div><b>{tx.map_card}</b><span>54.4338° N · 18.5621° E</span></div>
                <span className="map-go" aria-hidden="true"><svg className="ic" viewBox="0 0 24 24"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span>
              </a>
            </div>
          </div>

          <p className="motto rvw" data-rv="motto"><span>{tx.motto1}</span> <span>{tx.motto2}</span></p>
        </div>
      </section>

      {/* ===== REFERRAL ===== */}
      <section id="polecenia" className="ref" aria-labelledby="ref-h">
        <div className="wrap ref-grid rvw" data-rv="ref">
          <div>
            <p className="kicker fu s1">{tx.ref_k}</p>
            <h2 id="ref-h" className="h2"><span className="mk s2"><span>{tx.ref_h}</span></span></h2>
            <p className="lead fu s3">{tx.ref_p}</p>
            <ol className="ref-steps">
              <li className="fu s4"><span className="rs-n">1</span><div><b>{tx.rs1b}</b><span>{tx.rs1s}</span></div></li>
              <li className="fu s5"><span className="rs-n">2</span><div><b>{tx.rs2b}</b><span>{tx.rs2s}</span></div></li>
              <li className="fu s6"><span className="rs-n">3</span><div><b>{tx.rs3b}</b><span>{tx.rs3s}</span></div></li>
            </ol>
            <div className="ref-cta fu s7">
              <a className="btn btn-dark" href="#contact"><span>{tx.ref_btn}</span><span className="arr"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span></a>
              <p className="ref-note">{tx.ref_note}</p>
            </div>
          </div>
          <div className="ref-card fu s3" aria-hidden="true">
            <span className="ref-star rs1"><svg className="ic fill" viewBox="0 0 24 24"><path d="M12 2c.6 5.4 4.6 9.4 10 10-5.4.6-9.4 4.6-10 10-.6-5.4-4.6-9.4-10-10 5.4-.6 9.4-4.6 10-10z"></path></svg></span>
            <span className="ref-star rs2"><svg className="ic fill" viewBox="0 0 24 24"><path d="M12 2c.6 5.4 4.6 9.4 10 10-5.4.6-9.4 4.6-10 10-.6-5.4-4.6-9.4-10-10 5.4-.6 9.4-4.6 10-10z"></path></svg></span>
            <div className="ref-people">
              <div className="pp"><span className="av"><svg className="ic lg" viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.5"></circle><path d="M5 20a7 7 0 0 1 14 0"></path></svg></span><b>{tx.you}</b></div>
              <div className="ref-line"><i className="coin">zł</i></div>
              <div className="pp"><span className="av av2"><svg className="ic lg" viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.5"></circle><path d="M3 20a6 6 0 0 1 12 0"></path><path d="M19 8v6"></path><path d="M16 11h6"></path></svg></span><b>{tx.friend}</b></div>
            </div>
            <div className="ref-amount"><span className="ra-s">{tx.upto}</span><b><CountUp to={500} duration={1800} delay={400} /></b><span className="ra-s">zł</span></div>
            <p className="ref-cap">{tx.ref_cap}</p>
          </div>
        </div>
      </section>

      {/* ===== CONTACT ===== */}
      <section id="contact" className="contact">
        <div className="contact-dots" aria-hidden="true"></div>
        <div className="wrap contact-grid">
          <div className="rvw" data-rv="contact">
            <p className="kicker fu s1">{tx.k_contact}</p>
            <h2 className="h2"><span className="mk s2"><span>{tx.c_h1}</span></span><span className="mk s3"><span>{tx.c_h2}</span></span></h2>
            <p className="lead fu s4">{tx.c_p}</p>
            <div className="phones fu s5">
              <a className="phone" href="tel:+48791798673"><span>+48 791 798 673</span><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></a>
              <a className="phone" href="tel:+48791798685"><span>+48 791 798 685</span><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></a>
            </div>
            <div className="socials fu s6">
              <a href="mailto:sobi.biuro@gmail.com">sobi.biuro@gmail.com</a>
              <a href="https://chat.whatsapp.com/GQxvlaYvnPGLYdrq5nPzws" target="_blank" rel="noopener">WhatsApp</a>
              <a href="https://www.facebook.com/profile.php?id=61589818363226" target="_blank" rel="noopener">Facebook</a>
            </div>
          </div>

          <div className="form-card rvw" data-rv="form">
            {isSubmitted ? (<>
              <div className="done" role="status">
                <div className="done-ring"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"></path></svg></div>
                <h3>{tx.thanks}</h3>
                <button className="back" type="button" onClick={resetSubmitted}>{tx.back}</button>
              </div>
            </>) : null}
            {!isSubmitted ? (<>
              <form onSubmit={onSubmit}>
                <p className="form-title">{tx.join}</p>
                <div className="fgrid">
                  <div className="field"><input id="f-name" name="name" type="text" placeholder=" " required autoComplete="name" value={formData.name} onChange={handleInputChange} /><label htmlFor="f-name">{tx.f_name} <em>*</em></label><span className="uline"></span></div>
                  <div className="field"><input id="f-phone" name="phone" type="tel" placeholder=" " required autoComplete="tel" value={formData.phone} onChange={handleInputChange} aria-invalid={!!formErrors.phone} /><label htmlFor="f-phone">{tx.f_phone} <em>*</em></label><span className="uline"></span>{formErrors.phone ? <span className="ferr">{formErrors.phone}</span> : null}</div>
                  <div className="field full"><input id="f-mail" name="email" type="email" placeholder=" " autoComplete="email" value={formData.email} onChange={handleInputChange} /><label htmlFor="f-mail">Email</label><span className="uline"></span></div>
                </div>
                <p className="city-l" id="city-l">{tx.f_city} <em>*</em></p>
                <div className="cities" role="group" aria-labelledby="city-l">
                  {FORM_CITIES.map((c) => (
                    <button key={c.id} className={`city ${formData.city === c.id ? 'on' : ''}`} type="button" aria-pressed={formData.city === c.id} onClick={() => setField('city', c.id)}>{tx[c.label]}</button>
                  ))}
                </div>
                {formErrors.city ? <p className="ferr">{formErrors.city}</p> : null}
                <div className="field full"><textarea id="f-msg" name="comment" rows={3} placeholder=" " value={formData.comment} onChange={handleInputChange}></textarea><label htmlFor="f-msg">{tx.f_comment}</label><span className="uline"></span></div>
                <div className="form-actions">
                  <button className="btn btn-dark wide" type="submit" disabled={isSubmitting}><span>{isSubmitting ? tx.sending : tx.f_submit}</span><span className="arr"><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg><svg className="ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14"></path><path d="M13 6l6 6-6 6"></path></svg></span></button>
                </div>
                {submitError ? <p className="ferr" role="alert">{submitError}</p> : null}
              </form>
            </>) : null}
          </div>
        </div>
      </section>
      </main>

      <Footer translations={translations} />
    </div>
  );
}
