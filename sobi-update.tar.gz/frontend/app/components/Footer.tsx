'use client';

interface FooterProps {
  translations: Record<string, string>;
}

const Footer = ({ translations }: FooterProps) => {
  const t = (key: string, fallback?: string) => translations[key] || fallback || key;
  const tx = (key: string) => t('ui_' + key);
  const mapsUrl = process.env.NEXT_PUBLIC_MAPS_URL;

  const toTop = (e: React.MouseEvent) => {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="foot">
      <div className="wrap">
        <div className="foot-top">
          <div className="foot-col">
            <h4>{tx('f_address')}</h4>
            <a href={mapsUrl} target="_blank" rel="noopener noreferrer">Aleja Niepodległości 705a/707a</a>
            <a href={mapsUrl} target="_blank" rel="noopener noreferrer">81-853 Sopot</a>
          </div>
          <div className="foot-col">
            <h4>{tx('nav_contact')}</h4>
            <a href="tel:+48791798685">+48 791 798 685</a>
            <a href="tel:+48791798673">+48 791 798 673</a>
            <a href="mailto:sobi.biuro@gmail.com">sobi.biuro@gmail.com</a>
          </div>
          <div className="foot-col">
            <h4>{tx('f_social')}</h4>
            <a href="https://chat.whatsapp.com/GQxvlaYvnPGLYdrq5nPzws" target="_blank" rel="noopener noreferrer">WhatsApp</a>
            <a href="https://www.facebook.com/profile.php?id=61589818363226" target="_blank" rel="noopener noreferrer">Facebook</a>
          </div>
          <a className="totop" href="#" onClick={toTop} aria-label={tx('a_totop')}>
            <svg className="tt" viewBox="0 0 120 120" aria-hidden="true">
              <defs>
                <path id="sobi-circ-b" d="M60,60 m-48,0 a48,48 0 1,1 96,0 a48,48 0 1,1 -96,0"></path>
              </defs>
              <text>
                <textPath href="#sobi-circ-b" textLength="298">{tx('totop_ring')} </textPath>
              </text>
            </svg>
            <span className="tt-core">
              <svg className="ic" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M12 19V5"></path>
                <path d="M6 11l6-6 6 6"></path>
              </svg>
            </span>
          </a>
        </div>
        <div className="giant rvw" data-rv="giant" aria-hidden="true">
          <span>S</span>
          <span>O</span>
          <span>B</span>
          <span>I</span>
        </div>
        <div className="foot-bot">
          <span>{tx('rights')}</span>
          <a href="/privacy-policy/">{t('footer_privacy_policy')}</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
