'use client';

import { useEffect, useRef, useState } from 'react';
import { useAnalytics } from '../hooks/useAnalytics';

type Locale = 'uk' | 'ru' | 'pl' | 'en';

interface HeaderProps {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  translations: Record<string, string>;
  /** Which page is open – highlights the matching menu item. */
  current?: 'home' | 'own' | 'calc' | 'other';
}

const LANGS: { code: Locale; label: string; name: string }[] = [
  { code: 'pl', label: 'PL', name: 'Polski' },
  { code: 'uk', label: 'UA', name: 'Українська' },
  { code: 'ru', label: 'RU', name: 'Русский' },
  { code: 'en', label: 'EN', name: 'English' },
];

const PhoneIcon = () => (
  <svg className="ic" viewBox="0 0 24 24" aria-hidden="true">
    <path d="M5.5 3.5h3.2l1.8 4.6-2.3 1.4a11 11 0 0 0 5.3 5.3l1.4-2.3 4.6 1.8v3.2a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 3.5 5.7a2 2 0 0 1 2-2.2z"></path>
  </svg>
);

const Header = ({ locale, setLocale, translations, current = 'other' }: HeaderProps) => {
  const [langOpen, setLangOpen] = useState(false);
  const [callOpen, setCallOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);
  const callRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const { trackLanguageChange } = useAnalytics();

  const t = (key: string, fallback?: string) => translations[key] || fallback || key;
  const tx = (key: string) => t('ui_' + key);

  // close dropdowns on outside click
  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) setLangOpen(false);
      if (callRef.current && !callRef.current.contains(e.target as Node)) setCallOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, []);

  // scroll progress bar
  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const se = document.scrollingElement || document.documentElement;
        const max = se.scrollHeight - window.innerHeight;
        const p = max > 0 ? Math.max(0, Math.min(1, se.scrollTop / max)) : 0;
        if (progressRef.current) progressRef.current.style.transform = `scaleX(${p.toFixed(4)})`;
      });
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  const pickLang = (lang: Locale, where: string) => {
    trackLanguageChange({ previous_language: locale, new_language: lang, location: where });
    setLocale(lang);
    try {
      localStorage.setItem('sobi-locale', lang);
    } catch {}
    window.dispatchEvent(new CustomEvent('localeChange', { detail: { locale: lang } }));
    try {
      document.documentElement.lang = lang;
    } catch {}
    setLangOpen(false);
  };

  const cur = LANGS.find((l) => l.code === locale) || LANGS[0];
  const links = [
    { href: '/#hero', label: tx('nav_home'), id: 'home' },
    { href: '/#about', label: tx('nav_about'), id: 'about' },
    { href: '/#fleet', label: tx('nav_fleet'), id: 'fleet' },
    { href: '/wlasne-auto/', label: tx('nav_own'), id: 'own' },
    { href: '/#contact', label: tx('nav_contact'), id: 'contact' },
  ];

  return (
    <header className="hdr">
      <div className="hdr-in">
        <a className="logo" href="/" aria-label={tx('a_home')}>
          <span>S</span>
          <span>O</span>
          <span>B</span>
          <span>I</span>
        </a>
        <nav className="nav" aria-label={tx('a_nav')}>
          {links.map((l) => (
            <a key={l.id} href={l.href} className={current === l.id ? 'cur' : undefined} aria-current={current === l.id ? 'page' : undefined}>
              {l.label}
            </a>
          ))}
        </nav>
        <div className="hdr-act">
          <div className="lang-w" ref={callRef}>
            <button className="btn-call" type="button" onClick={() => setCallOpen(!callOpen)} aria-label={tx('call')} aria-expanded={callOpen}>
              <PhoneIcon />
              <span className="call-lbl">{tx('call')}</span>
            </button>
            {callOpen && (
              <ul className="lang-menu call-menu">
                <li>
                  <a className="lang-opt" href="tel:+48791798673" onClick={() => setCallOpen(false)}>
                    <b><PhoneIcon /></b>
                    <span>+48 791 798 673</span>
                  </a>
                </li>
                <li>
                  <a className="lang-opt" href="tel:+48791798685" onClick={() => setCallOpen(false)}>
                    <b><PhoneIcon /></b>
                    <span>+48 791 798 685</span>
                  </a>
                </li>
              </ul>
            )}
          </div>
          <div className="lang-w" ref={langRef}>
            <button className="lang" type="button" onClick={() => setLangOpen(!langOpen)} aria-label={tx('a_lang')} aria-expanded={langOpen}>
              {cur.label}
              <svg className="ic" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M6 9l6 6 6-6"></path>
              </svg>
            </button>
            {langOpen && (
              <ul className="lang-menu">
                {LANGS.map((l) => (
                  <li key={l.code}>
                    <button
                      type="button"
                      className={`lang-opt ${l.code === locale ? 'on' : ''}`}
                      aria-pressed={l.code === locale}
                      onClick={() => pickLang(l.code, 'header_dropdown')}
                    >
                      <b>{l.label}</b>
                      <span>{l.name}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <button className="burger" type="button" onClick={() => setMenuOpen(!menuOpen)} aria-label={tx('a_menu')} aria-expanded={menuOpen}>
            <svg className="ic" viewBox="0 0 24 24" aria-hidden="true">
              <path d="M4 7h16"></path>
              <path d="M4 12h16"></path>
              <path d="M4 17h10"></path>
            </svg>
          </button>
        </div>
      </div>
      <nav className={`mnav ${menuOpen ? 'open' : ''}`} aria-label={tx('a_mnav')}>
        {links.map((l) => (
          <a key={l.id} href={l.href} onClick={() => setMenuOpen(false)}>
            {l.label}
          </a>
        ))}
      </nav>
      <div className="progress" ref={progressRef} style={{ transform: 'scaleX(0)' }}></div>
    </header>
  );
};

export default Header;
