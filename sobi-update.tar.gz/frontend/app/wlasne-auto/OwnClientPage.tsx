'use client';

import OwnView from '../components/v2/OwnView';
import { SobiLoader } from '../components/v2/shared';
import { useTranslations } from '../hooks/useTranslations';

export default function OwnClientPage() {
  const { translations, locale, setLocale, loading, t } = useTranslations();

  if (loading) {
    return <SobiLoader />;
  }

  return <OwnView t={t} translations={translations} locale={locale} setLocale={setLocale} />;
}
