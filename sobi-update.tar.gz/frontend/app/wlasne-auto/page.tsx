import type { Metadata } from 'next';
import OwnClientPage from './OwnClientPage';
import { SITE_URL } from '../utils/site-url';

const title = 'Własne auto – jeździj na swoim aucie z SOBI | Uber, Bolt, FreeNow, iTaxi';
const description =
  'Masz własny samochód? Dołącz do SOBI i jeździj w Uber, Bolt, FreeNow i iTaxi. Sprawdź, czy auto się kwalifikuje, wbij TAXI w dowód – pomożemy z oznakowaniem i wypisem z licencji. Start w 48 godzin.';

export const metadata: Metadata = {
  title,
  description,
  alternates: { canonical: `${SITE_URL}/wlasne-auto/` },
  openGraph: {
    title,
    description,
    url: `${SITE_URL}/wlasne-auto/`,
    siteName: 'SOBI',
    type: 'website',
    locale: 'pl_PL',
  },
};

export default function OwnCarPage() {
  return <OwnClientPage />;
}
