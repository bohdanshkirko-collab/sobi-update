const fs = require('fs');
const path = require('path');

// All translations combined from all scripts
const allTranslations = [
  // From translations-import.json
  {
    "key": "hero_title",
    "section": "hero",
    "uk": "Стань водієм Uber, Bolt",
    "ru": "Стань водителем Uber, Bolt",
    "pl": "Zostań kierowcą Uber, Bolt",
    "en": "Become a Driver with Uber, Bolt"
  },
  {
    "key": "hero_subtitle",
    "section": "hero",
    "uk": "Працюй водієм таксі в Тримісті - та самостійно встановлюй свій графік.",
    "ru": "Работай водителем такси в Труймясто - и сам устанавливай свой график.",
    "pl": "Pracuj jako kierowca TAXI w Trójmieście – sam ustalaj grafik!",
    "en": "Work as a TAXI driver in Tri-City - and set your own schedule."
  },
  {
    "key": "join_sobi",
    "section": "hero",
    "uk": "Приєднуйся до SOBI",
    "ru": "Присоединяйся к SOBI",
    "pl": "Dołącz do Sobi",
    "en": "Join SOBI"
  },
  {
    "key": "why_sobi_title",
    "section": "about",
    "uk": "Чому SOBI?",
    "ru": "Почему SOBI?",
    "pl": "Dlaczego SOBI?",
    "en": "Why SOBI?"
  },
  {
    "key": "years_experience",
    "section": "about",
    "uk": "Уже понад 6 років підтримуємо водіїв у Труймісті",
    "ru": "Уже более 6 лет поддерживаем водителей в Труймясте",
    "pl": "Od 6 lat wspieramy kierowców w Trójmieście",
    "en": "Supporting drivers in the Tri-City area for over 6 years"
  },
  {
    "key": "benefit_experience",
    "section": "benefits",
    "uk": "Допомога в процесі отримання ліцензії — медичні огляди, документи, офіційні формальності",
    "ru": "Поддержка в процессе получения лицензии — медосмотр, документы, формальности в учреждениях",
    "pl": "Wsparcie w procesie licencyjnym — badania, dokumenty, urzędowe formalności",
    "en": "Assistance with the licensing process — medical checks, paperwork, official formalities"
  },
  {
    "key": "benefit_quality",
    "section": "benefits",
    "uk": "Орієнтуємось на якість, а не на швидкість",
    "ru": "Ставим акцент на качество, а не на скорость",
    "pl": "Działamy nie na szybkość a na jakość",
    "en": "Focus on quality, not just speed"
  },
  {
    "key": "benefit_fleet",
    "section": "benefits",
    "uk": "Автопарк на вибір — якщо у тебе немає авто, ти можеш орендувати його у нас",
    "ru": "Автопарк на выбор — если у тебя нет автомобиля, можешь арендовать его у нас",
    "pl": "Flota do wyboru — jeśli nie masz pojazdu, możesz go u nas wynająć",
    "en": "Fleet to choose from — if you don't have a car, you can rent one from us"
  },
  {
    "key": "benefit_workshop",
    "section": "benefits",
    "uk": "Власна автомайстерня — обслуговуємо наші автомобілі та машини водіїв, пропонуємо знижки на запчастини та різні види ремонту для тих, хто працює в SOBI",
    "ru": "Собственная автомастерская — обслуживаем наши автомобили и машины водителей, предоставляем скидки на запчасти и разные виды ремонта для тех, кто работает в SOBI",
    "pl": "Własny warsztat samochodowy – serwisujemy nasze auta i pojazdy kierowców, oferując zniżki na części oraz różnego rodzaje napraw dla osób pracujących w SOBi",
    "en": "Own car workshop — we service our vehicles and drivers' cars, offering discounts on parts and various repairs for SOBI drivers"
  },
  {
    "key": "benefit_payments",
    "section": "benefits",
    "uk": "Щотижневі виплати з зручним розрахунком",
    "ru": "Еженедельные выплаты с удобным расчетом",
    "pl": "Wypłaty co tydzień z wygodnym rozliczeniem",
    "en": "Weekly payouts with easy settlements"
  },
  {
    "key": "benefit_license_support",
    "section": "benefits",
    "uk": "Допомога в процесі отримання ліцензії — медичні огляди, документи, офіційні формальності",
    "ru": "Поддержка в процессе получения лицензии — медосмотр, документы, формальности в учреждениях",
    "pl": "Wsparcie w procesie licencyjnym — badania, dokumenty, urzędowe formalności",
    "en": "Assistance with the licensing process — medical checks, paperwork, official formalities"
  },
  {
    "key": "benefit_languages",
    "section": "benefits",
    "uk": "Контакт твоєю мовою — польська, українська, російська, англійська",
    "ru": "Контакт на твоем языке — польский, украинский, русский, английский",
    "pl": "Kontakt w Twoim języku — polski, ukraiński, rosyjski, angielski",
    "en": "Communication in your language — Polish, Ukrainian, Russian, English"
  },
  {
    "key": "partner_benefits_title",
    "section": "benefits",
    "uk": "Партнерські переваги:",
    "ru": "Партнёрские преимущества:",
    "pl": "Benefity partnerskie:",
    "en": "Partner benefits:"
  },
  {
    "key": "partner_fuel_discount",
    "section": "benefits",
    "uk": "Знижки на пальне завдяки співпраці з MOL Group",
    "ru": "Скидки на топливо благодаря сотрудничеству с MOL Group",
    "pl": "Zniżki na paliwo dzięki współpracy ze stacjami MOL Group",
    "en": "Fuel discounts thanks to cooperation with MOL Group"
    },
  {
    "key": "partner_flexible_cooperation",
    "section": "benefits",
    "uk": "Гнучкі форми співпраці – Цивільно-правовий договір або B2B",
    "ru": "Гибкие формы сотрудничества – Договор подряда или B2B",
    "pl": "Elastyczne formy współpracy – Umowa zlecenie lub B2B",
    "en": "Flexible forms of cooperation – Contract of mandate or B2B"
    },
  {
    "key": "partner_adapted_contracts",
    "section": "benefits",
    "uk": "Договори, адаптовані до твоєї ситуації",
    "ru": "Договоры, адаптированные к твоей ситуации",
    "pl": "Umowy dopasowane do Twojej sytuacji",
    "en": "Contracts tailored to your situation"
  },
  {
    "key": "partner_support_247",
    "section": "benefits",
    "uk": "Підтримка 24/7 — ми доступні телефоном та електронною поштою",
    "ru": "Поддержка 24/7 — мы доступны по телефону и электронной почте",
    "pl": "Wsparcie 24/7 – jesteśmy dostępni przez telefon, mail",
    "en": "24/7 support — available by phone or email"
  },
  {
    "key": "partner_referral",
    "section": "benefits",
    "uk": "Реферальна програма — запрошуй друга та отримуйте бонуси ",
    "ru": "Реферальная программа — пригласи друга и получите бонусы ",
    "pl": "Program rekomendacji, Ty polecasz znajomego zyskujesz bonusy",
    "en": "Referral program — recommend a friend, and you both get bonuses"
  },
  {
    "key": "our_fleet_title",
    "section": "common",
    "uk": "Наш автопарк",
    "ru": "Наш автопарк",
    "pl": "Nasza flota",
    "en": "Our Fleet"
  },
  {
    "key": "requirements_title",
    "section": "requirements",
    "uk": "Які умови потрібно виконати, щоб почати роботу?",
    "ru": "Какие условия нужно выполнить, чтобы начать работу?",
    "pl": "Jakie warunki należy spełnić, żeby zacząć pracę?",
    "en": "What are the requirements to start?"
  },
  {
    "key": "req_age",
    "section": "requirements",
    "uk": "Вік від 18 років",
    "ru": "Возраст от 18 лет",
    "pl": "ukończone 18 lat",
    "en": "Minimum age: 18 years"
  },
  {
    "key": "req_license",
    "section": "requirements",
    "uk": "Польські водійські права",
    "ru": "Польское водительское удостоверение",
    "pl": "polskie prawo jazdy",
    "en": "Valid Polish driving license"
  },
  {
    "key": "req_medical",
    "section": "requirements",
    "uk": "Медична та психологічна довідка для роботи водієм таксі",
    "ru": "Медицинское и психологическое заключение для работы водителем такси",
    "pl": "orzeczenie lekarskie oraz psychologiczne do pracy jako kierowca TAXI",
    "en": "Medical and psychological certificates required for TAXI drivers"
  },
  {
    "key": "req_criminal_record",
    "section": "requirements",
    "uk": "Довідка про несудимість (дійсна 30 днів)",
    "ru": "Справка об отсутствии судимости (действительна 30 дней)",
    "pl": "zaświadczenie o niekaralności ważności 30 dni",
    "en": "Certificate of no criminal record (valid for 30 days)"
  },
  {
    "key": "req_foreign_criminal",
    "section": "requirements",
    "uk": "Якщо ти іноземний громадянин — довідка про несудимість з твоєї країни",
    "ru": "Для иностранных граждан — справка об отсутствии судимости из своей страны",
    "pl": "jeżeli jesteś obywatelem krajów obcych to niekaralność z twojego kraju",
    "en": "If you are a foreign citizen — a certificate of no criminal record from your country"
  },
  {
    "key": "req_car",
    "section": "requirements",
    "uk": "Автомобіль, що відповідає вимогам застосунків — якщо його немає, можна орендувати у нас",
    "ru": "Автомобиль, соответствующий требованиям приложений — если у тебя его нет, можно арендовать у нас",
    "pl": "Samochód spełniający wymagania aplikacji – jeśli go nie masz, możesz wynająć auto u nas",
    "en": "A car that meets app requirements — if you don't have one, you can rent it from us"
  },
  {
    "key": "cta_title",
    "section": "contacts",
    "uk": "Зацікавлений? Є питання?",
    "ru": "Заинтересован? Есть вопросы?",
    "pl": "Jesteś zainteresowany? Masz pytania?",
    "en": "Interested? Have questions?"
  },
  {
    "key": "cta_form",
    "section": "contacts",
    "uk": "Заповни форму або зв'яжися з нами:",
    "ru": "Заполни форму или свяжись с нами:",
    "pl": "To zapraszamy do wypełnienia formularzu lub kontakt na numer:",
    "en": "Fill in the form or contact us:"
  },
  {
    "key": "contact_phones",
    "section": "contacts",
    "uk": "📞 +48 791 798 685 | +48 791 798 673",
    "ru": "📞 +48 791 798 685 | +48 791 798 673",
    "pl": "📞 +48 791 798 685 | +48 791 798 673",
    "en": "📞 +48 791 798 685 | +48 791 798 673"
  },
  {
    "key": "contact_social",
    "section": "contacts",
    "uk": "💬 Telegram, WhatsApp, Facebook",
    "ru": "💬 Telegram, WhatsApp, Facebook",
    "pl": "💬 Telegram, WhatsApp, Facebook",
    "en": "💬 Telegram, WhatsApp, Facebook"
  },
  {
    "key": "form_name",
    "section": "form",
    "uk": "Ім'я",
    "ru": "Имя",
    "pl": "Imię",
    "en": "Name"
  },
  {
    "key": "form_name_placeholder",
    "section": "form",
    "uk": "Ваше ім'я",
    "ru": "Ваше имя",
    "pl": "Twoje imię",
    "en": "Your name"
  },
  {
    "key": "form_phone",
    "section": "form",
    "uk": "Номер телефону",
    "ru": "Номер телефона",
    "pl": "Numer telefonu",
    "en": "Phone number"
  },
  {
    "key": "form_email",
    "section": "form",
    "uk": "Email",
    "ru": "Email",
    "pl": "Email",
    "en": "Email"
  },
  {
    "key": "form_email_placeholder",
    "section": "form",
    "uk": "your@email.com",
    "ru": "your@email.com",
    "pl": "your@email.com",
    "en": "your@email.com"
  },
  {
    "key": "form_city",
    "section": "form",
    "uk": "Місто",
    "ru": "Город",
    "pl": "Miasto",
    "en": "City"
  },
  {
    "key": "form_city_select",
    "section": "form",
    "uk": "Оберіть місто",
    "ru": "Выберите город",
    "pl": "Wybierz miasto",
    "en": "Select city"
  },
  {
    "key": "city_gdansk",
    "section": "form",
    "uk": "Гданськ",
    "ru": "Гданьск",
    "pl": "Gdańsk",
    "en": "Gdańsk"
  },
  {
    "key": "city_gdynia",
    "section": "form",
    "uk": "Гдиня",
    "ru": "Гдыня",
    "pl": "Gdynia",
    "en": "Gdynia"
  },
  {
    "key": "city_sopot",
    "section": "form",
    "uk": "Сопот",
    "ru": "Сопот",
    "pl": "Sopot",
    "en": "Sopot"
  },
  {
    "key": "city_rumia",
    "section": "form",
    "uk": "Румія",
    "ru": "Румия",
    "pl": "Rumia",
    "en": "Rumia"
  },
  {
    "key": "city_reda",
    "section": "form",
    "uk": "Реда",
    "ru": "Реда",
    "pl": "Reda",
    "en": "Reda"
  },
  {
    "key": "city_kosakowo",
    "section": "form",
    "uk": "Косаково",
    "ru": "Косаково",
    "pl": "Kosakowo",
    "en": "Kosakowo"
  },
  {
    "key": "city_pruszcz_gdanski",
    "section": "form",
    "uk": "Прушч-Гданський",
    "ru": "Прущ-Гданьский",
    "pl": "Pruszcz Gdański",
    "en": "Pruszcz Gdański"
  },
  {
    "key": "form_submit",
    "section": "form",
    "uk": "Відправити заявку",
    "ru": "Отправить заявку",
    "pl": "Wyślij zgłoszenie",
    "en": "Submit application"
  },
  {
    "key": "form_submitting",
    "section": "form",
    "uk": "Відправка...",
    "ru": "Отправка...",
    "pl": "Wysyłanie...",
    "en": "Submitting..."
  },
  {
    "key": "form_required",
    "section": "form",
    "uk": "Обов'язкові поля",
    "ru": "Обязательные поля",
    "pl": "Pola obowiązkowe",
    "en": "Required fields"
  },
  {
    "key": "form_success",
    "section": "form",
    "uk": "Дякуємо! Ми зв'яжемося з вами найближчим часом.",
    "ru": "Спасибо! Мы свяжемся с вами в ближайшее время.",
    "pl": "Dziękujemy! Skontaktujemy się z Tobą wkrótce.",
    "en": "Thank you! We will contact you soon."
  },
  {
    "key": "form_comment",
    "section": "form",
    "uk": "Коментар",
    "ru": "Комментарий",
    "pl": "Komentarz",
    "en": "Comment"
  },
  {
    "key": "form_comment_placeholder",
    "section": "form",
    "uk": "Розкажіть нам більше про себе або поставте запитання",
    "ru": "Расскажите нам больше о себе или задайте вопрос",
    "pl": "Opowiedz nam więcej o sobie lub zadaj pytanie",
    "en": "Tell us more about yourself or ask a question"
  },
  {
    "key": "week",
    "section": "fleet",
    "uk": "Тиждень",
    "ru": "Неделя",
    "pl": "Tydzień",
    "en": "Week"
  },
  {
    "key": "car_available",
    "section": "fleet",
    "uk": "В наявності",
    "ru": "В наличии",
    "pl": "Dostępny",
    "en": "Available"
  },
  {
    "key": "car_unavailable",
    "section": "fleet",
    "uk": "Не в наявності",
    "ru": "Нет в наличии",
    "pl": "Niedostępny",
    "en": "Unavailable"
  },
  {
    "key": "our_fleet_subtitle",
    "section": "fleet",
    "uk": "Сучасний автопарк для комфортної роботи",
    "ru": "Современный автопарк для комфортной работы",
    "pl": "Nowoczesna flota dla komfortowej pracy",
    "en": "Modern fleet for comfortable work"
  },
  {
    "key": "car_comfort_class",
    "section": "fleet",
    "uk": "Комфорт клас",
    "ru": "Комфорт класс",
    "pl": "Klasa komfort",
    "en": "Comfort class"
  },
  {
    "key": "car_fuel_efficient",
    "section": "fleet",
    "uk": "Економічна витрата пального",
    "ru": "Экономичный расход топлива",
    "pl": "Ekonomiczne zużycie paliwa",
    "en": "Fuel efficient"
  },
  {
    "key": "car_spacious",
    "section": "fleet",
    "uk": "Простора салон",
    "ru": "Просторный салон",
    "pl": "Przestronne wnętrze",
    "en": "Spacious interior"
  },
  {
    "key": "car_reliable",
    "section": "fleet",
    "uk": "Надійність Toyota",
    "ru": "Надежность Toyota",
    "pl": "Niezawodność Toyota",
    "en": "Toyota reliability"
  },
  {
    "key": "car_comfort",
    "section": "fleet",
    "uk": "Комфортне водіння",
    "ru": "Комфортное вождение",
    "pl": "Komfortowa jazda",
    "en": "Comfortable driving"
  },
  {
    "key": "car_economical",
    "section": "fleet",
    "uk": "Економічність",
    "ru": "Экономичность",
    "pl": "Ekonomiczność",
    "en": "Economical"
  },
  {
    "key": "car_hybrid",
    "section": "fleet",
    "uk": "Гібридна технологія",
    "ru": "Гибридная технология",
    "pl": "Technologia hybrydowa",
    "en": "Hybrid technology"
  },
  {
    "key": "car_fuel_economy",
    "section": "fleet",
    "uk": "Максимальна економія пального",
    "ru": "Максимальная экономия топлива",
    "pl": "Maksymalna oszczędność paliwa",
    "en": "Maximum fuel economy"
  },
  {
    "key": "car_eco_friendly",
    "section": "fleet",
    "uk": "Екологічність",
    "ru": "Экологичность",
    "pl": "Ekologiczny",
    "en": "Eco-friendly"
  },
  {
    "key": "car_proven",
    "section": "fleet",
    "uk": "Перевірена часом",
    "ru": "Проверенная временем",
    "pl": "Sprawdzona w czasie",
    "en": "Time-tested"
  },
  {
    "key": "car_low_maintenance",
    "section": "fleet",
    "uk": "Низькі витрати на обслуговування",
    "ru": "Низкие расходы на обслуживание",
    "pl": "Niskie koszty utrzymania",
    "en": "Low maintenance costs"
  },
  {
    "key": "car_city_driving",
    "section": "fleet",
    "uk": "Ідеальна для міста",
    "ru": "Идеальная для города",
    "pl": "Idealna do miasta",
    "en": "Perfect for city driving"
  },
  {
    "key": "car_modern",
    "section": "fleet",
    "uk": "Сучасний дизайн",
    "ru": "Современный дизайн",
    "pl": "Nowoczesny design",
    "en": "Modern design"
  },
  {
    "key": "car_spacious_trunk",
    "section": "fleet",
    "uk": "Великий багажник",
    "ru": "Большой багажник",
    "pl": "Duży bagażnik",
    "en": "Spacious trunk"
  },
  {
    "key": "car_affordable",
    "section": "fleet",
    "uk": "Доступність обслуговування",
    "ru": "Доступность обслуживания",
    "pl": "Przystępny serwis",
    "en": "Affordable maintenance"
  },
  {
    "key": "car_practical",
    "section": "fleet",
    "uk": "Практичність",
    "ru": "Практичность",
    "pl": "Praktyczność",
    "en": "Practical"
  },
  {
    "key": "car_robust",
    "section": "fleet",
    "uk": "Простота і надійність",
    "ru": "Простота и надежность",
    "pl": "Prostota i niezawodność",
    "en": "Simple and reliable"
  },
  {
    "key": "car_value",
    "section": "fleet",
    "uk": "Оптимальна ціна/якість",
    "ru": "Оптимальная цена/качество",
    "pl": "Optymalna cena/jakość",
    "en": "Best value for money"
  },
  {
    "key": "car_new",
    "section": "fleet",
    "uk": "Нове авто",
    "ru": "Новое авто",
    "pl": "Nowe auto",
    "en": "New car"
  },
  {
    "key": "fleet_cta",
    "section": "fleet",
    "uk": "Обрати авто та почати працювати",
    "ru": "Выбрать авто и начать работать",
    "pl": "Wybierz auto i zacznij pracować",
    "en": "Choose a car and start working"
  },
  {
    "key": "phone_error_required",
    "section": "form",
    "uk": "Номер телефону обов'язковий",
    "ru": "Номер телефона обязателен",
    "pl": "Numer telefonu jest wymagany",
    "en": "Phone number is required"
  },
  {
    "key": "phone_error_format",
    "section": "form",
    "uk": "Введіть коректний польський номер телефону",
    "ru": "Введите корректный польский номер телефона",
    "pl": "Wprowadź prawidłowy polski numer telefonu",
    "en": "Enter a valid Polish phone number"
  },
  {
    "key": "footer_privacy_policy",
    "section": "footer",
    "uk": "Політика конфіденційності",
    "ru": "Политика конфиденциальности",
    "pl": "Polityka prywatności",
    "en": "Privacy Policy"
  },
  {
    "key": "apps_section_title",
    "section": "common",
    "uk": "Працюйте водієм і заробляйте в популярних додатках",
    "ru": "Работайте водителем и зарабатывайте в популярных приложениях",
    "pl": "Pracuj jako kierowca i zarabiaj w popularnych aplikacjach",
    "en": "Work as a driver and earn in popular apps"
  },
  {
    "key": "apps_section_subtitle",
    "section": "common",
    "uk": "Ми співпрацюємо з провідними платформами для максимізації вашого доходу",
    "ru": "Мы сотрудничаем с ведущими платформами для максимизации вашего дохода",
    "pl": "Współpracujemy z wiodącymi platformami, aby zmaksymalizować Twoje zarobki",
    "en": "We partner with leading platforms to maximize your earnings"
  },
  {
    "key": "cta_button_join",
    "section": "hero",
    "uk": "Приєднатися",
    "ru": "Присоединиться",
    "pl": "Dołączyć",
    "en": "Join"
  },
  {
    "key": "cta_button_calculate",
    "section": "hero",
    "uk": "Розрахувати зоробіток",
    "ru": "Рассчитать заработок",
    "pl": "Obliczyć zarobek",
    "en": "Calculate earnings"
  },
  {
    "key": "header_call_button",
    "section": "header",
    "uk": "Зателефонувати",
    "ru": "Позвонить",
    "pl": "Zadzwoń",
    "en": "Call"
  },
  {
    "key": "footer_address_title",
    "section": "footer",
    "uk": "Адреса",
    "ru": "Адрес",
    "pl": "Adres",
    "en": "Address"
  },
  {
    "key": "footer_contact_title",
    "section": "footer",
    "uk": "Контакти",
    "ru": "Контакты",
    "pl": "Kontakt",
    "en": "Contact"
  },
  {
    "key": "footer_social_title",
    "section": "footer",
    "uk": "Соцмережі",
    "ru": "Соцсети",
    "pl": "Media społecznościowe",
    "en": "Social Media"
  },
  {
    "key": "nav_home",
    "section": "header",
    "uk": "Головна",
    "ru": "Главная",
    "pl": "Główna",
    "en": "Home"
  },
  {
    "key": "nav_about",
    "section": "header",
    "uk": "Про компанію",
    "ru": "О компании",
    "pl": "O firmie",
    "en": "About"
  },
  {
    "key": "nav_fleet",
    "section": "header",
    "uk": "Автопарк",
    "ru": "Автопарк",
    "pl": "Flota",
    "en": "Fleet"
  },
  {
    "key": "nav_contact",
    "section": "header",
    "uk": "Контакт",
    "ru": "Контакт",
    "pl": "Kontakt",
    "en": "Contact"
  },
  {
    "key": "form_error",
    "section": "form",
    "uk": "Сталася помилка. Спробуйте ще раз.",
    "ru": "Произошла ошибка. Попробуйте еще раз.",
    "pl": "Wystąpił błąd. Spróbuj ponownie.",
    "en": "An error occurred. Please try again."
  },
  {
    "key": "privacy_analytics_title",
    "section": "privacy",
    "uk": "Аналітика та маркетинг",
    "ru": "Аналитика и маркетинг",
    "pl": "Analityka i marketing",
    "en": "Analytics and Marketing"
  },
  {
    "key": "privacy_analytics_text",
    "section": "privacy",
    "uk": "Ми використовуємо Google Analytics для збору інформації про використання нашого Сервісу. Для покращення точності звітів ми можемо передавати до Google певні дані, надані користувачами (наприклад, адресу електронної пошти або номер телефону). Перед передачею ці дані шифруються (хешуються) та не дозволяють безпосередньо ідентифікувати особу. Google може поєднувати цю інформацію з даними про Ваші відвідування нашого Сервісу та інших сайтів чи додатків для надання нам агрегованої аналітики та для показу персоналізованої реклами. Ви можете відмовитися від збору таких даних через налаштування свого браузера або за допомогою інструментів Google для відмови від аналітики.",
    "ru": "Мы используем Google Analytics для сбора информации об использовании нашего Сервиса. Для улучшения точности отчетов мы можем передавать в Google определенные данные, предоставленные пользователями (например, адрес электронной почты или номер телефона). Перед передачей эти данные шифруются (хешируются) и не позволяют напрямую идентифицировать личность. Google может объединять эту информацию с данными о Ваших посещениях нашего Сервиса и других сайтов или приложений для предоставления нам агрегированной аналитики и для показа персонализированной рекламы. Вы можете отказаться от сбора таких данных через настройки своего браузера или с помощью инструментов Google для отказа от аналитики.",
    "pl": "Używamy Google Analytics do zbierania informacji o korzystaniu z naszego Serwisu. W celu poprawy dokładności raportów możemy przekazywać do Google określone dane podane przez użytkowników (np. adres e-mail lub numer telefonu). Przed przekazaniem dane te są szyfrowane (haszowane) i nie pozwalają na bezpośrednią identyfikację osoby. Google może łączyć te informacje z danymi o Twoich wizytach w naszym Serwisie i innych stronach lub aplikacjach w celu dostarczenia nam zagregowanych analiz i wyświetlania spersonalizowanych reklam. Możesz zrezygnować ze zbierania takich danych poprzez ustawienia przeglądarki lub za pomocą narzędzi Google do rezygnacji z analityki.",
    "en": "We use Google Analytics to collect information about the use of our Service. To improve the accuracy of reports, we may share certain user-provided data with Google (such as email address or phone number). Before transmission, this data is encrypted (hashed) and does not allow direct identification of individuals. Google may combine this information with data about your visits to our Service and other sites or apps to provide us with aggregated analytics and to display personalized advertising. You can opt out of such data collection through your browser settings or using Google's analytics opt-out tools."
  },
  // From privacy-policy-translations.json
  {
    "key": "privacy-policy_title",
    "section": "legal",
    "uk": "Умови використання",
    "ru": "Условия использования",
    "pl": "Regulamin",
    "en": "Terms of Service"
  },
  {
    "key": "privacy-policy_last_updated",
    "section": "legal",
    "uk": "Останнє оновлення: 1 вересня 2025",
    "ru": "Последнее обновление: 1 сентября 2025",
    "pl": "Ostatnia aktualizacja: 1 września 2025",
    "en": "Last updated: September 1, 2025"
  },
  {
    "key": "privacy-policy_section_1_title",
    "section": "legal",
    "uk": "1. Загальні положення",
    "ru": "1. Общие положения",
    "pl": "1. Postanowienia ogólne",
    "en": "1. General Provisions"
  },
  {
    "key": "privacy-policy_section_1_content",
    "section": "legal",
    "uk": "SOBI надає послуги з оренди автомобілів та підтримки водіїв таксі в Гданську та Труймісті. Використовуючи наші послуги, ви погоджуєтесь з цими умовами.",
    "ru": "SOBI предоставляет услуги по аренде автомобилей и поддержке водителей такси в Гданьске и Трёхградье. Используя наши услуги, вы соглашаетесь с этими условиями.",
    "pl": "SOBI świadczy usługi wynajmu samochodów i wsparcia kierowców taxi w Gdańsku i Trójmieście. Korzystając z naszych usług, akceptujesz niniejszy regulamin.",
    "en": "SOBI provides car rental services and taxi driver support in Gdańsk and the Tri-City area. By using our services, you agree to these terms."
  },
  {
    "key": "privacy-policy_section_2_title",
    "section": "legal",
    "uk": "2. Вимоги до водіїв",
    "ru": "2. Требования к водителям",
    "pl": "2. Wymagania dla kierowców",
    "en": "2. Driver Requirements"
  },
  {
    "key": "privacy-policy_section_2_content",
    "section": "legal",
    "uk": "Водій повинен мати: вік від 18 років, дійсне польське водійське посвідчення, медичну та психологічну довідку для водіїв таксі, довідку про несудимість (дійсна 30 днів).",
    "ru": "Водитель должен иметь: возраст от 18 лет, действующее польское водительское удостоверение, медицинское и психологическое заключение для водителей такси, справку об отсутствии судимости (действительна 30 дней).",
    "pl": "Kierowca musi posiadać: ukończone 18 lat, ważne polskie prawo jazdy, orzeczenie lekarskie i psychologiczne dla kierowców taxi, zaświadczenie o niekaralności (ważne 30 dni).",
    "en": "Driver must have: minimum age of 18 years, valid Polish driving license, medical and psychological certificate for taxi drivers, certificate of no criminal record (valid for 30 days)."
  },
  {
    "key": "privacy-policy_section_3_title",
    "section": "legal",
    "uk": "3. Умови оренди автомобіля",
    "ru": "3. Условия аренды автомобиля",
    "pl": "3. Warunki wynajmu samochodu",
    "en": "3. Car Rental Terms"
  },
  {
    "key": "privacy-policy_section_3_content",
    "section": "legal",
    "uk": "Орендар зобов'язується: використовувати автомобіль виключно для роботи в таксі, дотримуватися правил дорожнього руху, своєчасно проходити технічне обслуговування, повідомляти про всі пошкодження та ДТП.",
    "ru": "Арендатор обязуется: использовать автомобиль исключительно для работы в такси, соблюдать правила дорожного движения, своевременно проходить техническое обслуживание, сообщать обо всех повреждениях и ДТП.",
    "pl": "Najemca zobowiązuje się: używać samochodu wyłącznie do pracy w taxi, przestrzegać przepisów ruchu drogowego, terminowo przeprowadzać przeglądy techniczne, zgłaszać wszystkie uszkodzenia i wypadki.",
    "en": "The renter agrees to: use the car exclusively for taxi work, comply with traffic regulations, perform timely maintenance, report all damages and accidents."
  },
  {
    "key": "privacy-policy_section_4_title",
    "section": "legal",
    "uk": "4. Платежі та розрахунки",
    "ru": "4. Платежи и расчеты",
    "pl": "4. Płatności i rozliczenia",
    "en": "4. Payments and Settlements"
  },
  {
    "key": "privacy-policy_section_4_content",
    "section": "legal",
    "uk": "Розрахунки проводяться щотижнево. Водій отримує виплати після вирахування вартості оренди автомобіля та інших узгоджених платежів. Всі платежі здійснюються банківським переказом.",
    "ru": "Расчеты проводятся еженедельно. Водитель получает выплаты после вычета стоимости аренды автомобиля и других согласованных платежей. Все платежи осуществляются банковским переводом.",
    "pl": "Rozliczenia odbywają się co tydzień. Kierowca otrzymuje wypłaty po potrąceniu kosztów wynajmu samochodu i innych uzgodnionych opłat. Wszystkie płatności realizowane są przelewem bankowym.",
    "en": "Settlements are conducted weekly. The driver receives payments after deducting car rental costs and other agreed fees. All payments are made via bank transfer."
  },
  {
    "key": "privacy-policy_section_5_title",
    "section": "legal",
    "uk": "5. Страхування та відповідальність",
    "ru": "5. Страхование и ответственность",
    "pl": "5. Ubezpieczenie i odpowiedzialność",
    "en": "5. Insurance and Liability"
  },
  {
    "key": "privacy-policy_section_5_content",
    "section": "legal",
    "uk": "Всі автомобілі мають обов'язкове страхування OC та AC. Водій несе відповідальність за шкоду, заподіяну через порушення умов договору або недбалість. У разі ДТП водій зобов'язаний негайно повідомити SOBI.",
    "ru": "Все автомобили имеют обязательное страхование OC и AC. Водитель несет ответственность за ущерб, причиненный из-за нарушения условий договора или небрежности. В случае ДТП водитель обязан немедленно уведомить SOBI.",
    "pl": "Wszystkie samochody posiadają obowiązkowe ubezpieczenie OC i AC. Kierowca ponosi odpowiedzialność za szkody spowodowane naruszeniem warunków umowy lub zaniedbaniem. W przypadku wypadku kierowca jest zobowiązany natychmiast powiadomić SOBI.",
    "en": "All cars have mandatory OC and AC insurance. The driver is liable for damage caused by breach of contract or negligence. In case of an accident, the driver must immediately notify SOBI."
  },
  {
    "key": "privacy-policy_section_6_title",
    "section": "legal",
    "uk": "6. Підтримка та сервіс",
    "ru": "6. Поддержка и сервис",
    "pl": "6. Wsparcie i serwis",
    "en": "6. Support and Service"
  },
  {
    "key": "privacy-policy_section_6_content",
    "section": "legal",
    "uk": "SOBI надає цілодобову підтримку водіям. Технічне обслуговування проводиться у власній майстерні. Водії отримують знижки на запчастини та ремонт. Підтримка доступна польською, українською, російською та англійською мовами.",
    "ru": "SOBI предоставляет круглосуточную поддержку водителям. Техническое обслуживание проводится в собственной мастерской. Водители получают скидки на запчасти и ремонт. Поддержка доступна на польском, украинском, русском и английском языках.",
    "pl": "SOBI zapewnia całodobowe wsparcie kierowcom. Obsługa techniczna odbywa się we własnym warsztacie. Kierowcy otrzymują zniżki na części i naprawy. Wsparcie dostępne jest w językach polskim, ukraińskim, rosyjskim i angielskim.",
    "en": "SOBI provides 24/7 support to drivers. Technical service is performed in our own workshop. Drivers receive discounts on parts and repairs. Support is available in Polish, Ukrainian, Russian, and English."
  },
  {
    "key": "privacy-policy_section_7_title",
    "section": "legal",
    "uk": "7. Розірвання договору",
    "ru": "7. Расторжение договора",
    "pl": "7. Rozwiązanie umowy",
    "en": "7. Contract Termination"
  },
  {
    "key": "privacy-policy_section_7_content",
    "section": "legal",
    "uk": "Кожна сторона може розірвати договір з попередженням за 7 днів. У разі порушення умов договору, SOBI має право розірвати договір негайно. Водій зобов'язаний повернути автомобіль у належному стані.",
    "ru": "Каждая сторона может расторгнуть договор с предупреждением за 7 дней. В случае нарушения условий договора, SOBI имеет право расторгнуть договор немедленно. Водитель обязан вернуть автомобиль в надлежащем состоянии.",
    "pl": "Każda strona może rozwiązać umowę z 7-dniowym wypowiedzeniem. W przypadku naruszenia warunków umowy, SOBI ma prawo rozwiązać umowę ze skutkiem natychmiastowym. Kierowca jest zobowiązany zwrócić samochód w należytym stanie.",
    "en": "Either party may terminate the contract with 7 days notice. In case of breach of contract terms, SOBI has the right to terminate the contract immediately. The driver must return the car in proper condition."
  },
  {
    "key": "privacy-policy_section_8_title",
    "section": "legal",
    "uk": "8. Захист персональних даних",
    "ru": "8. Защита персональных данных",
    "pl": "8. Ochrona danych osobowych",
    "en": "8. Personal Data Protection"
  },
  {
    "key": "privacy-policy_section_8_content",
    "section": "legal",
    "uk": "SOBI обробляє персональні дані відповідно до GDPR та польського законодавства. Дані використовуються виключно для надання послуг та не передаються третім особам без згоди водія.",
    "ru": "SOBI обрабатывает персональные данные в соответствии с GDPR и польским законодательством. Данные используются исключительно для предоставления услуг и не передаются третьим лицам без согласия водителя.",
    "pl": "SOBI przetwarza dane osobowe zgodnie z GDPR i polskim prawem. Dane są wykorzystywane wyłącznie do świadczenia usług i nie są przekazywane osobom trzecim bez zgody kierowcy.",
    "en": "SOBI processes personal data in accordance with GDPR and Polish law. Data is used exclusively for service provision and is not shared with third parties without driver consent."
  },
  {
    "key": "privacy-policy_section_9_title",
    "section": "legal",
    "uk": "9. Зміни в умовах",
    "ru": "9. Изменения в условиях",
    "pl": "9. Zmiany w regulaminie",
    "en": "9. Changes to Terms"
  },
  {
    "key": "privacy-policy_section_9_content",
    "section": "legal",
    "uk": "SOBI залишає за собою право змінювати ці умови. Про всі зміни водії будуть повідомлені за 14 днів до їх вступу в силу через електронну пошту або SMS.",
    "ru": "SOBI оставляет за собой право изменять эти условия. Обо всех изменениях водители будут уведомлены за 14 дней до их вступления в силу через электронную почту или SMS.",
    "pl": "SOBI zastrzega sobie prawo do zmiany niniejszego regulaminu. O wszystkich zmianach kierowcy zostaną powiadomieni na 14 dni przed ich wejściem w życie poprzez e-mail lub SMS.",
    "en": "SOBI reserves the right to modify these terms. Drivers will be notified of all changes 14 days before they take effect via email or SMS."
  },
  {
    "key": "privacy-policy_section_10_title",
    "section": "legal",
    "uk": "10. Контактна інформація",
    "ru": "10. Контактная информация",
    "pl": "10. Dane kontaktowe",
    "en": "10. Contact Information"
  },
  {
    "key": "privacy-policy_section_10_content",
    "section": "legal",
    "uk": "SOBI Sp. z o.o., Гданськ, Польща. Телефон: +48 791 798 685, +48 791 798 673. Підтримка доступна 24/7 через телефон, Telegram, WhatsApp та Facebook.",
    "ru": "SOBI Sp. z o.o., Гданьск, Польша. Телефон: +48 791 798 685, +48 791 798 673. Поддержка доступна 24/7 через телефон, Telegram, WhatsApp и Facebook.",
    "pl": "SOBI Sp. z o.o., Gdańsk, Polska. Telefon: +48 791 798 685, +48 791 798 673. Wsparcie dostępne 24/7 przez telefon, Telegram, WhatsApp i Facebook.",
    "en": "SOBI Sp. z o.o., Gdańsk, Poland. Phone: +48 791 798 685, +48 791 798 673. Support available 24/7 via phone, Telegram, WhatsApp, and Facebook."
  },
  {
    "key": "privacy-policy_accept",
    "section": "legal",
    "uk": "Приймаю умови",
    "ru": "Принимаю условия",
    "pl": "Akceptuję regulamin",
    "en": "I accept the terms"
  },
  {
    "key": "privacy-policy_decline",
    "section": "legal",
    "uk": "Відхилити",
    "ru": "Отклонить",
    "pl": "Odrzuć",
    "en": "Decline"
  },
  {
    "key": "cookie_message",
    "section": "legal",
    "uk": "Цей сайт використовує cookies для покращення користувацького досвіду. Переглянути нашу",
    "ru": "Этот сайт использует cookies для улучшения пользовательского опыта. Просмотреть нашу",
    "pl": "Ta strona używa cookies w celu poprawy doświadczenia użytkownika. Zobacz naszą",
    "en": "This site uses cookies to improve user experience. View our"
  },
  {
    "key": "cookie_privacy_link",
    "section": "legal",
    "uk": "Політику конфіденційності",
    "ru": "Политику конфиденциальности",
    "pl": "Politykę prywatności",
    "en": "Privacy Policy"
  },
  {
    "key": "cookie_accept_button",
    "section": "legal",
    "uk": "Прийняти",
    "ru": "Принять",
    "pl": "Akceptuję",
    "en": "Accept"
  },
  {
    "key": "cookie_decline_button",
    "section": "legal",
    "uk": "Відхилити",
    "ru": "Отклонить",
    "pl": "Odrzuć",
    "en": "Decline"
  },
  // From workshop-translations.js
  {
    "key": "workshop_title",
    "section": "benefits",
    "uk": "Власна автомайстерня для водіїв",
    "ru": "Собственный автосервис для водителей",
    "pl": "Własny warsztat samochodowy dla naszych kierowców",
    "en": "Our own car workshop for drivers"
  },
  {
    "key": "workshop_priority_service",
    "section": "benefits",
    "uk": "Обслуговування без черги",
    "ru": "Обслуживание без очереди",
    "pl": "Obsługa bez kolejki",
    "en": "Priority service"
  },
  {
    "key": "workshop_priority_description",
    "section": "benefits",
    "uk": "автопарк і приватні авто водіїв",
    "ru": "автопарк и личные авто водителей",
    "pl": "flotowe i prywatne auta kierowców",
    "en": "fleet and private cars of our drivers"
  },
  {
    "key": "workshop_discounts",
    "section": "benefits",
    "uk": "Знижки на запчастини та ремонт",
    "ru": "Скидки на запчасти и ремонт",
    "pl": "Zniżki na części i naprawy",
    "en": "Discounts on parts and repairs"
  },
  {
    "key": "workshop_discounts_description",
    "section": "benefits",
    "uk": "Спеціальні ціни для наших водіїв на всі види робіт",
    "ru": "Специальные цены для наших водителей на все виды работ",
    "pl": "Specjalne ceny dla naszych kierowców na wszystkie rodzaje prac",
    "en": "Special prices for our drivers on all types of work"
  },
  {
    "key": "workshop_full_service",
    "section": "benefits",
    "uk": "Повний сервіс автопарку",
    "ru": "Полный сервис автопарка",
    "pl": "Pełny serwis flotowy",
    "en": "Full fleet service"
  },
  {
    "key": "workshop_full_service_description",
    "section": "benefits",
    "uk": "заміна лампочок, двірників, шин, поточний ремонт",
    "ru": "замена лампочек, дворников, шин, текущий ремонт",
    "pl": "wymiana żarówek, wycieraczek, opon, naprawy bieżące",
    "en": "bulb replacement, wipers, tire repairs, regular maintenance"
  },
  {
    "key": "workshop_motto",
    "section": "benefits",
    "uk": "Ти лише їздиш і заробляєш – ми дбаємо про все інше!",
    "ru": "Ты только ездишь и зарабатываешь – мы заботимся обо всём остальном!",
    "pl": "Ty tylko jeździsz i zarabiasz – my dbamy o resztę!",
    "en": "You just drive and earn – we take care of the rest!"
  },
  {
    "key": "workshop_maps_button",
    "section": "benefits",
    "uk": "Google Maps майстерня",
    "ru": "Google Maps сервис",
    "pl": "Warsztat Google Maps",
    "en": "Workshop Google Maps"
  },
  {
    "key": "workshop_image_placeholder",
    "section": "benefits",
    "uk": "Фото майстерні",
    "ru": "Фото сервиса",
    "pl": "Zdjęcie warsztatu",
    "en": "Workshop Image"
  },
  // Additional privacy-policy translations from the more detailed file
  {
    "key": "privacy-policy_section1_title",
    "section": "privacy-policy",
    "uk": "1. Загальні положення",
    "ru": "1. Общие положения",
    "pl": "1. Postanowienia ogólne",
    "en": "1. General Provisions"
  },
  {
    "key": "privacy-policy_section1_content",
    "section": "privacy-policy",
    "uk": "Ці Умови надання послуг регулюють відносини між SOBI (\"Компанія\") та водіями (\"Партнери\"), які використовують нашу платформу для надання послуг таксі в районі Труймістя (Гданськ, Гдиня, Сопот).",
    "ru": "Эти Условия предоставления услуг регулируют отношения между SOBI (\"Компания\") и водителями (\"Партнеры\"), которые используют нашу платформу для предоставления услуг такси в районе Трехградья (Гданьск, Гдыня, Сопот).",
    "pl": "Niniejsze Warunki świadczenia usług regulują relacje między SOBI (\"Firma\") a kierowcami (\"Partnerami\"), którzy korzystają z naszej platformy do świadczenia usług taksówkarskich w Trójmieście (Gdańsk, Gdynia, Sopot).",
    "en": "These Terms of Service govern the relationship between SOBI (\"Company\") and drivers (\"Partners\") who use our platform to provide taxi services in the Tricity area (Gdańsk, Gdynia, Sopot)."
  },
  {
    "key": "privacy-policy_section2_title",
    "section": "privacy-policy",
    "uk": "2. Вимоги до партнерства",
    "ru": "2. Требования к партнерству",
    "pl": "2. Wymagania partnerstwa",
    "en": "2. Partnership Requirements"
  },
  {
    "key": "privacy-policy_req1",
    "section": "privacy-policy",
    "uk": "Мінімальний вік 21 рік",
    "ru": "Минимальный возраст 21 год",
    "pl": "Minimalny wiek 21 lat",
    "en": "Minimum age of 21 years"
  },
  {
    "key": "privacy-policy_req2",
    "section": "privacy-policy",
    "uk": "Дійсне польське водійське посвідчення (категорія B) не менше 2 років",
    "ru": "Действительное польское водительское удостоверение (категория B) не менее 2 лет",
    "pl": "Ważne polskie prawo jazdy (kategoria B) od co najmniej 2 lat",
    "en": "Valid Polish driving license (category B) for at least 2 years"
  },
  {
    "key": "privacy-policy_req3",
    "section": "privacy-policy",
    "uk": "Дійсна ліцензія таксі або готовність її отримати",
    "ru": "Действующая лицензия такси или готовность ее получить",
    "pl": "Ważna licencja taxi lub gotowość do jej uzyskania",
    "en": "Valid taxi license or willingness to obtain one"
  },
  {
    "key": "privacy-policy_req4",
    "section": "privacy-policy",
    "uk": "Відсутність судимості",
    "ru": "Отсутствие судимости",
    "pl": "Niekaralność",
    "en": "Clean criminal record"
  },
  {
    "key": "privacy-policy_req5",
    "section": "privacy-policy",
    "uk": "Дійсна медична довідка для професійних водіїв",
    "ru": "Действительная медицинская справка для профессиональных водителей",
    "pl": "Ważne orzeczenie lekarskie dla kierowców zawodowych",
    "en": "Valid medical certificate for professional drivers"
  },
  {
    "key": "privacy-policy_req6",
    "section": "privacy-policy",
    "uk": "Автомобіль, що відповідає стандартам компанії (при використанні власного транспорту)",
    "ru": "Автомобиль, соответствующий стандартам компании (при использовании собственного транспорта)",
    "pl": "Pojazd spełniający standardy firmy (w przypadku korzystania z własnego pojazdu)",
    "en": "Vehicle meeting company standards (if using own vehicle)"
  },
  {
    "key": "privacy-policy_section3_title",
    "section": "privacy-policy",
    "uk": "3. Комісії та платежі",
    "ru": "3. Комиссии и платежи",
    "pl": "3. Prowizje i płatności",
    "en": "3. Commission and Payments"
  },
  {
    "key": "privacy-policy_section3_content1",
    "section": "privacy-policy",
    "uk": "Компанія стягує комісію за використання платформи та автомобілів флоту. Розмір комісії залежить від обраної моделі співпраці:",
    "ru": "Компания взимает комиссию за использование платформы и автомобилей флота. Размер комиссии зависит от выбранной модели сотрудничества:",
    "pl": "Firma pobiera prowizję za korzystanie z platformy i pojazdów floty. Wysokość prowizji zależy od wybranego modelu współpracy:",
    "en": "The Company charges a commission for using the platform and fleet vehicles. The commission rate depends on the cooperation model chosen:"
  },
  {
    "key": "privacy-policy_commission1",
    "section": "privacy-policy",
    "uk": "Використання автомобіля компанії: 45% від валового заробітку",
    "ru": "Использование автомобиля компании: 45% от валового заработка",
    "pl": "Korzystanie z pojazdu firmowego: 45% zarobków brutto",
    "en": "Using company vehicle: 45% of gross earnings"
  },
  {
    "key": "privacy-policy_commission2",
    "section": "privacy-policy",
    "uk": "Використання власного автомобіля: 10-15% від валового заробітку",
    "ru": "Использование собственного автомобиля: 10-15% от валового заработка",
    "pl": "Korzystanie z własnego pojazdu: 10-15% zarobków brutto",
    "en": "Using own vehicle: 10-15% of gross earnings"
  },
  {
    "key": "privacy-policy_section3_content2",
    "section": "privacy-policy",
    "uk": "Розрахунки проводяться щотижня. Партнери отримують детальні звіти про свої заробітки та відрахування.",
    "ru": "Расчеты производятся еженедельно. Партнеры получают детальные отчеты о своих заработках и отчислениях.",
    "pl": "Rozliczenia odbywają się co tydzień. Partnerzy otrzymują szczegółowe raporty o swoich zarobkach i potrąceniach.",
    "en": "Settlements are made weekly. Partners receive detailed reports of their earnings and deductions."
  },
  {
    "key": "privacy-policy_section4_title",
    "section": "privacy-policy",
    "uk": "4. Умови використання транспорту",
    "ru": "4. Условия использования транспорта",
    "pl": "4. Warunki korzystania z pojazdów",
    "en": "4. Vehicle Usage Terms"
  },
  {
    "key": "privacy-policy_section4_content1",
    "section": "privacy-policy",
    "uk": "Партнери, які використовують транспортні засоби компанії, відповідають за:",
    "ru": "Партнеры, использующие транспортные средства компании, отвечают за:",
    "pl": "Partnerzy korzystający z pojazdów firmowych są odpowiedzialni za:",
    "en": "Partners using company vehicles are responsible for:"
  },
  {
    "key": "privacy-policy_vehicle1",
    "section": "privacy-policy",
    "uk": "Підтримання чистоти автомобіля",
    "ru": "Поддержание чистоты автомобиля",
    "pl": "Utrzymanie czystości pojazdu",
    "en": "Maintaining vehicle cleanliness"
  },
  {
    "key": "privacy-policy_vehicle2",
    "section": "privacy-policy",
    "uk": "Негайне повідомлення про будь-які пошкодження або технічні проблеми",
    "ru": "Немедленное сообщение о любых повреждениях или технических проблемах",
    "pl": "Natychmiastowe zgłaszanie wszelkich uszkodzeń lub problemów technicznych",
    "en": "Reporting any damage or technical issues immediately"
  },
  {
    "key": "privacy-policy_vehicle3",
    "section": "privacy-policy",
    "uk": "Дотримання графіка технічного обслуговування",
    "ru": "Соблюдение графика технического обслуживания",
    "pl": "Przestrzeganie harmonogramu konserwacji",
    "en": "Following the maintenance schedule"
  },
  {
    "key": "privacy-policy_vehicle4",
    "section": "privacy-policy",
    "uk": "Використання транспортних засобів лише для дозволених ділових цілей",
    "ru": "Использование транспортных средств только для разрешенных деловых целей",
    "pl": "Używanie pojazdów wyłącznie do autoryzowanych celów biznesowych",
    "en": "Using vehicles only for authorized business purposes"
  },
  {
    "key": "privacy-policy_vehicle5",
    "section": "privacy-policy",
    "uk": "Повернення автомобіля з тим же рівнем палива, що й при отриманні",
    "ru": "Возврат автомобиля с тем же уровнем топлива, что и при получении",
    "pl": "Zwrot pojazdu z takim samym poziomem paliwa jak przy odbiorze",
    "en": "Returning the vehicle with the same fuel level as received"
  },
  {
    "key": "privacy-policy_section5_title",
    "section": "privacy-policy",
    "uk": "5. Обов'язки партнерів",
    "ru": "5. Обязанности партнеров",
    "pl": "5. Obowiązki partnerów",
    "en": "5. Partner Obligations"
  },
  {
    "key": "privacy-policy_obligation1",
    "section": "privacy-policy",
    "uk": "Підтримувати професійний зовнішній вигляд та поведінку",
    "ru": "Поддерживать профессиональный внешний вид и поведение",
    "pl": "Utrzymywać profesjonalny wygląd i zachowanie",
    "en": "Maintain professional appearance and behavior"
  },
  {
    "key": "privacy-policy_obligation2",
    "section": "privacy-policy",
    "uk": "Надавати безпечне та ввічливе обслуговування пасажирам",
    "ru": "Предоставлять безопасное и вежливое обслуживание пассажирам",
    "pl": "Zapewniać bezpieczną i uprzejmą obsługę pasażerów",
    "en": "Provide safe and courteous service to passengers"
  },
  {
    "key": "privacy-policy_obligation3",
    "section": "privacy-policy",
    "uk": "Дотримуватися всіх правил дорожнього руху та регламентів",
    "ru": "Соблюдать все правила дорожного движения и регламенты",
    "pl": "Przestrzegać wszystkich przepisów ruchu drogowego i regulacji",
    "en": "Follow all traffic laws and regulations"
  },
  {
    "key": "privacy-policy_obligation4",
    "section": "privacy-policy",
    "uk": "Підтримувати мінімальний рейтинг 4.5 в додатках платформи",
    "ru": "Поддерживать минимальный рейтинг 4.5 в приложениях платформы",
    "pl": "Utrzymywać minimalną ocenę 4.5 w aplikacjach platformy",
    "en": "Maintain minimum 4.5 rating on platform apps"
  },
  {
    "key": "privacy-policy_obligation5",
    "section": "privacy-policy",
    "uk": "Виконувати мінімум 20 годин на тиждень (для партнерів на повний робочий день)",
    "ru": "Выполнять минимум 20 часов в неделю (для партнеров на полный рабочий день)",
    "pl": "Realizować minimum 20 godzin tygodniowo (dla partnerów pełnoetatowych)",
    "en": "Complete minimum 20 hours per week (for full-time partners)"
  },
  {
    "key": "privacy-policy_obligation6",
    "section": "privacy-policy",
    "uk": "Відвідувати обов'язкові навчальні сесії",
    "ru": "Посещать обязательные учебные сессии",
    "pl": "Uczestniczyć w wymaganych sesjach szkoleniowych",
    "en": "Attend required training sessions"
  },
  {
    "key": "privacy-policy_section6_title",
    "section": "privacy-policy",
    "uk": "6. Страхування та відповідальність",
    "ru": "6. Страхование и ответственность",
    "pl": "6. Ubezpieczenie i odpowiedzialność",
    "en": "6. Insurance and Liability"
  },
  {
    "key": "privacy-policy_section6_content",
    "section": "privacy-policy",
    "uk": "Компанія надає комплексне страхування для транспортних засобів компанії. Партнери несуть відповідальність за будь-які збитки, спричинені недбалістю або порушенням цих умов. Партнери, які використовують власні транспортні засоби, повинні мати відповідне комерційне страхування.",
    "ru": "Компания предоставляет комплексное страхование для транспортных средств компании. Партнеры несут ответственность за любые убытки, причиненные небрежностью или нарушением этих условий. Партнеры, использующие собственные транспортные средства, должны иметь соответствующее коммерческое страхование.",
    "pl": "Firma zapewnia kompleksowe ubezpieczenie pojazdów firmowych. Partnerzy ponoszą odpowiedzialność za wszelkie szkody spowodowane zaniedbaniem lub naruszeniem niniejszych warunków. Partnerzy korzystający z własnych pojazdów muszą posiadać odpowiednie ubezpieczenie komercyjne.",
    "en": "The Company provides comprehensive insurance for company vehicles. Partners are responsible for any damages caused by negligence or violation of these terms. Partners using their own vehicles must maintain appropriate commercial insurance."
  },
  {
    "key": "privacy-policy_section7_title",
    "section": "privacy-policy",
    "uk": "7. Захист даних",
    "ru": "7. Защита данных",
    "pl": "7. Ochrona danych",
    "en": "7. Data Protection"
  },
  {
    "key": "privacy-policy_section7_content",
    "section": "privacy-policy",
    "uk": "Компанія обробляє персональні дані відповідно до регламенту GDPR. Партнери погоджуються на обробку своїх даних для бізнес-операцій, включаючи моніторинг продуктивності та обробку платежів.",
    "ru": "Компания обрабатывает персональные данные в соответствии с регламентом GDPR. Партнеры соглашаются на обработку своих данных для бизнес-операций, включая мониторинг производительности и обработку платежей.",
    "pl": "Firma przetwarza dane osobowe zgodnie z rozporządzeniem RODO. Partnerzy wyrażają zgodę na przetwarzanie swoich danych do celów operacji biznesowych, w tym monitorowania wydajności i przetwarzania płatności.",
    "en": "The Company processes personal data in accordance with GDPR regulations. Partners agree to the processing of their data for business operations, including performance monitoring and payment processing."
  },
  {
    "key": "privacy-policy_section8_title",
    "section": "privacy-policy",
    "uk": "8. Припинення співпраці",
    "ru": "8. Прекращение сотрудничества",
    "pl": "8. Rozwiązanie współpracy",
    "en": "8. Termination"
  },
  {
    "key": "privacy-policy_section8_content1",
    "section": "privacy-policy",
    "uk": "Будь-яка сторона може припинити партнерство з попередженням за 14 днів. Негайне припинення може відбутися у випадках:",
    "ru": "Любая сторона может прекратить партнерство с уведомлением за 14 дней. Немедленное прекращение может произойти в случаях:",
    "pl": "Każda ze stron może rozwiązać partnerstwo z 14-dniowym wypowiedzeniem. Natychmiastowe rozwiązanie może nastąpić w przypadkach:",
    "en": "Either party may terminate the partnership with 14 days notice. Immediate termination may occur in cases of:"
  },
  {
    "key": "privacy-policy_termination1",
    "section": "privacy-policy",
    "uk": "Серйозне порушення цих умов",
    "ru": "Серьезное нарушение этих условий",
    "pl": "Poważne naruszenie niniejszych warunków",
    "en": "Serious violation of these terms"
  },
  {
    "key": "privacy-policy_termination2",
    "section": "privacy-policy",
    "uk": "Кримінальна діяльність",
    "ru": "Криминальная деятельность",
    "pl": "Działalność przestępcza",
    "en": "Criminal activity"
  },
  {
    "key": "privacy-policy_termination3",
    "section": "privacy-policy",
    "uk": "Повторні скарги клієнтів",
    "ru": "Повторные жалобы клиентов",
    "pl": "Powtarzające się skargi klientów",
    "en": "Repeated customer complaints"
  },
  {
    "key": "privacy-policy_termination4",
    "section": "privacy-policy",
    "uk": "Пошкодження майна компанії через недбалість",
    "ru": "Повреждение имущества компании из-за небрежности",
    "pl": "Uszkodzenie mienia firmy z powodu zaniedbania",
    "en": "Damage to company property due to negligence"
  },
  {
    "key": "privacy-policy_termination5",
    "section": "privacy-policy",
    "uk": "Порушення політики платформ (Uber, Bolt)",
    "ru": "Нарушение политики платформ (Uber, Bolt)",
    "pl": "Naruszenie polityki platform (Uber, Bolt)",
    "en": "Violation of platform policies (Uber, Bolt)"
  },
  {
    "key": "privacy-policy_section9_title",
    "section": "privacy-policy",
    "uk": "9. Вирішення спорів",
    "ru": "9. Разрешение споров",
    "pl": "9. Rozwiązywanie sporów",
    "en": "9. Dispute Resolution"
  },
  {
    "key": "privacy-policy_section9_content",
    "section": "privacy-policy",
    "uk": "Будь-які спори, що виникають з цієї угоди, вирішуються шляхом переговорів. Якщо переговори не вдаються, спори вирішуються компетентним судом у Сопоті, Польща.",
    "ru": "Любые споры, возникающие из этого соглашения, разрешаются путем переговоров. Если переговоры не удаются, споры разрешаются компетентным судом в Сопоте, Польша.",
    "pl": "Wszelkie spory wynikające z niniejszej umowy będą rozwiązywane w drodze negocjacji. Jeśli negocjacje nie powiodą się, spory będą rozstrzygane przez właściwy sąd w Sopocie, Polska.",
    "en": "Any disputes arising from this agreement shall be resolved through negotiation. If negotiation fails, disputes will be settled by the competent court in Sopot, Poland."
  },
  {
    "key": "privacy-policy_section10_title",
    "section": "privacy-policy",
    "uk": "10. Зміни",
    "ru": "10. Изменения",
    "pl": "10. Zmiany",
    "en": "10. Amendments"
  },
  {
    "key": "privacy-policy_section10_content",
    "section": "privacy-policy",
    "uk": "Компанія залишає за собою право вносити зміни до цих умов з попередженням партнерів за 30 днів. Продовження партнерства після дати внесення змін означає прийняття нових умов.",
    "ru": "Компания оставляет за собой право вносить изменения в эти условия с уведомлением партнеров за 30 дней. Продолжение партнерства после даты внесения изменений означает принятие новых условий.",
    "pl": "Firma zastrzega sobie prawo do zmiany niniejszych warunków z 30-dniowym powiadomieniem partnerów. Kontynuacja partnerstwa po dacie zmiany oznacza akceptację nowych warunków.",
    "en": "The Company reserves the right to amend these terms with 30 days notice to partners. Continued partnership after the amendment date constitutes acceptance of the new terms."
  },
  {
    "key": "privacy-policy_section11_title",
    "section": "privacy-policy",
    "uk": "11. Контактна інформація",
    "ru": "11. Контактная информация",
    "pl": "11. Informacje kontaktowe",
    "en": "11. Contact Information"
  },
  {
    "key": "privacy-policy_phone",
    "section": "privacy-policy",
    "uk": "Телефон",
    "ru": "Телефон",
    "pl": "Telefon",
    "en": "Phone"
  },
  {
    "key": "privacy-policy_email",
    "section": "privacy-policy",
    "uk": "Електронна пошта",
    "ru": "Электронная почта",
    "pl": "E-mail",
    "en": "Email"
  },
  {
    "key": "privacy-policy_last_updated",
    "section": "privacy-policy",
    "uk": "Останнє оновлення",
    "ru": "Последнее обновление",
    "pl": "Ostatnia aktualizacja",
    "en": "Last updated"
  },
  {
    "key": "privacy-policy_version",
    "section": "privacy-policy",
    "uk": "Версія",
    "ru": "Версия",
    "pl": "Wersja",
    "en": "Version"
  },
  // Privacy Policy translations
  {
    "key": "privacy_title",
    "section": "legal",
    "uk": "Політика конфіденційності",
    "ru": "Политика конфиденциальности", 
    "pl": "Polityka prywatności",
    "en": "Privacy Policy"
  },
  {
    "key": "privacy_last_updated",
    "section": "legal",
    "uk": "Останнє оновлення: 9 вересня 2025",
    "ru": "Последнее обновление: 9 сентября 2025",
    "pl": "Ostatnia aktualizacja: 9 września 2025", 
    "en": "Last updated: September 09, 2025"
  },
  {
    "key": "privacy_intro1",
    "section": "legal",
    "uk": "Ця Політика конфіденційності описує наші політики та процедури щодо збору, використання та розкриття Вашої інформації, коли Ви користуєтесь Сервісом, і розповідає Вам про Ваші права на конфіденційність та як закон захищає Вас.",
    "ru": "Эта Политика конфиденциальности описывает наши политики и процедуры по сбору, использованию и раскрытию Вашей информации при использовании Вами Сервиса, а также рассказывает Вам о Ваших правах на конфиденциальность и том, как закон защищает Вас.",
    "pl": "Niniejsza Polityka prywatności opisuje nasze zasady i procedury dotyczące zbierania, wykorzystywania i ujawniania Twoich informacji podczas korzystania z Usługi oraz informuje o Twoich prawach do prywatności i o tym, jak prawo Cię chroni.",
    "en": "This Privacy Policy describes Our policies and procedures on the collection, use and disclosure of Your information when You use the Service and tells You about Your privacy rights and how the law protects You."
  },
  {
    "key": "privacy_intro2", 
    "section": "legal",
    "uk": "Ми використовуємо Ваші персональні дані для надання та вдосконалення Сервісу. Користуючись Сервісом, Ви погоджуєтесь на збір та використання інформації відповідно до цієї Політики конфіденційності.",
    "ru": "Мы используем Ваши персональные данные для предоставления и улучшения Сервиса. Используя Сервис, Вы соглашаетесь на сбор и использование информации в соответствии с этой Политикой конфиденциальности.",
    "pl": "Wykorzystujemy Twoje dane osobowe w celu świadczenia i ulepszania Usługi. Korzystając z Usługi, wyrażasz zgodę na zbieranie i wykorzystywanie informacji zgodnie z niniejszą Polityką prywatności.",
    "en": "We use Your Personal data to provide and improve the Service. By using the Service, You agree to the collection and use of information in accordance with this Privacy Policy."
  },
  {
    "key": "privacy_definitions_title",
    "section": "legal", 
    "uk": "Тлумачення та визначення",
    "ru": "Интерпретация и определения",
    "pl": "Interpretacja i definicje",
    "en": "Interpretation and Definitions"
  },
  {
    "key": "privacy_interpretation",
    "section": "legal",
    "uk": "Тлумачення",
    "ru": "Интерпретация", 
    "pl": "Interpretacja",
    "en": "Interpretation"
  },
  {
    "key": "privacy_interpretation_text",
    "section": "legal",
    "uk": "Слова, з яких перша літера написана з великої літери, мають значення, визначені в наступних умовах. Наступні визначення мають однакове значення незалежно від того, вживаються вони в однині чи множині.",
    "ru": "Слова, первая буква которых написана с заглавной буквы, имеют значения, определенные в следующих условиях. Следующие определения имеют одинаковое значение независимо от того, употребляются они в единственном или множественном числе.",
    "pl": "Słowa, których pierwsza litera jest pisana wielką literą, mają znaczenia zdefiniowane w następujących warunkach. Poniższe definicje mają to samo znaczenie niezależnie od tego, czy występują w liczbie pojedynczej czy mnogiej.",
    "en": "The words of which the initial letter is capitalized have meanings defined under the following conditions. The following definitions shall have the same meaning regardless of whether they appear in singular or in plural."
  },
  {
    "key": "privacy_definitions",
    "section": "legal",
    "uk": "Визначення",
    "ru": "Определения",
    "pl": "Definicje", 
    "en": "Definitions"
  },
  {
    "key": "privacy_definitions_intro",
    "section": "legal",
    "uk": "Для цілей цієї Політики конфіденційності:",
    "ru": "Для целей данной Политики конфиденциальности:",
    "pl": "Na potrzeby niniejszej Polityki prywatności:",
    "en": "For the purposes of this Privacy Policy:"
  },
  {
    "key": "privacy_def_account",
    "section": "legal",
    "uk": "Акаунт",
    "ru": "Аккаунт",
    "pl": "Konto",
    "en": "Account"
  },
  {
    "key": "privacy_def_account_text", 
    "section": "legal",
    "uk": "означає унікальний акаунт, створений для Вас для доступу до нашого Сервісу або частин нашого Сервісу.",
    "ru": "означает уникальную учетную запись, созданную для Вас для доступа к нашему Сервису или частям нашего Сервиса.",
    "pl": "oznacza unikalne konto utworzone dla Ciebie w celu uzyskania dostępu do naszej Usługi lub części naszej Usługi.",
    "en": "means a unique account created for You to access our Service or parts of our Service."
  },
  {
    "key": "privacy_def_company",
    "section": "legal",
    "uk": "Компанія",
    "ru": "Компания",
    "pl": "Firma",
    "en": "Company"
  },
  {
    "key": "privacy_def_company_text",
    "section": "legal", 
    "uk": "відноситься до SOBI, Алея Незалежності 705a/707a 81-853 Сопот, Польща.",
    "ru": "относится к SOBI, Алея Независимости 705a/707a 81-853 Сопот, Польша.",
    "pl": "odnosi się do SOBI, Aleja Niepodległości 705a/707a 81-853 Sopot, Polska.",
    "en": "refers to SOBI, Aleja Niepodległości 705a/707a 81-853 Sopot, Poland."
  },
  {
    "key": "privacy_def_cookies",
    "section": "legal",
    "uk": "Куки",
    "ru": "Куки",
    "pl": "Pliki cookie", 
    "en": "Cookies"
  },
  {
    "key": "privacy_def_cookies_text",
    "section": "legal",
    "uk": "це малі файли, які розміщуються на Вашому комп'ютері, мобільному пристрої або будь-якому іншому пристрої веб-сайтом.",
    "ru": "это небольшие файлы, которые размещаются на Вашем компьютере, мобильном устройстве или любом другом устройстве веб-сайтом.",
    "pl": "to małe pliki umieszczane na Twoim komputerze, urządzeniu mobilnym lub innym urządzeniu przez stronę internetową.",
    "en": "are small files that are placed on Your computer, mobile device or any other device by a website."
  },
  {
    "key": "privacy_def_country", 
    "section": "legal",
    "uk": "Країна",
    "ru": "Страна",
    "pl": "Kraj",
    "en": "Country"
  },
  {
    "key": "privacy_def_country_text",
    "section": "legal",
    "uk": "відноситься до Польщі",
    "ru": "относится к Польше",
    "pl": "odnosi się do Polski",
    "en": "refers to Poland"
  },
  {
    "key": "privacy_def_device",
    "section": "legal",
    "uk": "Пристрій",
    "ru": "Устройство",
    "pl": "Urządzenie",
    "en": "Device"
  },
  {
    "key": "privacy_def_device_text",
    "section": "legal",
    "uk": "означає будь-який пристрій, який може отримати доступ до Сервісу, такий як комп'ютер, мобільний телефон або цифровий планшет.",
    "ru": "означает любое устройство, которое может получить доступ к Сервису, такое как компьютер, мобильный телефон или цифровой планшет.",
    "pl": "oznacza dowolne urządzenie, które może uzyskać dostęp do Usługi, takie jak komputer, telefon komórkowy lub tablet cyfrowy.",
    "en": "means any device that can access the Service such as a computer, a cellphone or a digital tablet."
  },
  {
    "key": "privacy_def_personal_data",
    "section": "legal",
    "uk": "Персональні дані",
    "ru": "Персональные данные", 
    "pl": "Dane osobowe",
    "en": "Personal Data"
  },
  {
    "key": "privacy_def_personal_data_text",
    "section": "legal",
    "uk": "це будь-яка інформація, яка стосується ідентифікованої або ідентифікованої особи.",
    "ru": "это любая информация, которая относится к идентифицированному или идентифицируемому лицу.",
    "pl": "to wszelkie informacje odnoszące się do zidentyfikowanej lub możliwej do zidentyfikowania osoby.",
    "en": "is any information that relates to an identified or identifiable individual."
  },
  {
    "key": "privacy_def_service",
    "section": "legal",
    "uk": "Сервіс",
    "ru": "Сервис",
    "pl": "Usługa",
    "en": "Service"
  },
  {
    "key": "privacy_def_service_text", 
    "section": "legal",
    "uk": "відноситься до Веб-сайту.",
    "ru": "относится к Веб-сайту.",
    "pl": "odnosi się do Strony internetowej.",
    "en": "refers to the Website."
  },
  {
    "key": "privacy_def_website",
    "section": "legal",
    "uk": "Веб-сайт",
    "ru": "Веб-сайт",
    "pl": "Strona internetowa",
    "en": "Website"
  },
  {
    "key": "privacy_def_website_text",
    "section": "legal",
    "uk": "відноситься до SOBI, доступного за адресою https://sobipartner.info/",
    "ru": "относится к SOBI, доступному по адресу https://sobipartner.info/", 
    "pl": "odnosi się do SOBI, dostępnego pod adresem https://sobipartner.info/",
    "en": "refers to SOBI, accessible from https://sobipartner.info/"
  },
  {
    "key": "privacy_collecting_title",
    "section": "legal",
    "uk": "Збір та використання Ваших персональних даних",
    "ru": "Сбор и использование Ваших персональных данных",
    "pl": "Gromadzenie i wykorzystywanie Twoich danych osobowych",
    "en": "Collecting and Using Your Personal Data"
  },
  {
    "key": "privacy_data_types",
    "section": "legal",
    "uk": "Типи зібраних даних", 
    "ru": "Типы собранных данных",
    "pl": "Rodzaje zbieranych danych",
    "en": "Types of Data Collected"
  },
  {
    "key": "privacy_personal_data",
    "section": "legal",
    "uk": "Персональні дані",
    "ru": "Персональные данные",
    "pl": "Dane osobowe",
    "en": "Personal Data"
  },
  {
    "key": "privacy_personal_data_intro",
    "section": "legal",
    "uk": "Під час використання нашого Сервісу Ми можемо попросити Вас надати Нам певну особисто ідентифікуючу інформацію, яка може бути використана для зв'язку з Вами або ідентифікації Вас. Особисто ідентифікуюча інформація може включати, але не обмежується:",
    "ru": "При использовании нашего Сервиса Мы можем попросить Вас предоставить Нам определенную личную информацию, которая может быть использована для связи с Вами или идентификации Вас. Личная информация может включать, но не ограничиваться:",
    "pl": "Podczas korzystania z naszej Usługi możemy poprosić Cię o podanie określonych danych osobowych, które mogą być wykorzystane do kontaktu z Tobą lub identyfikacji Ciebie. Dane osobowe mogą obejmować, ale nie ograniczają się do:",
    "en": "While using Our Service, We may ask You to provide Us with certain personally identifiable information that can be used to contact or identify You. Personally identifiable information may include, but is not limited to:"
  },
  {
    "key": "privacy_data_email",
    "section": "legal",
    "uk": "Адреса електронної пошти",
    "ru": "Адрес электронной почты",
    "pl": "Adres e-mail",
    "en": "Email address"
  },
  {
    "key": "privacy_data_name",
    "section": "legal",
    "uk": "Ім'я та прізвище",
    "ru": "Имя и фамилия",
    "pl": "Imię i nazwisko", 
    "en": "First name and last name"
  },
  {
    "key": "privacy_data_phone",
    "section": "legal",
    "uk": "Номер телефону",
    "ru": "Номер телефона",
    "pl": "Numer telefonu",
    "en": "Phone number"
  },
  {
    "key": "privacy_data_address",
    "section": "legal",
    "uk": "Адреса, область, провінція, поштовий індекс, місто",
    "ru": "Адрес, область, провинция, почтовый индекс, город",
    "pl": "Adres, województwo, prowincja, kod pocztowy, miasto",
    "en": "Address, State, Province, ZIP/Postal code, City"
  },
  {
    "key": "privacy_data_usage",
    "section": "legal",
    "uk": "Дані використання",
    "ru": "Данные использования",
    "pl": "Dane użytkowania", 
    "en": "Usage Data"
  },
  {
    "key": "privacy_usage_data",
    "section": "legal",
    "uk": "Дані використання",
    "ru": "Данные использования",
    "pl": "Dane użytkowania",
    "en": "Usage Data"
  },
  {
    "key": "privacy_usage_data_text",
    "section": "legal",
    "uk": "Дані використання збираються автоматично при використанні Сервісу. Дані використання можуть включати таку інформацію, як IP-адреса Вашого пристрою, тип браузера, версія браузера, сторінки нашого Сервісу, які Ви відвідуєте, час та дата Вашого відвідування, час, проведений на цих сторінках, унікальні ідентифікатори пристрою та інші діагностичні дані.",
    "ru": "Данные использования собираются автоматически при использовании Сервиса. Данные использования могут включать такую информацию, как IP-адрес Вашего устройства, тип браузера, версия браузера, страницы нашего Сервиса, которые Вы посещаете, время и дата Вашего посещения, время, проведенное на этих страницах, уникальные идентификаторы устройства и другие диагностические данные.",
    "pl": "Dane użytkowania są gromadzone automatycznie podczas korzystania z Usługi. Dane użytkowania mogą obejmować informacje takie jak adres IP Twojego urządzenia, typ przeglądarki, wersja przeglądarki, strony naszej Usługi, które odwiedzasz, czas i data Twojej wizyty, czas spędzony na tych stronach, unikalne identyfikatory urządzeń i inne dane diagnostyczne.",
    "en": "Usage Data is collected automatically when using the Service. Usage Data may include information such as Your Device's Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that You visit, the time and date of Your visit, the time spent on those pages, unique device identifiers and other diagnostic data."
  },
  {
    "key": "privacy_tracking",
    "section": "legal",
    "uk": "Технології відстеження та куки",
    "ru": "Технологии отслеживания и куки",
    "pl": "Technologie śledzenia i pliki cookie",
    "en": "Tracking Technologies and Cookies"
  },
  {
    "key": "privacy_tracking_text",
    "section": "legal",
    "uk": "Ми використовуємо куки та подібні технології відстеження для відстеження діяльності в нашому Сервісі та зберігання певної інформації. Технології, які ми використовуємо, можуть включати:",
    "ru": "Мы используем куки и аналогичные технологии отслеживания для отслеживания активности в нашем Сервисе и хранения определенной информации. Технологии, которые мы используем, могут включать:",
    "pl": "Używamy plików cookie i podobnych technologii śledzenia do śledzenia aktywności w naszej Usłudze i przechowywania określonych informacji. Technologie, których używamy, mogą obejmować:",
    "en": "We use Cookies and similar tracking technologies to track the activity on Our Service and store certain information. The technologies We use may include:"
  },
  {
    "key": "privacy_cookies_browser", 
    "section": "legal",
    "uk": "Куки або браузерні куки",
    "ru": "Куки или браузерные куки",
    "pl": "Pliki cookie lub pliki cookie przeglądarki",
    "en": "Cookies or Browser Cookies"
  },
  {
    "key": "privacy_cookies_browser_text",
    "section": "legal",
    "uk": "Куки - це малий файл, розміщений на Вашому пристрої.",
    "ru": "Куки - это небольшой файл, размещенный на Вашем устройстве.",
    "pl": "Plik cookie to mały plik umieszczony na Twoim urządzeniu.",
    "en": "A cookie is a small file placed on Your Device."
  },
  {
    "key": "privacy_web_beacons",
    "section": "legal",
    "uk": "Веб-маяки",
    "ru": "Веб-маяки",
    "pl": "Sygnalizatory internetowe", 
    "en": "Web Beacons"
  },
  {
    "key": "privacy_web_beacons_text",
    "section": "legal",
    "uk": "Певні розділи нашого Сервісу можуть містити малі електронні файли, відомі як веб-маяки.",
    "ru": "Определенные разделы нашего Сервиса могут содержать небольшие электронные файлы, известные как веб-маяки.",
    "pl": "Niektóre sekcje naszej Usługi mogą zawierać małe pliki elektroniczne znane jako sygnalizatory internetowe.",
    "en": "Certain sections of our Service may contain small electronic files known as web beacons."
  },
  {
    "key": "privacy_use_data",
    "section": "legal",
    "uk": "Використання Ваших персональних даних",
    "ru": "Использование Ваших персональных данных",
    "pl": "Wykorzystywanie Twoich danych osobowych",
    "en": "Use of Your Personal Data"
  },
  {
    "key": "privacy_use_intro",
    "section": "legal",
    "uk": "Компанія може використовувати персональні дані для наступних цілей:",
    "ru": "Компания может использовать персональные данные для следующих целей:",
    "pl": "Firma może wykorzystywać dane osobowe w następujących celach:",
    "en": "The Company may use Personal Data for the following purposes:"
  },
  {
    "key": "privacy_use_provide",
    "section": "legal",
    "uk": "Для надання та підтримки нашого Сервісу",
    "ru": "Для предоставления и поддержки нашего Сервиса",
    "pl": "W celu świadczenia i utrzymania naszej Usługi",
    "en": "To provide and maintain our Service"
  },
  {
    "key": "privacy_use_provide_text",
    "section": "legal",
    "uk": "включаючи моніторинг використання нашого Сервісу.",
    "ru": "включая мониторинг использования нашего Сервиса.",
    "pl": "w tym monitorowanie korzystania z naszej Usługi.",
    "en": "including to monitor the usage of our Service."
  },
  {
    "key": "privacy_use_account",
    "section": "legal",
    "uk": "Для управління Вашим акаунтом",
    "ru": "Для управления Вашим аккаунтом", 
    "pl": "W celu zarządzania Twoim kontem",
    "en": "To manage Your Account"
  },
  {
    "key": "privacy_use_account_text",
    "section": "legal",
    "uk": "для управління Вашою реєстрацією як користувача Сервісу.",
    "ru": "для управления Вашей регистрацией как пользователя Сервиса.",
    "pl": "w celu zarządzania Twoją rejestracją jako użytkownika Usługi.",
    "en": "to manage Your registration as a user of the Service."
  },
  {
    "key": "privacy_use_contract",
    "section": "legal",
    "uk": "Для виконання договору",
    "ru": "Для выполнения договора",
    "pl": "W celu wykonania umowy",
    "en": "For the performance of a contract"
  },
  {
    "key": "privacy_use_contract_text",
    "section": "legal",
    "uk": "розробка, дотримання та виконання договору купівлі.",
    "ru": "разработка, соблюдение и выполнение договора купли-продажи.",
    "pl": "rozwój, zgodność i realizacja umowy kupna.",
    "en": "the development, compliance and undertaking of the purchase contract."
  },
  {
    "key": "privacy_use_contact",
    "section": "legal",
    "uk": "Для зв'язку з Вами",
    "ru": "Для связи с Вами",
    "pl": "W celu skontaktowania się z Tobą",
    "en": "To contact You"
  },
  {
    "key": "privacy_use_contact_text",
    "section": "legal",
    "uk": "Для зв'язку з Вами електронною поштою, телефонними дзвінками, SMS або іншими еквівалентними формами електронного спілкування.",
    "ru": "Для связи с Вами по электронной почте, телефонными звонками, SMS или другими эквивалентными формами электронного общения.",
    "pl": "W celu skontaktowania się z Tobą za pośrednictwem poczty elektronicznej, połączeń telefonicznych, SMS-ów lub innych równoważnych form komunikacji elektronicznej.",
    "en": "To contact You by email, telephone calls, SMS, or other equivalent forms of electronic communication."
  },
  {
    "key": "privacy_use_news",
    "section": "legal",
    "uk": "Для надання Вам",
    "ru": "Для предоставления Вам",
    "pl": "W celu dostarczenia Ci", 
    "en": "To provide You"
  },
  {
    "key": "privacy_use_news_text",
    "section": "legal",
    "uk": "новин, спеціальних пропозицій та загальної інформації про інші товари, послуги та заходи.",
    "ru": "новостей, специальных предложений и общей информации о других товарах, услугах и мероприятиях.",
    "pl": "wiadomości, oferty specjalne i ogólne informacje o innych towarach, usługach i wydarzeniach.",
    "en": "with news, special offers and general information about other goods, services and events."
  },
  {
    "key": "privacy_use_requests",
    "section": "legal",
    "uk": "Для управління Вашими запитами",
    "ru": "Для управления Вашими запросами",
    "pl": "W celu zarządzania Twoimi zapytaniami",
    "en": "To manage Your requests"
  },
  {
    "key": "privacy_use_requests_text",
    "section": "legal",
    "uk": "Для обслуговування та управління Вашими запитами до Нас.",
    "ru": "Для обслуживания и управления Вашими запросами к Нам.",
    "pl": "W celu obsługi i zarządzania Twoimi zapytaniami do nas.",
    "en": "To attend and manage Your requests to Us."
  },
  {
    "key": "privacy_retention",
    "section": "legal",
    "uk": "Зберігання Ваших персональних даних",
    "ru": "Хранение Ваших персональных данных",
    "pl": "Przechowywanie Twoich danych osobowych",
    "en": "Retention of Your Personal Data"
  },
  {
    "key": "privacy_retention_text",
    "section": "legal",
    "uk": "Компанія буде зберігати Ваші персональні дані лише стільки, скільки це необхідно для цілей, викладених у цій Політиці конфіденційності. Ми будемо зберігати та використовувати Ваші персональні дані в тій мірі, в якій це необхідно для дотримання наших правових зобов'язань, вирішення спорів та забезпечення виконання наших правових угод та політик.",
    "ru": "Компания будет хранить Ваши персональные данные только столько, сколько это необходимо для целей, изложенных в данной Политике конфиденциальности. Мы будем хранить и использовать Ваши персональные данные в той степени, в которой это необходимо для соблюдения наших правовых обязательств, разрешения споров и обеспечения выполнения наших правовых соглашений и политик.",
    "pl": "Firma będzie przechowywać Twoje dane osobowe tylko tak długo, jak jest to konieczne do celów określonych w niniejszej Polityce prywatności. Będziemy przechowywać i wykorzystywać Twoje dane osobowe w zakresie niezbędnym do wypełnienia naszych obowiązków prawnych, rozwiązywania sporów i egzekwowania naszych umów prawnych i zasad.",
    "en": "The Company will retain Your Personal Data only for as long as is necessary for the purposes set out in this Privacy Policy. We will retain and use Your Personal Data to the extent necessary to comply with our legal obligations, resolve disputes, and enforce our legal agreements and policies."
  },
  {
    "key": "privacy_delete",
    "section": "legal",
    "uk": "Видалення Ваших персональних даних",
    "ru": "Удаление Ваших персональных данных",
    "pl": "Usuwanie Twoich danych osobowych",
    "en": "Delete Your Personal Data"
  },
  {
    "key": "privacy_delete_text",
    "section": "legal",
    "uk": "Ви маєте право видалити або попросити Нас допомогти у видаленні персональних даних, які Ми зібрали про Вас. Наш Сервіс може надати Вам можливість видалити певну інформацію про Вас з Сервісу.",
    "ru": "Вы имеете право удалить или попросить Нас помочь в удалении персональных данных, которые Мы собрали о Вас. Наш Сервис может предоставить Вам возможность удалить определенную информацию о Вас из Сервиса.",
    "pl": "Masz prawo usunąć lub poprosić nas o pomoc w usunięciu danych osobowych, które zebraliśmy o Tobie. Nasza Usługa może dać Ci możliwość usunięcia określonych informacji o Tobie z Usługi.",
    "en": "You have the right to delete or request that We assist in deleting the Personal Data that We have collected about You. Our Service may give You the ability to delete certain information about You from within the Service."
  },
  {
    "key": "privacy_disclosure",
    "section": "legal",
    "uk": "Розкриття Ваших персональних даних",
    "ru": "Раскрытие Ваших персональных данных",
    "pl": "Ujawnianie Twoich danych osobowych",
    "en": "Disclosure of Your Personal Data"
  },
  {
    "key": "privacy_business_transactions",
    "section": "legal",
    "uk": "Бізнес-транзакції",
    "ru": "Бизнес-транзакции",
    "pl": "Transakcje biznesowe",
    "en": "Business Transactions"
  },
  {
    "key": "privacy_business_transactions_text",
    "section": "legal",
    "uk": "Якщо Компанія бере участь у злитті, поглинанні або продажу активів, Ваші персональні дані можуть бути передані.",
    "ru": "Если Компания участвует в слиянии, поглощении или продаже активов, Ваши персональные данные могут быть переданы.",
    "pl": "Jeśli Firma uczestniczy w fuzji, przejęciu lub sprzedaży aktywów, Twoje dane osobowe mogą zostać przekazane.",
    "en": "If the Company is involved in a merger, acquisition or asset sale, Your Personal Data may be transferred."
  },
  {
    "key": "privacy_law_enforcement",
    "section": "legal",
    "uk": "Правоохоронні органи",
    "ru": "Правоохранительные органы",
    "pl": "Organy ścigania",
    "en": "Law enforcement"
  },
  {
    "key": "privacy_law_enforcement_text",
    "section": "legal",
    "uk": "За певних обставин Компанія може бути зобов'язана розкрити Ваші персональні дані, якщо це вимагається законом або у відповідь на дійсні запити державних органів.",
    "ru": "При определенных обстоятельствах Компания может быть обязана раскрыть Ваши персональные данные, если этого требует закон или в ответ на действительные запросы государственных органов.",
    "pl": "W pewnych okolicznościach Firma może być zobowiązana do ujawnienia Twoich danych osobowych, jeśli wymaga tego prawo lub w odpowiedzi na ważne żądania organów publicznych.",
    "en": "Under certain circumstances, the Company may be required to disclose Your Personal Data if required to do so by law or in response to valid requests by public authorities."
  },
  {
    "key": "privacy_security",
    "section": "legal",
    "uk": "Безпека Ваших персональних даних",
    "ru": "Безопасность Ваших персональных данных",
    "pl": "Bezpieczeństwo Twoich danych osobowych",
    "en": "Security of Your Personal Data"
  },
  {
    "key": "privacy_security_text",
    "section": "legal",
    "uk": "Безпека Ваших персональних даних важлива для Нас, але пам'ятайте, що жоден метод передачі через Інтернет або метод електронного зберігання не є на 100% безпечним. Хоча Ми прагнемо використовувати комерційно прийнятні засоби для захисту Ваших персональних даних, Ми не можемо гарантувати їх абсолютну безпеку.",
    "ru": "Безопасность Ваших персональных данных важна для Нас, но помните, что ни один метод передачи через Интернет или метод электронного хранения не является на 100% безопасным. Хотя Мы стремимся использовать коммерчески приемлемые средства для защиты Ваших персональных данных, Мы не можем гарантировать их абсолютную безопасность.",
    "pl": "Bezpieczeństwo Twoich danych osobowych jest dla nas ważne, ale pamiętaj, że żadna metoda transmisji przez Internet ani metoda przechowywania elektronicznego nie jest w 100% bezpieczna. Chociaż staramy się używać komercyjnie akceptowalnych środków w celu ochrony Twoich danych osobowych, nie możemy zagwarantować ich absolutnego bezpieczeństwa.",
    "en": "The security of Your Personal Data is important to Us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While We strive to use commercially acceptable means to protect Your Personal Data, We cannot guarantee its absolute security."
  },
  {
    "key": "privacy_children",
    "section": "legal",
    "uk": "Конфіденційність дітей",
    "ru": "Конфиденциальность детей",
    "pl": "Prywatność dzieci",
    "en": "Children's Privacy"
  },
  {
    "key": "privacy_children_text",
    "section": "legal",
    "uk": "Наш Сервіс не призначений для осіб віком до 13 років. Ми свідомо не збираємо особисто ідентифікуючу інформацію від осіб віком до 13 років. Якщо Ви є батьком або опікуном і знаєте, що Ваша дитина надала Нам персональні дані, будь ласка, зв'яжіться з Нами.",
    "ru": "Наш Сервис не предназначен для лиц в возрасте до 13 лет. Мы сознательно не собираем личную информацию от лиц в возрасте до 13 лет. Если Вы являетесь родителем или опекуном и знаете, что Ваш ребенок предоставил Нам персональные данные, пожалуйста, свяжитесь с Нами.",
    "pl": "Nasza Usługa nie jest skierowana do osób poniżej 13 roku życia. Nie zbieramy świadomie danych osobowych od osób poniżej 13 roku życia. Jeśli jesteś rodzicem lub opiekunem i wiesz, że Twoje dziecko dostarczyło nam dane osobowe, skontaktuj się z nami.",
    "en": "Our Service does not address anyone under the age of 13. We do not knowingly collect personally identifiable information from anyone under the age of 13. If You are a parent or guardian and You are aware that Your child has provided Us with Personal Data, please contact Us."
  },
  {
    "key": "privacy_links",
    "section": "legal",
    "uk": "Посилання на інші веб-сайти",
    "ru": "Ссылки на другие веб-сайты",
    "pl": "Linki do innych stron internetowych",
    "en": "Links to Other Websites"
  },
  {
    "key": "privacy_links_text",
    "section": "legal",
    "uk": "Наш Сервіс може містити посилання на інші веб-сайти, які не керуються Нами. Якщо Ви натиснете на посилання третьої сторони, Ви будете перенаправлені на сайт цієї третьої сторони. Ми настійно радимо Вам переглянути Політику конфіденційності кожного сайту, який Ви відвідуєте.",
    "ru": "Наш Сервис может содержать ссылки на другие веб-сайты, которые не управляются Нами. Если Вы нажмете на ссылку третьей стороны, Вы будете перенаправлены на сайт этой третьей стороны. Мы настоятельно рекомендуем Вам ознакомиться с Политикой конфиденциальности каждого сайта, который Вы посещаете.",
    "pl": "Nasza Usługa może zawierać linki do innych stron internetowych, które nie są przez nas obsługiwane. Jeśli klikniesz link strony trzeciej, zostaniesz przekierowany na stronę tej strony trzeciej. Zdecydowanie zalecamy przejrzenie Polityki prywatności każdej strony, którą odwiedzasz.",
    "en": "Our Service may contain links to other websites that are not operated by Us. If You click on a third party link, You will be directed to that third party's site. We strongly advise You to review the Privacy Policy of every site You visit."
  },
  {
    "key": "privacy_changes",
    "section": "legal",
    "uk": "Зміни до цієї Політики конфіденційності",
    "ru": "Изменения в данной Политике конфиденциальности",
    "pl": "Zmiany w niniejszej Polityce prywatności",
    "en": "Changes to this Privacy Policy"
  },
  {
    "key": "privacy_changes_text",
    "section": "legal",
    "uk": "Ми можемо час від часу оновлювати Нашу Політику конфіденційності. Ми повідомимо Вас про будь-які зміни, розмістивши нову Політику конфіденційності на цій сторінці та оновивши дату \"Останнє оновлення\" у верхній частині цієї Політики конфіденційності.",
    "ru": "Мы можем время от времени обновлять Нашу Политику конфиденциальности. Мы уведомим Вас о любых изменениях, разместив новую Политику конфиденциальности на данной странице и обновив дату \"Последнее обновление\" в верхней части данной Политики конфиденциальности.",
    "pl": "Możemy co jakiś czas aktualizować naszą Politykę prywatności. Powiadomimy Cię o wszelkich zmianach, publikując nową Politykę prywatności na tej stronie i aktualizując datę \"Ostatnia aktualizacja\" u góry niniejszej Polityki prywatności.",
    "en": "We may update Our Privacy Policy from time to time. We will notify You of any changes by posting the new Privacy Policy on this page and update the \"Last updated\" date at the top of this Privacy Policy."
  },
  {
    "key": "privacy_contact",
    "section": "legal",
    "uk": "Зв'яжіться з Нами",
    "ru": "Свяжитесь с Нами",
    "pl": "Skontaktuj się z nami",
    "en": "Contact Us"
  },
  {
    "key": "privacy_contact_intro",
    "section": "legal",
    "uk": "Якщо у Вас є будь-які питання щодо цієї Політики конфіденційності, Ви можете зв'язатися з нами:",
    "ru": "Если у Вас есть какие-либо вопросы по данной Политике конфиденциальности, Вы можете связаться с нами:",
    "pl": "Jeśli masz jakiekolwiek pytania dotyczące niniejszej Polityki prywatności, możesz skontaktować się z nami:",
    "en": "If you have any questions about this Privacy Policy, You can contact us:"
  },
  {
    "key": "privacy_contact_email",
    "section": "legal",
    "uk": "Електронною поштою",
    "ru": "По электронной почте",
    "pl": "Pocztą elektroniczną",
    "en": "By email"
  },
  {
    "key": "privacy_contact_phone",
    "section": "legal",
    "uk": "По телефону",
    "ru": "По телефону",
    "pl": "Przez telefon",
    "en": "By phone number"
  },
  {
    "key": "privacy_effective",
    "section": "legal",
    "uk": "Ця Політика конфіденційності набуває чинності з 9 вересня 2025 року",
    "ru": "Эта Политика конфиденциальности вступает в силу с 9 сентября 2025 года",
    "pl": "Niniejsza Polityka prywatności obowiązuje od 9 września 2025 roku",
    "en": "This Privacy Policy is effective as of September 09, 2025"
  },
  // Income Calculator translations
  {
    "key": "calc_title",
    "section": "common",
    "uk": "Калькулятор заробітку водія",
    "ru": "Калькулятор заработка водителя",
    "pl": "Kalkulator zarobków kierowcy",
    "en": "Driver Income Calculator"
  },
  {
    "key": "calc_mode_label",
    "section": "common",
    "uk": "Режим розрахунку:",
    "ru": "Режим расчета:",
    "pl": "Tryb kalkulacji:",
    "en": "Calculation mode:"
  },
  {
    "key": "calc_mode_known",
    "section": "common",
    "uk": "Введіть свій чистий дохід",
    "ru": "Введите свой чистый доход",
    "pl": "Wpisz swój dochód netto",
    "en": "Enter your net income"
  },
  {
    "key": "calc_mode_hourly",
    "section": "common",
    "uk": "Розрахувати на основі годин",
    "ru": "Рассчитать на основе часов",
    "pl": "Oblicz na podstawie godzin",
    "en": "Calculate based on hours"
  },
  {
    "key": "calc_income_label",
    "section": "common",
    "uk": "Ваш чистий дохід (zł)",
    "ru": "Ваш чистый доход (zł)",
    "pl": "Twój dochód netto (zł)",
    "en": "Your net income (zł)"
  },
  {
    "key": "calc_income_placeholder",
    "section": "common",
    "uk": "Введіть суму",
    "ru": "Введите сумму",
    "pl": "Wpisz kwotę",
    "en": "Enter amount"
  },
  {
    "key": "calc_hourly_rate",
    "section": "common",
    "uk": "Ставка за годину (zł)",
    "ru": "Ставка за час (zł)",
    "pl": "Stawka za godzinę (zł)",
    "en": "Hourly rate (zł)"
  },
  {
    "key": "calc_hourly_rate_hint",
    "section": "common",
    "uk": "Годинна ставка може відрізнятись в залежності від часу роботи і дня",
    "ru": "Почасовая ставка может отличаться в зависимости от времени работы и дня",
    "pl": "Stawka godzinowa może się różnić w zależności od godzin pracy i dnia",
    "en": "Hourly rate may vary depending on working hours and day"
  },
  {
    "key": "calc_hours_per_day",
    "section": "common",
    "uk": "Годин на день",
    "ru": "Часов в день",
    "pl": "Godzin dziennie",
    "en": "Hours per day"
  },
  {
    "key": "calc_days_per_week",
    "section": "common",
    "uk": "Днів на тиждень",
    "ru": "Дней в неделю",
    "pl": "Dni w tygodniu",
    "en": "Days per week"
  },
  {
    "key": "calc_have_self_car",
    "section": "common",
    "uk": "Маю своє авто",
    "ru": "Есть свой автомобиль",
    "pl": "Mam własny samochód",
    "en": "I have my own car"
  },
  {
    "key": "calc_want_rent_car",
    "section": "common",
    "uk": "Хочу арендувати авто",
    "ru": "Хочу арендовать автомобиль",
    "pl": "Chcę wynająć samochód",
    "en": "I want to rent a car"
  },
  {
    "key": "calc_select_car",
    "section": "common",
    "uk": "Оберіть автомобіль:",
    "ru": "Выберите автомобиль:",
    "pl": "Wybierz samochód:",
    "en": "Select a car:"
  },
  {
    "key": "calc_rental_cost",
    "section": "common",
    "uk": "Вартість оренди автомобіля (zł)",
    "ru": "Стоимость аренды автомобиля (zł)",
    "pl": "Koszt wynajmu samochodu (zł)",
    "en": "Car rental cost (zł)"
  },
  {
    "key": "calc_rental_placeholder",
    "section": "common",
    "uk": "Введіть вартість оренди",
    "ru": "Введите стоимость аренды",
    "pl": "Wpisz koszt wynajmu",
    "en": "Enter rental cost"
  },
  {
    "key": "calc_button",
    "section": "common",
    "uk": "Розрахувати заробіток",
    "ru": "Рассчитать заработок",
    "pl": "Oblicz zarobek",
    "en": "Calculate income"
  },
  {
    "key": "calc_results_title",
    "section": "common",
    "uk": "Результати розрахунку:",
    "ru": "Результаты расчета:",
    "pl": "Wyniki kalkulacji:",
    "en": "Calculation results:"
  },
  {
    "key": "calc_result_netto",
    "section": "common",
    "uk": "Чистий дохід (тижневий):",
    "ru": "Чистый доход (недельный):",
    "pl": "Dochód netto (tygodniowo):",
    "en": "Net income (weekly):"
  },
  {
    "key": "calc_result_after_fixed",
    "section": "common",
    "uk": "Після вирахування 50 zł:",
    "ru": "После вычета 50 zł:",
    "pl": "Po odjęciu 50 zł:",
    "en": "After deducting 50 zł:"
  },
  {
    "key": "calc_result_after_percent",
    "section": "common",
    "uk": "Після вирахування 8%:",
    "ru": "После вычета 8%:",
    "pl": "Po odjęciu 8%:",
    "en": "After deducting 8%:"
  },
  {
    "key": "calc_result_after_rental",
    "section": "common",
    "uk": "Після вирахування оренди",
    "ru": "После вычета аренды",
    "pl": "Po odjęciu wynajmu",
    "en": "After deducting rental"
  },
  {
    "key": "calc_result_weekly",
    "section": "common",
    "uk": "Тижневий прибуток:",
    "ru": "Недельная прибыль:",
    "pl": "Zysk tygodniowy:",
    "en": "Weekly profit:"
  },
  {
    "key": "calc_result_monthly",
    "section": "common",
    "uk": "Прогнозований місячний прибуток:",
    "ru": "Прогнозируемая месячная прибыль:",
    "pl": "Prognozowany zysk miesięczny:",
    "en": "Projected monthly profit:"
  },
  {
    "key": "enter_income_for_net_income",
    "section": "common",
    "uk": "Введіть суму вашого заробітку для розрахунку чистого доходу",
    "ru": "Введите сумму вашего заработка для расчета чистого дохода",
    "pl": "Wprowadź kwotę swojego dochodu, aby obliczyć dochód netto",
    "en": "Enter your earnings amount to calculate net income"
  },
  {
    "key": "validation_hours_per_day",
    "section": "common",
    "uk": "Введіть кількість годин на день скільки ви плануєте працювати, для розрахунку чистого доходу",
    "ru": "Введите количество часов в день, которые вы планируете работать, для расчета чистого дохода",
    "pl": "Wprowadź liczbę godzin dziennie, które planujesz pracować, aby obliczyć dochód netto",
    "en": "Enter the number of hours per day you plan to work to calculate net income"
  },
  {
    "key": "validation_days_per_week",
    "section": "common",
    "uk": "Введіть кількість днів на тиждень скільки ви плануєте працювати, для розрахунку чистого доходу",
    "ru": "Введите количество дней в неделю, которые вы планируете работать, для расчета чистого дохода",
    "pl": "Wprowadź liczbę dni w tygodniu, które planujesz pracować, aby obliczyć dochód netto",
    "en": "Enter the number of days per week you plan to work to calculate net income"
  },
  {
    "key": "validation_hours_per_day_max",
    "section": "common",
    "uk": "Максимальна кількість годин на день не може перевищувати 24",
    "ru": "Максимальное количество часов в день не может превышать 24",
    "pl": "Maksymalna liczba godzin dziennie nie może przekraczać 24",
    "en": "Maximum hours per day cannot exceed 24"
  },
  {
    "key": "validation_days_per_week_max",
    "section": "common",
    "uk": "Максимальна кількість днів на тиждень не може перевищувати 7",
    "ru": "Максимальное количество дней в неделю не может превышать 7",
    "pl": "Maksymalna liczba dni w tygodniu nie może przekraczać 7",
    "en": "Maximum days per week cannot exceed 7"
  },
  {
    "key": "validation_income_max",
    "section": "common",
    "uk": "Ви дуже амбіційні, але нажаль таку суму неможливо заробити😄",
    "ru": "Вы очень амбициозны, но к сожалению такую сумму невозможно заработать😄",
    "pl": "Jesteś bardzo ambitny, ale niestety nie da się zarobić takiej kwoty😄",
    "en": "You are very ambitious, but unfortunately it is impossible to earn such an amount😄"
  },
  {
    "key": "calc_recommendation_title",
    "section": "common",
    "uk": "Рекомендація",
    "ru": "Рекомендация",
    "pl": "Rekomendacja",
    "en": "Recommendation"
  },
  {
    "key": "calc_recommendation_toyota_corolla_low",
    "section": "common",
    "uk": "Щоб отримати більший прибуток, обери дешевший автомобіль, наприклад, Dacia Logan 2021.",
    "ru": "Чтобы получить большую прибыль, выбери более дешевый автомобиль, например, Dacia Logan 2021.",
    "pl": "Aby uzyskać większy zysk, wybierz tańszy samochód, taki jak Dacia Logan 2021.",
    "en": "To get more profit, choose a cheaper car, such as Dacia Logan 2021."
  },
  {
    "key": "calc_recommendation_toyota_corolla_medium",
    "section": "common",
    "uk": "Авто Prius 30 — чудовий вибір: комфорт у їзді залишиться на тому ж рівні, але тижневий прибуток буде більшим.",
    "ru": "Авто Prius 30 — отличный выбор: комфорт в езде останется на том же уровне, но недельная прибыль будет выше.",
    "pl": "Samochód Prius 30 to doskonały wybór: komfort jazdy pozostanie na tym samym poziomie, ale tygodniowy zysk będzie wyższy.",
    "en": "The Prius 30 is a great choice: your driving comfort will remain the same, but your weekly profit will be higher."
  },
  {
    "key": "calc_recommendation_toyota_corolla_high",
    "section": "common",
    "uk": "Ти обрав чудовий автомобіль для свого стилю роботи в таксі. Ти багато працюєш, тому тобі потрібні низька витрата пального та комфорт, які ти знайдеш у Toyota Corolla.",
    "ru": "Ты выбрал отличный автомобиль для своего стиля работы в такси. Ты много работаешь, поэтому тебе нужны низкий расход топлива и комфорт, которые ты найдешь в Toyota Corolla.",
    "pl": "Wybrałeś świetny samochód do swojego stylu pracy w taksówce. Dużo pracujesz, więc potrzebujesz niskiego zużycia paliwa i komfortu, które znajdziesz w Toyocie Corolli.",
    "en": "You have chosen a great car for your taxi work style. You work a lot, so you need low fuel consumption and comfort, which you will find in the Toyota Corolla."
  },
  {
    "key": "calc_recommendation_dacia_low",
    "section": "common",
    "uk": "Ти обрав чудовий автомобіль для свого стилю роботи в таксі. Тобі потрібен дешевий і економічний автомобіль — Dacia Logan 2021 є чудовим вибором.",
    "ru": "Ты выбрал отличный автомобиль для своего стиля работы в такси. Тебе нужен дешевый и экономичный автомобиль — Dacia Logan 2021 является отличным выбором.",
    "pl": "Wybrałeś świetny samochód do swojego stylu pracy w taksówce. Potrzebujesz taniego i ekonomicznego samochodu — Dacia Logan 2021 to doskonały wybór.",
    "en": "You have chosen a great car for your taxi work style. You need a cheap and economical car — Dacia Logan 2021 is an excellent choice."
  },
  {
    "key": "calc_recommendation_dacia_medium",
    "section": "common",
    "uk": "Ти вже досить активно працюєш — автомобіль Prius 30 може стати ідеальним вибором, адже автоматична коробка передач зробить твою щоденну роботу комфортнішою.",
    "ru": "Ты уже достаточно активно работаешь — автомобиль Prius 30 может стать идеальным выбором, ведь автоматическая коробка передач сделает твою ежедневную работу комфортнее.",
    "pl": "Już dość aktywnie pracujesz — samochód Prius 30 może być idealnym wyborem, ponieważ automatyczna skrzynia biegów uczyni Twoją codzienną pracę wygodniejszą.",
    "en": "You are already quite active — the Prius 30 can be an ideal choice, as the automatic transmission will make your daily work more comfortable."
  },
  {
    "key": "calc_recommendation_dacia_high",
    "section": "common",
    "uk": "Ти працюєш достатньо, щоб потребувати комфорту та низької витрати пального. Toyota Corolla може бути кращим вибором для тебе.",
    "ru": "Ты работаешь достаточно, чтобы нуждаться в комфорте и низком расходе топлива. Toyota Corolla может быть лучшим выбором для тебя.",
    "pl": "Pracujesz wystarczająco dużo, aby potrzebować komfortu i niskiego zużycia paliwa. Toyota Corolla może być dla Ciebie lepszym wyborem.",
    "en": "You work enough to need comfort and low fuel consumption. Toyota Corolla may be a better choice for you."
  },
  {
    "key": "calc_recommendation_prius_low",
    "section": "common",
    "uk": "Чудовий вибір автомобіля — отримаєш комфортну їзду та низьке споживання пального.",
    "ru": "Отличный выбор автомобиля — получишь комфортную езду и низкое потребление топлива.",
    "pl": "Doskonały wybór samochodu — uzyskasz komfortową jazdę i niskie zużycie paliwa.",
    "en": "Great choice of car — you will get comfortable driving and low fuel consumption."
  },
  {
    "key": "calc_recommendation_prius_medium",
    "section": "common",
    "uk": "Саме те, що тобі потрібно! Ідеальний режим роботи з обраним авто — низьке споживання пального та автоматична коробка передач допомагають заробляти більше.",
    "ru": "Именно то, что тебе нужно! Идеальный режим работы с выбранным авто — низкое потребление топлива и автоматическая коробка передач помогают зарабатывать больше.",
    "pl": "To dokładnie to, czego potrzebujesz! Idealny tryb pracy z wybranym samochodem — niskie zużycie paliwa i automatyczna skrzynia biegów pomagają zarabiać więcej.",
    "en": "That's exactly what you need! The ideal work mode with the chosen car — low fuel consumption and automatic transmission help you earn more."
  },
  {
    "key": "calc_recommendation_prius_high",
    "section": "common",
    "uk": "Ти працюєш достатньо багато і потребуєш найкращих умов та найнижчого споживання пального. Toyota Corolla може бути кращим вибором для тебе.",
    "ru": "Ты работаешь достаточно много и нуждаешься в лучших условиях и самом низком потреблении топлива. Toyota Corolla может быть лучшим выбором для тебя.",
    "pl": "Pracujesz wystarczająco dużo i potrzebujesz najlepszych warunków i najniższego zużycia paliwa. Toyota Corolla może być dla Ciebie lepszym wyborem.",
    "en": "You work quite a lot and need the best conditions and the lowest fuel consumption. Toyota Corolla may be a better choice for you."
  },
  {
    "key": "calc_recommendation_default",
    "section": "common",
    "uk": "Цей автомобіль підходить для роботи в таксі. Зв'яжіться з нами для отримання детальної консультації щодо оренди.",
    "ru": "Этот автомобиль подходит для работы в такси. Свяжитесь с нами для получения подробной консультации по аренде.",
    "pl": "Ten samochód nadaje się do pracy w taksówce. Skontaktuj się z nami, aby uzyskać szczegółową konsultację dotyczącą wynajmu.",
    "en": "This car is suitable for taxi work. Contact us for a detailed rental consultation."
  },
  // SEO metadata
  {
    "key": "seo_title",
    "section": "common",
    "uk": "SOBI - Стань водієм Uber, Bolt в Труймясті",
    "ru": "SOBI - Стань водителем Uber, Bolt в Трёхградье",
    "pl": "SOBI - Zostań kierowcą Uber, Bolt w Trójmieście",
    "en": "SOBI - Become an Uber, Bolt Driver in Tri-City"
  },
  {
    "key": "seo_description",
    "section": "common",
    "uk": "Працюй водієм таксі в Труймясті - сам встановлюй свій графік. Понад 6 років підтримуємо водіїв. Допомога з ліцензією, якісний автопарк, підтримка 24/7.",
    "ru": "Работай водителем такси в Трёхградье - сам устанавливай свой график. Более 6 лет поддерживаем водителей. Помощь с лицензией, качественный автопарк, поддержка 24/7.",
    "pl": "Pracuj jako kierowca taksówki w Trójmieście - sam ustalaj grafik. Ponad 6 lat wspieramy kierowców. Pomoc z licencją, jakościowa flota, wsparcie 24/7.",
    "en": "Work as a taxi driver in Tri-City - set your own schedule. Over 6 years supporting drivers. License assistance, quality fleet, 24/7 support."
  },
  {
    "key": "seo_keywords",
    "section": "common",
    "uk": "SOBI, водій такси, Uber, Bolt, Труймясто, Гданськ, Гдиня, Сопот, робота водієм, таксі",
    "ru": "SOBI, водитель такси, Uber, Bolt, Трёхградье, Гданьск, Гдыня, Сопот, работа водителем, такси",
    "pl": "SOBI, kierowca taxi, Uber, Bolt, Trójmiasto, Gdańsk, Gdynia, Sopot, praca kierowcy, taksówka",
    "en": "SOBI, taxi driver, Uber, Bolt, Tri-City, Gdansk, Gdynia, Sopot, driver job, taxi"
  },
  // ===== New design (2026) – texts used by components/v2 (prefix "ui_") =====
  {
    "key": "ui_a_home",
    "section": "common",
    "uk": "SOBI – головна сторінка",
    "ru": "SOBI – главная страница",
    "pl": "SOBI – strona główna",
    "en": "SOBI – home page"
  },
  {
    "key": "ui_a_nav",
    "section": "common",
    "uk": "Головна навігація",
    "ru": "Главная навигация",
    "pl": "Główna nawigacja",
    "en": "Main navigation"
  },
  {
    "key": "ui_nav_home",
    "section": "common",
    "uk": "Головна",
    "ru": "Главная",
    "pl": "Główna",
    "en": "Home"
  },
  {
    "key": "ui_nav_about",
    "section": "common",
    "uk": "Про компанію",
    "ru": "О компании",
    "pl": "O firmie",
    "en": "About"
  },
  {
    "key": "ui_nav_fleet",
    "section": "common",
    "uk": "Автопарк",
    "ru": "Автопарк",
    "pl": "Flota",
    "en": "Fleet"
  },
  {
    "key": "ui_nav_own",
    "section": "common",
    "uk": "Власне авто",
    "ru": "Своё авто",
    "pl": "Własne auto",
    "en": "Own car"
  },
  {
    "key": "ui_nav_contact",
    "section": "common",
    "uk": "Контакт",
    "ru": "Контакт",
    "pl": "Kontakt",
    "en": "Contact"
  },
  {
    "key": "ui_nav_calc",
    "section": "common",
    "uk": "Калькулятор",
    "ru": "Калькулятор",
    "pl": "Kalkulator",
    "en": "Calculator"
  },
  {
    "key": "ui_call",
    "section": "common",
    "uk": "Подзвонити",
    "ru": "Позвонить",
    "pl": "Zadzwoń",
    "en": "Call"
  },
  {
    "key": "ui_a_lang",
    "section": "common",
    "uk": "Змінити мову",
    "ru": "Сменить язык",
    "pl": "Zmień język",
    "en": "Change language"
  },
  {
    "key": "ui_a_menu",
    "section": "common",
    "uk": "Меню",
    "ru": "Меню",
    "pl": "Menu",
    "en": "Menu"
  },
  {
    "key": "ui_a_mnav",
    "section": "common",
    "uk": "Мобільне меню",
    "ru": "Мобильное меню",
    "pl": "Menu mobilne",
    "en": "Mobile menu"
  },
  {
    "key": "ui_f_address",
    "section": "common",
    "uk": "Адреса",
    "ru": "Адрес",
    "pl": "Adres",
    "en": "Address"
  },
  {
    "key": "ui_f_social",
    "section": "common",
    "uk": "Соцмережі",
    "ru": "Соцсети",
    "pl": "Media społecznościowe",
    "en": "Social media"
  },
  {
    "key": "ui_a_totop",
    "section": "common",
    "uk": "Повернутися нагору",
    "ru": "Вернуться наверх",
    "pl": "Wróć na górę strony",
    "en": "Back to top"
  },
  {
    "key": "ui_totop_ring",
    "section": "common",
    "uk": "НАГОРУ • НАГОРУ • НАГОРУ •",
    "ru": "НАВЕРХ • НАВЕРХ • НАВЕРХ •",
    "pl": "DO GÓRY • DO GÓRY • DO GÓRY •",
    "en": "TO TOP • TO TOP • TO TOP •"
  },
  {
    "key": "ui_rights",
    "section": "common",
    "uk": "© 2026 SOBI. Усі права захищені.",
    "ru": "© 2026 SOBI. Все права защищены.",
    "pl": "© 2026 SOBI. All rights reserved.",
    "en": "© 2026 SOBI. All rights reserved."
  },
  {
    "key": "ui_thanks",
    "section": "common",
    "uk": "Дякуємо! Ми зв'яжемося з тобою найближчим часом.",
    "ru": "Спасибо! Мы свяжемся с тобой в ближайшее время.",
    "pl": "Dziękujemy! Skontaktujemy się z Tobą wkrótce.",
    "en": "Thank you! We'll contact you soon."
  },
  {
    "key": "ui_back",
    "section": "common",
    "uk": "Повернутися до форми",
    "ru": "Вернуться к форме",
    "pl": "Wróć do formularza",
    "en": "Back to the form"
  },
  {
    "key": "ui_f_name",
    "section": "common",
    "uk": "Ім'я",
    "ru": "Имя",
    "pl": "Imię",
    "en": "Name"
  },
  {
    "key": "ui_f_phone",
    "section": "common",
    "uk": "Номер телефону",
    "ru": "Номер телефона",
    "pl": "Numer telefonu",
    "en": "Phone number"
  },
  {
    "key": "ui_f_city",
    "section": "common",
    "uk": "Місто",
    "ru": "Город",
    "pl": "Miasto",
    "en": "City"
  },
  {
    "key": "ui_f_comment",
    "section": "common",
    "uk": "Коментар",
    "ru": "Комментарий",
    "pl": "Komentarz",
    "en": "Comment"
  },
  {
    "key": "ui_f_submit",
    "section": "common",
    "uk": "Надіслати заявку",
    "ru": "Отправить заявку",
    "pl": "Wyślij zgłoszenie",
    "en": "Send application"
  },
  {
    "key": "ui_join",
    "section": "common",
    "uk": "Приєднуйся до SOBI",
    "ru": "Присоединяйся к SOBI",
    "pl": "Dołącz do SOBI",
    "en": "Join SOBI"
  },
  {
    "key": "ui_calc_btn",
    "section": "common",
    "uk": "Розрахувати заробіток",
    "ru": "Рассчитать заработок",
    "pl": "Oblicz zarobek",
    "en": "Calculate earnings"
  },
  {
    "key": "ui_pr_48",
    "section": "common",
    "uk": "48 годин",
    "ru": "48 часов",
    "pl": "48 godzin",
    "en": "48 hours"
  },
  {
    "key": "ui_tricity",
    "section": "common",
    "uk": "Труймісто",
    "ru": "Труймясто",
    "pl": "Trójmiasto",
    "en": "Tri-City"
  },
  {
    "key": "ui_around",
    "section": "common",
    "uk": "Околиці",
    "ru": "Окрестности",
    "pl": "Okolice",
    "en": "Surroundings"
  },
  {
    "key": "ui_city_gdansk",
    "section": "common",
    "uk": "Гданськ",
    "ru": "Гданьск",
    "pl": "Gdańsk",
    "en": "Gdańsk"
  },
  {
    "key": "ui_city_gdynia",
    "section": "common",
    "uk": "Гдиня",
    "ru": "Гдыня",
    "pl": "Gdynia",
    "en": "Gdynia"
  },
  {
    "key": "ui_city_sopot",
    "section": "common",
    "uk": "Сопот",
    "ru": "Сопот",
    "pl": "Sopot",
    "en": "Sopot"
  },
  {
    "key": "ui_city_rumia",
    "section": "common",
    "uk": "Румія",
    "ru": "Румия",
    "pl": "Rumia",
    "en": "Rumia"
  },
  {
    "key": "ui_city_reda",
    "section": "common",
    "uk": "Реда",
    "ru": "Реда",
    "pl": "Reda",
    "en": "Reda"
  },
  {
    "key": "ui_city_kosakowo",
    "section": "common",
    "uk": "Косаково",
    "ru": "Косаково",
    "pl": "Kosakowo",
    "en": "Kosakowo"
  },
  {
    "key": "ui_city_pruszcz",
    "section": "common",
    "uk": "Прушч-Гданський",
    "ru": "Прущ-Гданьский",
    "pl": "Pruszcz Gdański",
    "en": "Pruszcz Gdański"
  },
  {
    "key": "ui_a_map",
    "section": "common",
    "uk": "Мапа: Реда, Румія, Косаково, Гдиня, Сопот, Гданськ, Прушч-Гданський",
    "ru": "Карта: Реда, Румия, Косаково, Гдыня, Сопот, Гданьск, Прущ-Гданьский",
    "pl": "Mapa: Reda, Rumia, Kosakowo, Gdynia, Sopot, Gdańsk, Pruszcz Gdański",
    "en": "Map: Reda, Rumia, Kosakowo, Gdynia, Sopot, Gdańsk, Pruszcz Gdański"
  },
  {
    "key": "ui_sea1",
    "section": "common",
    "uk": "Гданська",
    "ru": "Гданьский",
    "pl": "Zatoka",
    "en": "Gulf of"
  },
  {
    "key": "ui_sea2",
    "section": "common",
    "uk": "затока",
    "ru": "залив",
    "pl": "Gdańska",
    "en": "Gdańsk"
  },
  {
    "key": "ui_badge1",
    "section": "common",
    "uk": "міст і гмін",
    "ru": "городов и гмин",
    "pl": "miast i gmin",
    "en": "towns and"
  },
  {
    "key": "ui_badge2",
    "section": "common",
    "uk": "у виписках",
    "ru": "в выписках",
    "pl": "na wypisach",
    "en": "municipalities"
  },
  {
    "key": "ui_st3",
    "section": "common",
    "uk": "польська, українська, російська, англійська",
    "ru": "польский, украинский, русский, английский",
    "pl": "polski, ukraiński, rosyjski, angielski",
    "en": "Polish, Ukrainian, Russian, English"
  },
  {
    "key": "ui_st4",
    "section": "common",
    "uk": "на зв'язку телефоном і поштою",
    "ru": "на связи по телефону и почте",
    "pl": "jesteśmy dostępni przez telefon i mail",
    "en": "available by phone and email"
  },
  {
    "key": "ui_lang_card",
    "section": "common",
    "uk": "Контакт твоєю мовою",
    "ru": "Контакт на твоём языке",
    "pl": "Kontakt w Twoim języku",
    "en": "Contact in your language"
  },
  {
    "key": "ui_b5h",
    "section": "common",
    "uk": "Виплати щотижня",
    "ru": "Выплаты каждую неделю",
    "pl": "Wypłaty co tydzień",
    "en": "Weekly payouts"
  },
  {
    "key": "ui_p3h",
    "section": "common",
    "uk": "Підтримка 24/7",
    "ru": "Поддержка 24/7",
    "pl": "Wsparcie 24/7",
    "en": "24/7 support"
  },
  {
    "key": "ui_req_age",
    "section": "common",
    "uk": "вік від 18 років",
    "ru": "возраст от 18 лет",
    "pl": "ukończone 18 lat",
    "en": "at least 18 years old"
  },
  {
    "key": "ui_req_lic",
    "section": "common",
    "uk": "польські водійські права",
    "ru": "польское водительское удостоверение",
    "pl": "polskie prawo jazdy",
    "en": "Polish driving licence"
  },
  {
    "key": "ui_req_crim",
    "section": "common",
    "uk": "довідка про несудимість (дійсна 30 днів)",
    "ru": "справка об отсутствии судимости (действительна 30 дней)",
    "pl": "zaświadczenie o niekaralności ważne 30 dni",
    "en": "certificate of no criminal record (valid 30 days)"
  },
  {
    "key": "ui_req_med",
    "section": "common",
    "uk": "медична та психологічна довідка для роботи водієм таксі",
    "ru": "медицинское и психологическое заключение для работы водителем такси",
    "pl": "orzeczenie lekarskie i psychologiczne do pracy jako kierowca TAXI",
    "en": "medical and psychological certificates for taxi drivers"
  },
  {
    "key": "ui_per_week",
    "section": "common",
    "uk": "zł / тиждень",
    "ru": "zł / неделя",
    "pl": "zł / tydzień",
    "en": "zł / week"
  },
  {
    "key": "ui_own_note",
    "section": "common",
    "uk": "Без оплати оренди – від доходу віднімаємо лише 8% і 50 zł.",
    "ru": "Без оплаты аренды – из дохода вычитаем только 8% и 50 zł.",
    "pl": "Bez kosztu wynajmu – od dochodu odejmujemy tylko 8% i 50 zł.",
    "en": "No rental cost – we only deduct 8% and 50 zł from your income."
  },
  {
    "key": "ui_netto",
    "section": "common",
    "uk": "Чистий дохід",
    "ru": "Чистый доход",
    "pl": "Dochód netto",
    "en": "Net income"
  },
  {
    "key": "ui_minus_rent",
    "section": "common",
    "uk": "− оренда авто",
    "ru": "− аренда авто",
    "pl": "− wynajem auta",
    "en": "− car rental"
  },
  {
    "key": "ui_step2",
    "section": "common",
    "uk": "Автомобіль",
    "ru": "Автомобиль",
    "pl": "Samochód",
    "en": "Car"
  },
  {
    "key": "ui_t_48",
    "section": "common",
    "uk": "Старт за 48 годин",
    "ru": "Старт за 48 часов",
    "pl": "Start w 48 godzin",
    "en": "Start in 48 hours"
  },
  {
    "key": "ui_t_lic",
    "section": "common",
    "uk": "Виписки на 7 міст і гмін",
    "ru": "Выписки на 7 городов и гмин",
    "pl": "Wypisy na 7 miast i gmin",
    "en": "Licence extracts for 7 towns"
  },
  {
    "key": "ui_t_ref",
    "section": "common",
    "uk": "До 500 zł за рекомендацію",
    "ru": "До 500 zł за рекомендацию",
    "pl": "Do 500 zł za polecenie",
    "en": "Up to 500 zł per referral"
  },
  {
    "key": "ui_t_fuel",
    "section": "common",
    "uk": "Знижки на пальне MOL",
    "ru": "Скидки на топливо MOL",
    "pl": "Zniżki na paliwo MOL",
    "en": "MOL fuel discounts"
  },
  {
    "key": "ui_eyebrow",
    "section": "common",
    "uk": "Труймісто · Гданськ · Гдиня · Сопот",
    "ru": "Труймясто · Гданьск · Гдыня · Сопот",
    "pl": "Trójmiasto · Gdańsk · Gdynia · Sopot",
    "en": "Tri-City · Gdańsk · Gdynia · Sopot"
  },
  {
    "key": "ui_h_l1",
    "section": "common",
    "uk": "Стань",
    "ru": "Стань",
    "pl": "Zostań",
    "en": "Become a"
  },
  {
    "key": "ui_h_l2",
    "section": "common",
    "uk": "водієм",
    "ru": "водителем",
    "pl": "kierowcą",
    "en": "driver for"
  },
  {
    "key": "ui_hero_sub",
    "section": "common",
    "uk": "Працюй водієм таксі в Труймісті – сам обирай графік!",
    "ru": "Работай водителем такси в Труймясте – сам выбирай график!",
    "pl": "Pracuj jako kierowca TAXI w Trójmieście – sam ustalaj grafik!",
    "en": "Work as a taxi driver in the Tri-City – set your own schedule!"
  },
  {
    "key": "ui_pr_48_l",
    "section": "common",
    "uk": "і ти вже працюєш",
    "ru": "и ты уже работаешь",
    "pl": "i zaczynasz pracę",
    "en": "and you start working"
  },
  {
    "key": "ui_pr_0_l",
    "section": "common",
    "uk": "витрат на старт",
    "ru": "расходов на старт",
    "pl": "wydatków na start",
    "en": "start-up costs"
  },
  {
    "key": "ui_scroll",
    "section": "common",
    "uk": "Гортай униз",
    "ru": "Листай вниз",
    "pl": "Przewiń w dół",
    "en": "Scroll down"
  },
  {
    "key": "ui_badge_ring",
    "section": "common",
    "uk": "6 РОКІВ У ТРУЙМІСТІ • ВИПЛАТИ ЩОТИЖНЯ •",
    "ru": "6 ЛЕТ В ТРУЙМЯСТЕ • ВЫПЛАТЫ КАЖДУЮ НЕДЕЛЮ •",
    "pl": "OD 6 LAT W TRÓJMIEŚCIE • WYPŁATY CO TYDZIEŃ •",
    "en": "6 YEARS IN THE TRI-CITY • WEEKLY PAYOUTS •"
  },
  {
    "key": "ui_years",
    "section": "common",
    "uk": "років",
    "ru": "лет",
    "pl": "lat",
    "en": "years"
  },
  {
    "key": "ui_alt_camry",
    "section": "common",
    "uk": "Toyota Camry з автопарку SOBI",
    "ru": "Toyota Camry из автопарка SOBI",
    "pl": "Toyota Camry z floty SOBI",
    "en": "Toyota Camry from the SOBI fleet"
  },
  {
    "key": "ui_a_tapes",
    "section": "common",
    "uk": "Головні переваги",
    "ru": "Главные преимущества",
    "pl": "Najważniejsze korzyści",
    "en": "Key benefits"
  },
  {
    "key": "ui_a_stats",
    "section": "common",
    "uk": "SOBI в цифрах",
    "ru": "SOBI в цифрах",
    "pl": "SOBI w liczbach",
    "en": "SOBI in numbers"
  },
  {
    "key": "ui_st1",
    "section": "common",
    "uk": "підтримуємо водіїв у Труймісті",
    "ru": "поддерживаем водителей в Труймясте",
    "pl": "wspieramy kierowców w Trójmieście",
    "en": "supporting drivers in the Tri-City"
  },
  {
    "key": "ui_st_apps",
    "section": "common",
    "uk": "застосунки",
    "ru": "приложения",
    "pl": "aplikacje",
    "en": "apps"
  },
  {
    "key": "ui_st2",
    "section": "common",
    "uk": "Uber, Bolt, FreeNow та iTaxi",
    "ru": "Uber, Bolt, FreeNow и iTaxi",
    "pl": "Uber, Bolt, FreeNow i iTaxi",
    "en": "Uber, Bolt, FreeNow and iTaxi"
  },
  {
    "key": "ui_st_langs",
    "section": "common",
    "uk": "мови",
    "ru": "языка",
    "pl": "języki",
    "en": "languages"
  },
  {
    "key": "ui_st_support",
    "section": "common",
    "uk": "підтримка",
    "ru": "поддержка",
    "pl": "wsparcie",
    "en": "support"
  },
  {
    "key": "ui_lic_k",
    "section": "common",
    "uk": "Виписки з ліцензії",
    "ru": "Выписки из лицензии",
    "pl": "Wypisy z licencji",
    "en": "Licence extracts"
  },
  {
    "key": "ui_lic_h",
    "section": "common",
    "uk": "Їздиш у 7 містах, а не в одному",
    "ru": "Ездишь в 7 городах, а не в одном",
    "pl": "Jeździsz w 7 miastach, nie w jednym",
    "en": "Drive in 7 towns, not just one"
  },
  {
    "key": "ui_lic_p",
    "section": "common",
    "uk": "Маємо виписки з ліцензії не лише на Гданськ, Гдиню і Сопот, а й на Румію, Реду, Косаково та Прушч-Гданський. Їздиш по всьому Труймісту й околицях.",
    "ru": "У нас есть выписки из лицензии не только на Гданьск, Гдыню и Сопот, но и на Румию, Реду, Косаково и Прущ-Гданьский. Ездишь по всему Труймясту и окрестностям.",
    "pl": "Mamy wypisy z licencji nie tylko na Gdańsk, Gdynię i Sopot, ale też na Rumię, Redę, Kosakowo i Pruszcz Gdański. Jeździsz w całym Trójmieście i okolicy.",
    "en": "We hold licence extracts not only for Gdańsk, Gdynia and Sopot, but also for Rumia, Reda, Kosakowo and Pruszcz Gdański. You drive across the whole Tri-City area."
  },
  {
    "key": "ui_k_about",
    "section": "common",
    "uk": "01 — Про компанію",
    "ru": "01 — О компании",
    "pl": "01 — O firmie",
    "en": "01 — About us"
  },
  {
    "key": "ui_why",
    "section": "common",
    "uk": "Чому SOBI?",
    "ru": "Почему SOBI?",
    "pl": "Dlaczego SOBI?",
    "en": "Why SOBI?"
  },
  {
    "key": "ui_years_exp",
    "section": "common",
    "uk": "Уже понад 6 років підтримуємо водіїв у Труймісті",
    "ru": "Уже более 6 лет поддерживаем водителей в Труймясте",
    "pl": "Od 6 lat wspieramy kierowców w Trójmieście",
    "en": "Supporting drivers in the Tri-City for over 6 years"
  },
  {
    "key": "ui_alt_driver",
    "section": "common",
    "uk": "Водій SOBI в авто",
    "ru": "Водитель SOBI в машине",
    "pl": "Kierowca SOBI w samochodzie",
    "en": "SOBI driver in the car"
  },
  {
    "key": "ui_b1h",
    "section": "common",
    "uk": "Допомога з ліцензією",
    "ru": "Помощь с лицензией",
    "pl": "Wsparcie w procesie licencyjnym",
    "en": "Help with licensing"
  },
  {
    "key": "ui_b1p",
    "section": "common",
    "uk": "медогляди, документи, офіційні формальності",
    "ru": "медосмотры, документы, формальности в учреждениях",
    "pl": "badania, dokumenty, urzędowe formalności",
    "en": "medical checks, paperwork, official formalities"
  },
  {
    "key": "ui_b2h",
    "section": "common",
    "uk": "Орієнтуємось на якість, а не на швидкість",
    "ru": "Делаем ставку на качество, а не на скорость",
    "pl": "Działamy nie na szybkość, a na jakość",
    "en": "We focus on quality, not just speed"
  },
  {
    "key": "ui_b3h",
    "section": "common",
    "uk": "Автопарк на вибір",
    "ru": "Автопарк на выбор",
    "pl": "Flota do wyboru",
    "en": "Fleet to choose from"
  },
  {
    "key": "ui_b3p",
    "section": "common",
    "uk": "якщо в тебе немає авто, можеш орендувати його в нас",
    "ru": "если у тебя нет авто, можешь арендовать его у нас",
    "pl": "jeśli nie masz pojazdu, możesz go u nas wynająć",
    "en": "if you don't have a car, you can rent one from us"
  },
  {
    "key": "ui_b4h",
    "section": "common",
    "uk": "Власна автомайстерня",
    "ru": "Собственная автомастерская",
    "pl": "Własny warsztat samochodowy",
    "en": "Our own car workshop"
  },
  {
    "key": "ui_b4p",
    "section": "common",
    "uk": "обслуговуємо наші авто й авто водіїв – зі знижками на запчастини та ремонт",
    "ru": "обслуживаем наши авто и машины водителей – со скидками на запчасти и ремонт",
    "pl": "serwisujemy nasze auta i pojazdy kierowców – ze zniżkami na części i naprawy",
    "en": "we service our cars and drivers' own cars – with discounts on parts and repairs"
  },
  {
    "key": "ui_b5p",
    "section": "common",
    "uk": "зі зручним розрахунком",
    "ru": "с удобным расчётом",
    "pl": "z wygodnym rozliczeniem",
    "en": "with easy settlement"
  },
  {
    "key": "ui_partners_h",
    "section": "common",
    "uk": "Партнерські переваги",
    "ru": "Партнёрские преимущества",
    "pl": "Benefity partnerskie",
    "en": "Partner benefits"
  },
  {
    "key": "ui_p1h",
    "section": "common",
    "uk": "Знижки на пальне",
    "ru": "Скидки на топливо",
    "pl": "Zniżki na paliwo",
    "en": "Fuel discounts"
  },
  {
    "key": "ui_p1p",
    "section": "common",
    "uk": "завдяки співпраці зі станціями MOL Group",
    "ru": "благодаря сотрудничеству со станциями MOL Group",
    "pl": "dzięki współpracy ze stacjami MOL Group",
    "en": "thanks to our partnership with MOL Group stations"
  },
  {
    "key": "ui_p2h",
    "section": "common",
    "uk": "Гнучкі форми співпраці",
    "ru": "Гибкие формы сотрудничества",
    "pl": "Elastyczne formy współpracy",
    "en": "Flexible cooperation"
  },
  {
    "key": "ui_p2p",
    "section": "common",
    "uk": "договір доручення або B2B",
    "ru": "договор поручения или B2B",
    "pl": "umowa zlecenie lub B2B",
    "en": "contract of mandate or B2B"
  },
  {
    "key": "ui_p4h",
    "section": "common",
    "uk": "Програма рекомендацій",
    "ru": "Программа рекомендаций",
    "pl": "Program rekomendacji",
    "en": "Referral programme"
  },
  {
    "key": "ui_p4p",
    "section": "common",
    "uk": "рекомендуєш знайомого водія – отримуєш до 500 zł",
    "ru": "рекомендуешь знакомого водителя – получаешь до 500 zł",
    "pl": "polecasz znajomego kierowcę – zyskujesz do 500 zł",
    "en": "recommend a driver friend – earn up to 500 zł"
  },
  {
    "key": "ui_k_apps",
    "section": "common",
    "uk": "02 — Застосунки",
    "ru": "02 — Приложения",
    "pl": "02 — Aplikacje",
    "en": "02 — Apps"
  },
  {
    "key": "ui_apps_h",
    "section": "common",
    "uk": "Працюй водієм і заробляй у популярних застосунках",
    "ru": "Работай водителем и зарабатывай в популярных приложениях",
    "pl": "Pracuj jako kierowca i zarabiaj w popularnych aplikacjach",
    "en": "Work as a driver and earn in popular apps"
  },
  {
    "key": "ui_apps_p",
    "section": "common",
    "uk": "Ми співпрацюємо з провідними платформами, щоб ти заробляв якомога більше",
    "ru": "Мы сотрудничаем с ведущими платформами, чтобы ты зарабатывал как можно больше",
    "pl": "Współpracujemy z wiodącymi platformami, aby zmaksymalizować Twoje zarobki",
    "en": "We partner with leading platforms to maximise your earnings"
  },
  {
    "key": "ui_k_req",
    "section": "common",
    "uk": "03 — Вимоги",
    "ru": "03 — Требования",
    "pl": "03 — Wymagania",
    "en": "03 — Requirements"
  },
  {
    "key": "ui_req_h",
    "section": "common",
    "uk": "Які умови потрібно виконати, щоб почати роботу?",
    "ru": "Какие условия нужно выполнить, чтобы начать работу?",
    "pl": "Jakie warunki należy spełnić, żeby zacząć pracę?",
    "en": "What do you need to start working?"
  },
  {
    "key": "ui_req_car",
    "section": "common",
    "uk": "авто, що відповідає вимогам застосунків, – або оренда авто в нас",
    "ru": "автомобиль, соответствующий требованиям приложений, – или аренда авто у нас",
    "pl": "samochód spełniający wymagania aplikacji – albo wynajem auta u nas",
    "en": "a car that meets the app requirements – or rent one from us"
  },
  {
    "key": "ui_replay",
    "section": "common",
    "uk": "Подивитися ще раз",
    "ru": "Посмотреть ещё раз",
    "pl": "Zobacz jeszcze raz",
    "en": "Watch again"
  },
  {
    "key": "ui_own_link",
    "section": "common",
    "uk": "Маєш власне авто? Дивись, як почати",
    "ru": "Есть своё авто? Смотри, как начать",
    "pl": "Masz własne auto? Zobacz, jak zacząć",
    "en": "Have your own car? See how to start"
  },
  {
    "key": "ui_k_fleet",
    "section": "common",
    "uk": "04 — Автопарк",
    "ru": "04 — Автопарк",
    "pl": "04 — Flota",
    "en": "04 — Fleet"
  },
  {
    "key": "ui_fleet_h",
    "section": "common",
    "uk": "Наш автопарк",
    "ru": "Наш автопарк",
    "pl": "Nasza flota",
    "en": "Our fleet"
  },
  {
    "key": "ui_fleet_p",
    "section": "common",
    "uk": "Сучасний автопарк для комфортної роботи",
    "ru": "Современный автопарк для комфортной работы",
    "pl": "Nowoczesna flota dla komfortowej pracy",
    "en": "A modern fleet for comfortable work"
  },
  {
    "key": "ui_a_filter",
    "section": "common",
    "uk": "Фільтр авто",
    "ru": "Фильтр авто",
    "pl": "Filtruj auta",
    "en": "Filter cars"
  },
  {
    "key": "ui_avail",
    "section": "common",
    "uk": "Доступне",
    "ru": "Доступен",
    "pl": "Dostępny",
    "en": "Available"
  },
  {
    "key": "ui_flt_all",
    "section": "common",
    "uk": "Усі",
    "ru": "Все",
    "pl": "Wszystkie",
    "en": "All"
  },
  {
    "key": "ui_flt_hyb",
    "section": "common",
    "uk": "Гібриди",
    "ru": "Гибриды",
    "pl": "Hybrydy",
    "en": "Hybrids"
  },
  {
    "key": "ui_flt_lpg",
    "section": "common",
    "uk": "З ГБО",
    "ru": "С ГБО",
    "pl": "Z instalacją LPG",
    "en": "With LPG"
  },
  {
    "key": "ui_fuel_lpg",
    "section": "common",
    "uk": "Бензин + ГБО",
    "ru": "Бензин + ГБО",
    "pl": "Benzyna + LPG",
    "en": "Petrol + LPG"
  },
  {
    "key": "ui_fuel_pb",
    "section": "common",
    "uk": "Бензин",
    "ru": "Бензин",
    "pl": "Benzyna",
    "en": "Petrol"
  },
  {
    "key": "ui_fuel_hyb",
    "section": "common",
    "uk": "Бензин · гібрид",
    "ru": "Бензин · гибрид",
    "pl": "Benzyna · hybryda",
    "en": "Petrol · hybrid"
  },
  {
    "key": "ui_per_week_long",
    "section": "common",
    "uk": "zł на тиждень",
    "ru": "zł в неделю",
    "pl": "zł za tydzień",
    "en": "zł per week"
  },
  {
    "key": "ui_k_shop",
    "section": "common",
    "uk": "05 — Майстерня",
    "ru": "05 — Автосервис",
    "pl": "05 — Warsztat",
    "en": "05 — Workshop"
  },
  {
    "key": "ui_shop_h",
    "section": "common",
    "uk": "Поломка? Ремонтуємо без черги – ти не втрачаєш робочих днів",
    "ru": "Поломка? Ремонтируем без очереди – ты не теряешь рабочие дни",
    "pl": "Awaria? Naprawiamy bez kolejki – nie tracisz dni pracy",
    "en": "Breakdown? We fix it with no queue – you don't lose working days"
  },
  {
    "key": "ui_shop_p",
    "section": "common",
    "uk": "Власна майстерня SOBI – для авто з нашого автопарку та приватних авто наших водіїв.",
    "ru": "Собственный автосервис SOBI – для авто из нашего автопарка и личных авто наших водителей.",
    "pl": "Własny warsztat SOBI – dla aut z naszej floty i prywatnych aut naszych kierowców.",
    "en": "SOBI's own workshop – for our fleet cars and our drivers' private cars."
  },
  {
    "key": "ui_w1h",
    "section": "common",
    "uk": "Обслуговування без черги",
    "ru": "Обслуживание без очереди",
    "pl": "Obsługa bez kolejki",
    "en": "No-queue service"
  },
  {
    "key": "ui_w1p",
    "section": "common",
    "uk": "авто з автопарку й приватні авто водіїв",
    "ru": "авто из автопарка и личные авто водителей",
    "pl": "flotowe i prywatne auta kierowców",
    "en": "fleet cars and drivers' private cars"
  },
  {
    "key": "ui_w2h",
    "section": "common",
    "uk": "Знижки на запчастини та ремонт",
    "ru": "Скидки на запчасти и ремонт",
    "pl": "Zniżki na części i naprawy",
    "en": "Discounts on parts and repairs"
  },
  {
    "key": "ui_w2p",
    "section": "common",
    "uk": "спеціальні ціни для наших водіїв на всі види робіт",
    "ru": "специальные цены для наших водителей на все виды работ",
    "pl": "specjalne ceny dla naszych kierowców na wszystkie rodzaje prac",
    "en": "special prices for our drivers on all types of work"
  },
  {
    "key": "ui_w3h",
    "section": "common",
    "uk": "Повний сервіс автопарку",
    "ru": "Полный сервис автопарка",
    "pl": "Pełny serwis flotowy",
    "en": "Full fleet service"
  },
  {
    "key": "ui_w3p",
    "section": "common",
    "uk": "заміна лампочок, двірників, шин, поточний ремонт",
    "ru": "замена лампочек, дворников, шин, текущий ремонт",
    "pl": "wymiana żarówek, wycieraczek, opon, naprawy bieżące",
    "en": "bulbs, wipers, tyres, day-to-day repairs"
  },
  {
    "key": "ui_maps_btn",
    "section": "common",
    "uk": "Майстерня в Google Maps",
    "ru": "Автосервис в Google Maps",
    "pl": "Warsztat w Google Maps",
    "en": "Workshop on Google Maps"
  },
  {
    "key": "ui_map_card",
    "section": "common",
    "uk": "SOBI Partner – майстерня",
    "ru": "SOBI Partner – автосервис",
    "pl": "SOBI Partner – warsztat",
    "en": "SOBI Partner – workshop"
  },
  {
    "key": "ui_motto1",
    "section": "common",
    "uk": "Ти лише їздиш і заробляєш –",
    "ru": "Ты только ездишь и зарабатываешь –",
    "pl": "Ty tylko jeździsz i zarabiasz –",
    "en": "You just drive and earn –"
  },
  {
    "key": "ui_motto2",
    "section": "common",
    "uk": "ми дбаємо про все інше!",
    "ru": "мы заботимся обо всём остальном!",
    "pl": "my dbamy o resztę!",
    "en": "we take care of the rest!"
  },
  {
    "key": "ui_ref_k",
    "section": "common",
    "uk": "Програма рекомендацій",
    "ru": "Программа рекомендаций",
    "pl": "Program poleceń",
    "en": "Referral programme"
  },
  {
    "key": "ui_ref_h",
    "section": "common",
    "uk": "Порекомендуй водія – отримай до 500 zł",
    "ru": "Порекомендуй водителя – получи до 500 zł",
    "pl": "Poleć kierowcę – zgarnij do 500 zł",
    "en": "Refer a driver – get up to 500 zł"
  },
  {
    "key": "ui_ref_p",
    "section": "common",
    "uk": "Знаєш когось, хто шукає роботу водієм? Запроси його в SOBI – за кожного нового водія отримуєш бонус до 500 zł.",
    "ru": "Знаешь кого-то, кто ищет работу водителем? Пригласи его в SOBI – за каждого нового водителя получаешь бонус до 500 zł.",
    "pl": "Znasz kogoś, kto szuka pracy jako kierowca? Zaproś go do SOBI – za każdego nowego kierowcę dostajesz bonus do 500 zł.",
    "en": "Know someone looking for work as a driver? Invite them to SOBI – for every new driver you get a bonus of up to 500 zł."
  },
  {
    "key": "ui_rs1b",
    "section": "common",
    "uk": "Рекомендуєш SOBI",
    "ru": "Рекомендуешь SOBI",
    "pl": "Polecasz SOBI",
    "en": "You recommend SOBI"
  },
  {
    "key": "ui_rs1s",
    "section": "common",
    "uk": "знайомому, який хоче їздити",
    "ru": "знакомому, который хочет ездить",
    "pl": "znajomemu, który chce jeździć",
    "en": "to a friend who wants to drive"
  },
  {
    "key": "ui_rs2b",
    "section": "common",
    "uk": "Знайомий приєднується",
    "ru": "Знакомый присоединяется",
    "pl": "Znajomy dołącza",
    "en": "Your friend joins"
  },
  {
    "key": "ui_rs2s",
    "section": "common",
    "uk": "і починає їздити з SOBI",
    "ru": "и начинает ездить с SOBI",
    "pl": "i zaczyna jeździć z SOBI",
    "en": "and starts driving with SOBI"
  },
  {
    "key": "ui_rs3b",
    "section": "common",
    "uk": "Отримуєш бонус",
    "ru": "Получаешь бонус",
    "pl": "Dostajesz bonus",
    "en": "You get a bonus"
  },
  {
    "key": "ui_rs3s",
    "section": "common",
    "uk": "до 500 zł за кожного рекомендованого водія",
    "ru": "до 500 zł за каждого приглашённого водителя",
    "pl": "do 500 zł za każdego poleconego kierowcę",
    "en": "up to 500 zł for every driver you refer"
  },
  {
    "key": "ui_ref_btn",
    "section": "common",
    "uk": "Надіслати рекомендацію",
    "ru": "Отправить рекомендацию",
    "pl": "Zgłoś polecenie",
    "en": "Submit a referral"
  },
  {
    "key": "ui_ref_note",
    "section": "common",
    "uk": "Запитай нас про умови програми.",
    "ru": "Спроси нас об условиях программы.",
    "pl": "Zapytaj nas o warunki programu.",
    "en": "Ask us about the programme terms."
  },
  {
    "key": "ui_you",
    "section": "common",
    "uk": "Ти",
    "ru": "Ты",
    "pl": "Ty",
    "en": "You"
  },
  {
    "key": "ui_friend",
    "section": "common",
    "uk": "Знайомий",
    "ru": "Знакомый",
    "pl": "Znajomy",
    "en": "Friend"
  },
  {
    "key": "ui_upto",
    "section": "common",
    "uk": "до",
    "ru": "до",
    "pl": "do",
    "en": "up to"
  },
  {
    "key": "ui_ref_cap",
    "section": "common",
    "uk": "бонусу за кожного рекомендованого водія",
    "ru": "бонуса за каждого приглашённого водителя",
    "pl": "bonusu za każdego poleconego kierowcę",
    "en": "bonus for every driver you refer"
  },
  {
    "key": "ui_k_contact",
    "section": "common",
    "uk": "06 — Контакт",
    "ru": "06 — Контакт",
    "pl": "06 — Kontakt",
    "en": "06 — Contact"
  },
  {
    "key": "ui_c_h1",
    "section": "common",
    "uk": "Зацікавився?",
    "ru": "Заинтересовался?",
    "pl": "Jesteś zainteresowany?",
    "en": "Interested?"
  },
  {
    "key": "ui_c_h2",
    "section": "common",
    "uk": "Маєш питання?",
    "ru": "Есть вопросы?",
    "pl": "Masz pytania?",
    "en": "Got questions?"
  },
  {
    "key": "ui_c_p",
    "section": "common",
    "uk": "Заповни форму або зателефонуй нам:",
    "ru": "Заполни форму или позвони нам:",
    "pl": "Zapraszamy do wypełnienia formularza lub kontakt telefoniczny:",
    "en": "Fill in the form or give us a call:"
  },
  {
    "key": "ui_t_zero",
    "section": "common",
    "uk": "0 zł на старт",
    "ru": "0 zł на старт",
    "pl": "0 zł na start",
    "en": "0 zł to start"
  },
  {
    "key": "ui_t_mandate",
    "section": "common",
    "uk": "Договір доручення або B2B",
    "ru": "Договор поручения или B2B",
    "pl": "Umowa zlecenie lub B2B",
    "en": "Mandate contract or B2B"
  },
  {
    "key": "ui_t_shop",
    "section": "common",
    "uk": "Власна майстерня",
    "ru": "Свой автосервис",
    "pl": "Własny warsztat",
    "en": "Own workshop"
  },
  {
    "key": "ui_calc_k",
    "section": "common",
    "uk": "Калькулятор заробітку водія",
    "ru": "Калькулятор заработка водителя",
    "pl": "Kalkulator zarobków kierowcy",
    "en": "Driver earnings calculator"
  },
  {
    "key": "ui_calc_h1",
    "section": "common",
    "uk": "Знаєш, скільки заробиш,",
    "ru": "Знаешь, сколько заработаешь,",
    "pl": "Wiesz, ile zarobisz,",
    "en": "Know what you'll earn"
  },
  {
    "key": "ui_calc_h2",
    "section": "common",
    "uk": "ще до старту",
    "ru": "ещё до старта",
    "pl": "zanim zaczniesz",
    "en": "before you start"
  },
  {
    "key": "ui_a_flow",
    "section": "common",
    "uk": "Як ми рахуємо тижневий прибуток",
    "ru": "Как мы считаем недельную прибыль",
    "pl": "Jak liczymy zysk tygodniowy",
    "en": "How we calculate weekly profit"
  },
  {
    "key": "ui_eq_profit",
    "section": "common",
    "uk": "= Тижневий прибуток",
    "ru": "= Недельная прибыль",
    "pl": "= Zysk tygodniowy",
    "en": "= Weekly profit"
  },
  {
    "key": "ui_step1",
    "section": "common",
    "uk": "Твій дохід",
    "ru": "Твой доход",
    "pl": "Twój dochód",
    "en": "Your income"
  },
  {
    "key": "ui_a_mode",
    "section": "common",
    "uk": "Режим розрахунку",
    "ru": "Режим расчёта",
    "pl": "Tryb kalkulacji",
    "en": "Calculation mode"
  },
  {
    "key": "ui_mode_known",
    "section": "common",
    "uk": "Введи свій чистий дохід",
    "ru": "Введи свой чистый доход",
    "pl": "Wpisz swój dochód netto",
    "en": "Enter your net income"
  },
  {
    "key": "ui_mode_hourly",
    "section": "common",
    "uk": "Розрахувати за годинами",
    "ru": "Рассчитать по часам",
    "pl": "Oblicz na podstawie godzin",
    "en": "Calculate by hours"
  },
  {
    "key": "ui_inc_label",
    "section": "common",
    "uk": "Твій чистий дохід (zł)",
    "ru": "Твой чистый доход (zł)",
    "pl": "Twój dochód netto (zł)",
    "en": "Your net income (zł)"
  },
  {
    "key": "ui_inc_ph",
    "section": "common",
    "uk": "Введи суму",
    "ru": "Введи сумму",
    "pl": "Wpisz kwotę",
    "en": "Enter amount"
  },
  {
    "key": "ui_err_empty",
    "section": "common",
    "uk": "Введи суму свого заробітку, щоб розрахувати чистий дохід",
    "ru": "Введи сумму своего заработка, чтобы рассчитать чистый доход",
    "pl": "Wprowadź kwotę swojego dochodu, aby obliczyć dochód netto",
    "en": "Enter your earnings to calculate net income"
  },
  {
    "key": "ui_err_max",
    "section": "common",
    "uk": "Ти дуже амбітний, але, на жаль, таку суму заробити неможливо",
    "ru": "Ты очень амбициозен, но, к сожалению, такую сумму заработать невозможно",
    "pl": "Jesteś bardzo ambitny, ale niestety nie da się zarobić takiej kwoty",
    "en": "You're very ambitious, but unfortunately it's impossible to earn that much"
  },
  {
    "key": "ui_a_slider",
    "section": "common",
    "uk": "Чистий дохід – повзунок",
    "ru": "Чистый доход – ползунок",
    "pl": "Dochód netto – suwak",
    "en": "Net income – slider"
  },
  {
    "key": "ui_a_quick",
    "section": "common",
    "uk": "Швидкий вибір суми",
    "ru": "Быстрый выбор суммы",
    "pl": "Szybki wybór kwoty",
    "en": "Quick amount choice"
  },
  {
    "key": "ui_rate_l",
    "section": "common",
    "uk": "Ставка за годину (zł)",
    "ru": "Ставка за час (zł)",
    "pl": "Stawka za godzinę (zł)",
    "en": "Hourly rate (zł)"
  },
  {
    "key": "ui_h",
    "section": "common",
    "uk": "год",
    "ru": "ч",
    "pl": "h",
    "en": "h"
  },
  {
    "key": "ui_a_rate",
    "section": "common",
    "uk": "Інформація про ставку",
    "ru": "Информация о ставке",
    "pl": "Informacja o stawce",
    "en": "About the rate"
  },
  {
    "key": "ui_rate_tip",
    "section": "common",
    "uk": "Погодинна ставка може відрізнятися залежно від годин роботи та дня",
    "ru": "Почасовая ставка может отличаться в зависимости от времени работы и дня",
    "pl": "Stawka godzinowa może się różnić w zależności od godzin pracy i dnia",
    "en": "The hourly rate may vary depending on working hours and day"
  },
  {
    "key": "ui_days_l",
    "section": "common",
    "uk": "Днів на тиждень",
    "ru": "Дней в неделю",
    "pl": "Dni w tygodniu",
    "en": "Days per week"
  },
  {
    "key": "ui_hours_l",
    "section": "common",
    "uk": "Годин на день",
    "ru": "Часов в день",
    "pl": "Godzin dziennie",
    "en": "Hours per day"
  },
  {
    "key": "ui_rent",
    "section": "common",
    "uk": "Хочу орендувати авто",
    "ru": "Хочу арендовать авто",
    "pl": "Chcę wynająć samochód",
    "en": "I want to rent a car"
  },
  {
    "key": "ui_own",
    "section": "common",
    "uk": "Маю власне авто",
    "ru": "Есть своё авто",
    "pl": "Mam własny samochód",
    "en": "I have my own car"
  },
  {
    "key": "ui_pick_car",
    "section": "common",
    "uk": "Обери автомобіль:",
    "ru": "Выбери автомобиль:",
    "pl": "Wybierz samochód:",
    "en": "Choose a car:"
  },
  {
    "key": "ui_own_more",
    "section": "common",
    "uk": "Як почати на власному авто",
    "ru": "Как начать на своём авто",
    "pl": "Jak zacząć na własnym aucie",
    "en": "How to start with your own car"
  },
  {
    "key": "ui_rec_t",
    "section": "common",
    "uk": "Рекомендація",
    "ru": "Рекомендация",
    "pl": "Rekomendacja",
    "en": "Recommendation"
  },
  {
    "key": "ui_res_h",
    "section": "common",
    "uk": "Результати розрахунку",
    "ru": "Результаты расчёта",
    "pl": "Wyniki kalkulacji",
    "en": "Calculation results"
  },
  {
    "key": "ui_live",
    "section": "common",
    "uk": "наживо",
    "ru": "онлайн",
    "pl": "na żywo",
    "en": "live"
  },
  {
    "key": "ui_weekly",
    "section": "common",
    "uk": "Тижневий прибуток:",
    "ru": "Недельная прибыль:",
    "pl": "Zysk tygodniowy:",
    "en": "Weekly profit:"
  },
  {
    "key": "ui_weekly2",
    "section": "common",
    "uk": "Тижневий прибуток",
    "ru": "Недельная прибыль",
    "pl": "Zysk tygodniowy",
    "en": "Weekly profit"
  },
  {
    "key": "ui_monthly",
    "section": "common",
    "uk": "Прогнозований місячний прибуток:",
    "ru": "Прогнозируемая месячная прибыль:",
    "pl": "Prognozowany zysk miesięczny:",
    "en": "Projected monthly profit:"
  },
  {
    "key": "ui_leg_profit",
    "section": "common",
    "uk": "Прибуток",
    "ru": "Прибыль",
    "pl": "Zysk",
    "en": "Profit"
  },
  {
    "key": "ui_leg_rent",
    "section": "common",
    "uk": "Оренда",
    "ru": "Аренда",
    "pl": "Wynajem",
    "en": "Rental"
  },
  {
    "key": "ui_r_netto",
    "section": "common",
    "uk": "Чистий дохід (за тиждень):",
    "ru": "Чистый доход (за неделю):",
    "pl": "Dochód netto (tygodniowo):",
    "en": "Net income (weekly):"
  },
  {
    "key": "ui_r_pct",
    "section": "common",
    "uk": "Після вирахування 8%:",
    "ru": "После вычета 8%:",
    "pl": "Po odjęciu 8%:",
    "en": "After 8% deduction:"
  },
  {
    "key": "ui_r_fixed",
    "section": "common",
    "uk": "Після вирахування 50 zł:",
    "ru": "После вычета 50 zł:",
    "pl": "Po odjęciu 50 zł:",
    "en": "After 50 zł deduction:"
  },
  {
    "key": "ui_r_rent",
    "section": "common",
    "uk": "Після вирахування оренди",
    "ru": "После вычета аренды",
    "pl": "Po odjęciu wynajmu",
    "en": "After rental of"
  },
  {
    "key": "ui_fair_b",
    "section": "common",
    "uk": "Без прихованих платежів: лише 8% і 50 zł на тиждень",
    "ru": "Без скрытых платежей: только 8% и 50 zł в неделю",
    "pl": "Bez ukrytych opłat: tylko 8% i 50 zł tygodniowo",
    "en": "No hidden fees: just 8% and 50 zł a week"
  },
  {
    "key": "ui_fair_s",
    "section": "common",
    "uk": "+ вартість оренди, якщо береш авто з нашого автопарку",
    "ru": "+ стоимость аренды, если берёшь авто из нашего автопарка",
    "pl": "+ koszt wynajmu, jeśli wybierasz auto z naszej floty",
    "en": "+ rental cost if you choose a car from our fleet"
  },
  {
    "key": "ui_own_eyebrow",
    "section": "common",
    "uk": "Для водіїв із власним авто",
    "ru": "Для водителей со своим авто",
    "pl": "Dla kierowców z własnym autem",
    "en": "For drivers with their own car"
  },
  {
    "key": "ui_oh1",
    "section": "common",
    "uk": "Маєш",
    "ru": "Есть",
    "pl": "Jeździsz",
    "en": "Got your"
  },
  {
    "key": "ui_oh2",
    "section": "common",
    "uk": "своє авто?",
    "ru": "своё авто?",
    "pl": "swoim autem?",
    "en": "own car?"
  },
  {
    "key": "ui_oh3",
    "section": "common",
    "uk": "Заробляй із SOBI.",
    "ru": "Зарабатывай с SOBI.",
    "pl": "Zarabiaj z SOBI.",
    "en": "Earn with SOBI."
  },
  {
    "key": "ui_own_sub",
    "section": "common",
    "uk": "Працюй в Uber, Bolt, FreeNow та iTaxi на власному авто. Дивись, що потрібно для старту, – а з формальностями ми допоможемо.",
    "ru": "Работай в Uber, Bolt, FreeNow и iTaxi на своём авто. Смотри, что нужно для старта, – а с формальностями мы поможем.",
    "pl": "Pracuj w Uber, Bolt, FreeNow i iTaxi na własnym samochodzie. Zobacz, czego potrzebujesz, żeby zacząć – a z formalnościami pomożemy.",
    "en": "Drive for Uber, Bolt, FreeNow and iTaxi in your own car. See what you need to get started – we'll help with the paperwork."
  },
  {
    "key": "ui_own_48_l",
    "section": "common",
    "uk": "від відмітки TAXI до старту",
    "ru": "от отметки TAXI до старта",
    "pl": "od wpisu TAXI do startu",
    "en": "from TAXI entry to start"
  },
  {
    "key": "ui_pr0_star",
    "section": "common",
    "uk": "витрат на старт*",
    "ru": "расходов на старт*",
    "pl": "wydatków na start*",
    "en": "start-up costs*"
  },
  {
    "key": "ui_pr_note",
    "section": "common",
    "uk": "* платиш лише за додатковий техогляд авто (бл. 43 zł)",
    "ru": "* платишь только за дополнительный техосмотр авто (ок. 43 zł)",
    "pl": "* płacisz tylko dodatkowe badanie techniczne auta (ok. 43 zł)",
    "en": "* you only pay for the additional vehicle inspection (approx. 43 zł)"
  },
  {
    "key": "ui_see4",
    "section": "common",
    "uk": "Дивись 4 кроки",
    "ru": "Смотри 4 шага",
    "pl": "Zobacz 4 kroki",
    "en": "See the 4 steps"
  },
  {
    "key": "ui_report_car",
    "section": "common",
    "uk": "Додай своє авто",
    "ru": "Добавь своё авто",
    "pl": "Zgłoś swoje auto",
    "en": "Register your car"
  },
  {
    "key": "ui_doc_h",
    "section": "common",
    "uk": "Техпаспорт",
    "ru": "Техпаспорт",
    "pl": "Dowód rejestracyjny",
    "en": "Registration certificate"
  },
  {
    "key": "ui_doc_your",
    "section": "common",
    "uk": "Твоє авто",
    "ru": "Твоё авто",
    "pl": "Twoje auto",
    "en": "Your car"
  },
  {
    "key": "ui_doc_make",
    "section": "common",
    "uk": "Марка / модель",
    "ru": "Марка / модель",
    "pl": "Marka / model",
    "en": "Make / model"
  },
  {
    "key": "ui_doc_type",
    "section": "common",
    "uk": "Тип авто",
    "ru": "Тип авто",
    "pl": "Rodzaj pojazdu",
    "en": "Vehicle type"
  },
  {
    "key": "ui_doc_type_v",
    "section": "common",
    "uk": "легковий автомобіль",
    "ru": "легковой автомобиль",
    "pl": "samochód osobowy",
    "en": "passenger car"
  },
  {
    "key": "ui_doc_seats",
    "section": "common",
    "uk": "Кількість місць",
    "ru": "Количество мест",
    "pl": "Liczba miejsc",
    "en": "Seats"
  },
  {
    "key": "ui_doc_ann",
    "section": "common",
    "uk": "Службові відмітки",
    "ru": "Служебные отметки",
    "pl": "Adnotacje urzędowe",
    "en": "Official notes"
  },
  {
    "key": "ui_a_tape_own",
    "section": "common",
    "uk": "Що ти отримуєш у SOBI",
    "ru": "Что ты получаешь в SOBI",
    "pl": "Co dostajesz w SOBI",
    "en": "What you get with SOBI"
  },
  {
    "key": "ui_steps_k",
    "section": "common",
    "uk": "Крок за кроком",
    "ru": "Шаг за шагом",
    "pl": "Krok po kroku",
    "en": "Step by step"
  },
  {
    "key": "ui_steps_h",
    "section": "common",
    "uk": "4 кроки до першої поїздки на власному авто",
    "ru": "4 шага до первой поездки на своём авто",
    "pl": "4 kroki do pierwszego kursu na własnym aucie",
    "en": "4 steps to your first ride in your own car"
  },
  {
    "key": "ui_steps_p",
    "section": "common",
    "uk": "Документи водія такі самі, як і при оренді. Різниця стосується лише авто.",
    "ru": "Документы водителя такие же, как при аренде. Разница касается только авто.",
    "pl": "Dokumenty kierowcy są takie same jak przy wynajmie. Różnica dotyczy tylko samochodu.",
    "en": "Driver documents are the same as when renting. Only the car part is different."
  },
  {
    "key": "ui_of4",
    "section": "common",
    "uk": "з 4 кроків",
    "ru": "из 4 шагов",
    "pl": "z 4 kroków",
    "en": "of 4 steps"
  },
  {
    "key": "ui_s1h",
    "section": "common",
    "uk": "Перевір, чи підходить твоє авто для застосунків",
    "ru": "Проверь, подходит ли твоё авто для приложений",
    "pl": "Sprawdź, czy Twoje auto kwalifikuje się do aplikacji",
    "en": "Check if your car qualifies for the apps"
  },
  {
    "key": "ui_s1p",
    "section": "common",
    "uk": "Кожен застосунок має власний список моделей і обмеження за віком авто – це залежить і від категорії поїздок (напр. Comfort, XL). Базові вимоги Uber:",
    "ru": "У каждого приложения свой список моделей и ограничение по возрасту авто – это зависит и от категории поездок (напр. Comfort, XL). Базовые требования Uber:",
    "pl": "Każda aplikacja ma własną listę modeli i limit wieku auta – zależy też od kategorii przejazdów (np. Comfort, XL). Podstawowe wymagania Ubera:",
    "en": "Each app has its own list of models and an age limit for cars – it also depends on the ride category (e.g. Comfort, XL). Uber's basic requirements:"
  },
  {
    "key": "ui_rq1",
    "section": "common",
    "uk": "4 або 5 дверей",
    "ru": "4 или 5 дверей",
    "pl": "4 lub 5 drzwi",
    "en": "4 or 5 doors"
  },
  {
    "key": "ui_rq2",
    "section": "common",
    "uk": "мін. 5 місць у техпаспорті",
    "ru": "мин. 5 мест в техпаспорте",
    "pl": "min. 5 miejsc w dowodzie",
    "en": "at least 5 seats in registration"
  },
  {
    "key": "ui_rq3",
    "section": "common",
    "uk": "кермо зліва",
    "ru": "руль слева",
    "pl": "kierownica po lewej stronie",
    "en": "left-hand drive"
  },
  {
    "key": "ui_rq4",
    "section": "common",
    "uk": "реєстрація в ЄС",
    "ru": "регистрация в ЕС",
    "pl": "rejestracja w UE",
    "en": "registered in the EU"
  },
  {
    "key": "ui_rq5",
    "section": "common",
    "uk": "чинна страховка OC і техогляд",
    "ru": "действующая страховка OC и техосмотр",
    "pl": "ważne OC i przegląd",
    "en": "valid OC insurance and inspection"
  },
  {
    "key": "ui_lk1",
    "section": "common",
    "uk": "Вимоги до авто",
    "ru": "Требования к авто",
    "pl": "Wymagania dotyczące pojazdu",
    "en": "Vehicle requirements"
  },
  {
    "key": "ui_lk2",
    "section": "common",
    "uk": "Список авто, що відповідають вимогам",
    "ru": "Список подходящих авто",
    "pl": "Lista pojazdów spełniających wymagania",
    "en": "List of eligible vehicles"
  },
  {
    "key": "ui_lk3",
    "section": "common",
    "uk": "Категорії поїздок і вимоги до авто",
    "ru": "Категории поездок и требования к авто",
    "pl": "Kategorie przejazdów i wymagania dla aut",
    "en": "Ride categories and car requirements"
  },
  {
    "key": "ui_lk4",
    "section": "common",
    "uk": "Список моделей – категорія Comfort",
    "ru": "Список моделей – категория Comfort",
    "pl": "Lista modeli – kategoria Comfort",
    "en": "Model list – Comfort category"
  },
  {
    "key": "ui_s2h",
    "section": "common",
    "uk": "Внеси відмітку TAXI в техпаспорт",
    "ru": "Внеси отметку TAXI в техпаспорт",
    "pl": "Wbij TAXI do dowodu rejestracyjnego",
    "en": "Get TAXI entered in your registration"
  },
  {
    "key": "ui_s2p",
    "section": "common",
    "uk": "Авто, яким ти возиш пасажирів із застосунків, повинно мати в техпаспорті відмітку TAXI.",
    "ru": "Авто, на котором ты возишь пассажиров из приложений, должно иметь в техпаспорте отметку TAXI.",
    "pl": "Auto, którym wozisz pasażerów z aplikacji, musi mieć w dowodzie rejestracyjnym adnotację TAXI.",
    "en": "The car you use for app passengers must have a TAXI entry in its registration certificate."
  },
  {
    "key": "ui_s2a_h",
    "section": "common",
    "uk": "Додатковий техогляд",
    "ru": "Дополнительный техосмотр",
    "pl": "Dodatkowe badanie techniczne",
    "en": "Additional technical inspection"
  },
  {
    "key": "ui_s2a_1",
    "section": "common",
    "uk": "На станції техогляду – офіційна плата",
    "ru": "На станции техосмотра – официальная плата",
    "pl": "Na stacji kontroli pojazdów – opłata ustawowa",
    "en": "At a vehicle inspection station – statutory fee of"
  },
  {
    "key": "ui_s2a_b",
    "section": "common",
    "uk": "бл. 43 zł",
    "ru": "ок. 43 zł",
    "pl": "ok. 43 zł",
    "en": "approx. 43 zł"
  },
  {
    "key": "ui_s2a_2",
    "section": "common",
    "uk": ". Отримуєш довідку зі станції.",
    "ru": ". Получаешь справку со станции.",
    "pl": ". Dostajesz zaświadczenie ze stacji.",
    "en": ". You get a certificate from the station."
  },
  {
    "key": "ui_s2b_h",
    "section": "common",
    "uk": "Відділ транспорту",
    "ru": "Отдел транспорта",
    "pl": "Wydział komunikacji",
    "en": "Vehicle registration office"
  },
  {
    "key": "ui_s2b_1",
    "section": "common",
    "uk": "З довідкою йдеш до управи, де зареєстроване авто. Працівник вносить у техпаспорт",
    "ru": "Со справкой идёшь в учреждение, где зарегистрировано авто. Сотрудник вносит в техпаспорт",
    "pl": "Z zaświadczeniem idziesz do urzędu, w którym auto jest zarejestrowane. Urzędnik wbija do dowodu",
    "en": "Take the certificate to the office where the car is registered. The clerk adds"
  },
  {
    "key": "ui_s2b_b",
    "section": "common",
    "uk": "відмітку TAXI",
    "ru": "отметку TAXI",
    "pl": "adnotację TAXI",
    "en": "the TAXI entry"
  },
  {
    "key": "ui_s2_note",
    "section": "common",
    "uk": "Потрібні документи можуть відрізнятися залежно від управи – дзвони, підкажемо.",
    "ru": "Нужные документы могут отличаться в зависимости от учреждения – звони, подскажем.",
    "pl": "Wymagane dokumenty mogą się różnić w zależności od urzędu – zadzwoń, podpowiemy.",
    "en": "Required documents may vary by office – call us and we'll advise."
  },
  {
    "key": "ui_s3h",
    "section": "common",
    "uk": "Маркування TAXI – допоможемо",
    "ru": "Маркировка TAXI – поможем",
    "pl": "Oznakowanie TAXI – pomożemy",
    "en": "TAXI markings – we'll help"
  },
  {
    "key": "ui_s3p",
    "section": "common",
    "uk": "Авто потрібні лампа TAXI та маркування, яке вимагає твоє місто, – застосунки перевіряють їх на фото авто.",
    "ru": "Авто нужны лампа TAXI и маркировка, которую требует твой город, – приложения проверяют их на фото авто.",
    "pl": "Auto potrzebuje lampy TAXI i oznakowania wymaganego w Twoim mieście – aplikacje sprawdzają je na zdjęciach auta.",
    "en": "The car needs a TAXI roof light and the markings your town requires – the apps check them on photos of the car."
  },
  {
    "key": "ui_help_b",
    "section": "common",
    "uk": "Допомагаємо зробити маркування",
    "ru": "Помогаем сделать маркировку",
    "pl": "Pomagamy zrobić oznakowanie",
    "en": "We help you get the markings done"
  },
  {
    "key": "ui_help_s",
    "section": "common",
    "uk": "Не треба нічого шукати самому – зробимо це разом.",
    "ru": "Не нужно ничего искать самому – сделаем это вместе.",
    "pl": "Nie musisz niczego szukać sam – zrobimy to razem.",
    "en": "No need to sort it out alone – we'll do it together."
  },
  {
    "key": "ui_s4h",
    "section": "common",
    "uk": "SOBI підключає авто до застосунків",
    "ru": "SOBI подключает авто к приложениям",
    "pl": "SOBI podłącza auto do aplikacji",
    "en": "SOBI connects your car to the apps"
  },
  {
    "key": "ui_s4p",
    "section": "common",
    "uk": "Надсилаєш нам фото техпаспорта з відміткою TAXI. Ми оформлюємо виписки з ліцензії для твого авто – на 7 міст і гмін – і додаємо авто в застосунки. Починаєш протягом 48 годин, без витрат на старт.",
    "ru": "Присылаешь нам фото техпаспорта с отметкой TAXI. Мы оформляем выписки из лицензии для твоего авто – на 7 городов и гмин – и добавляем авто в приложения. Начинаешь в течение 48 часов, без расходов на старт.",
    "pl": "Przesyłasz nam zdjęcie dowodu z wpisem TAXI. Występujemy o wypisy z licencji dla Twojego auta – na 7 miast i gmin – i dodajemy auto w aplikacjach. Zaczynasz w ciągu 48 godzin, bez wydatków na start.",
    "en": "Send us a photo of your registration with the TAXI entry. We apply for licence extracts for your car – covering 7 towns – and add the car to the apps. You start within 48 hours, with no start-up costs."
  },
  {
    "key": "ui_benefit_k",
    "section": "common",
    "uk": "Перевага SOBI",
    "ru": "Преимущество SOBI",
    "pl": "Benefit SOBI",
    "en": "SOBI benefit"
  },
  {
    "key": "ui_own_lic_p",
    "section": "common",
    "uk": "Твоє авто отримує виписки з ліцензії не лише на Гданськ, Гдиню і Сопот, а й на Румію, Реду, Косаково та Прушч-Гданський. Їздиш по всьому Труймісту й околицях.",
    "ru": "Твоё авто получает выписки из лицензии не только на Гданьск, Гдыню и Сопот, но и на Румию, Реду, Косаково и Прущ-Гданьский. Ездишь по всему Труймясту и окрестностям.",
    "pl": "Twoje auto dostaje wypisy z licencji nie tylko na Gdańsk, Gdynię i Sopot, ale też na Rumię, Redę, Kosakowo i Pruszcz Gdański. Jeździsz w całym Trójmieście i okolicy.",
    "en": "Your car gets licence extracts not only for Gdańsk, Gdynia and Sopot, but also for Rumia, Reda, Kosakowo and Pruszcz Gdański. You drive across the whole Tri-City area."
  },
  {
    "key": "ui_drv_k",
    "section": "common",
    "uk": "Водій",
    "ru": "Водитель",
    "pl": "Kierowca",
    "en": "Driver"
  },
  {
    "key": "ui_drv_h",
    "section": "common",
    "uk": "Документи водія",
    "ru": "Документы водителя",
    "pl": "Dokumenty kierowcy",
    "en": "Driver documents"
  },
  {
    "key": "ui_same",
    "section": "common",
    "uk": "Такі самі, як при оренді авто",
    "ru": "Такие же, как при аренде авто",
    "pl": "Takie same jak przy wynajmie auta",
    "en": "Same as when renting a car"
  },
  {
    "key": "ui_ck_k",
    "section": "common",
    "uk": "Чек-лист",
    "ru": "Чек-лист",
    "pl": "Lista kontrolna",
    "en": "Checklist"
  },
  {
    "key": "ui_ck_h",
    "section": "common",
    "uk": "Перевір, чи ти готовий",
    "ru": "Проверь, готов ли ты",
    "pl": "Sprawdź, czy jesteś gotowy",
    "en": "Check if you're ready"
  },
  {
    "key": "ui_ck_p",
    "section": "common",
    "uk": "Познач, що в тебе вже є, – побачиш, скільки лишилося до старту.",
    "ru": "Отметь, что у тебя уже есть, – увидишь, сколько осталось до старта.",
    "pl": "Zaznacz, co już masz – zobaczysz, ile zostało do startu.",
    "en": "Tick what you already have – you'll see how close you are to starting."
  },
  {
    "key": "ui_ck_note",
    "section": "common",
    "uk": "Маркування TAXI зробимо разом із тобою",
    "ru": "Маркировку TAXI сделаем вместе с тобой",
    "pl": "Oznakowanie TAXI zrobimy razem z Tobą",
    "en": "We'll do the TAXI markings together with you"
  },
  {
    "key": "ui_readiness",
    "section": "common",
    "uk": "готовності",
    "ru": "готовности",
    "pl": "gotowości",
    "en": "ready"
  },
  {
    "key": "ui_band_h",
    "section": "common",
    "uk": "Скільки заробиш на своєму авто?",
    "ru": "Сколько заработаешь на своём авто?",
    "pl": "Ile zarobisz na swoim aucie?",
    "en": "How much will you earn in your own car?"
  },
  {
    "key": "ui_faq_k",
    "section": "common",
    "uk": "Питання",
    "ru": "Вопросы",
    "pl": "Pytania",
    "en": "Questions"
  },
  {
    "key": "ui_faq_h",
    "section": "common",
    "uk": "Часті питання",
    "ru": "Частые вопросы",
    "pl": "Najczęstsze pytania",
    "en": "Frequently asked questions"
  },
  {
    "key": "ui_form_k",
    "section": "common",
    "uk": "Заявка",
    "ru": "Заявка",
    "pl": "Zgłoszenie",
    "en": "Application"
  },
  {
    "key": "ui_form_p",
    "section": "common",
    "uk": "Передзвонимо, перевіримо твоє авто й скажемо, чого ще бракує.",
    "ru": "Перезвоним, проверим твоё авто и скажем, чего ещё не хватает.",
    "pl": "Oddzwonimy, sprawdzimy Twoje auto i powiemy, czego jeszcze brakuje.",
    "en": "We'll call you back, check your car and tell you what's still missing."
  },
  {
    "key": "ui_form_t",
    "section": "common",
    "uk": "Твої дані та авто",
    "ru": "Твои данные и авто",
    "pl": "Twoje dane i auto",
    "en": "Your details and car"
  },
  {
    "key": "ui_f_car",
    "section": "common",
    "uk": "Марка й модель авто",
    "ru": "Марка и модель авто",
    "pl": "Marka i model auta",
    "en": "Car make and model"
  },
  {
    "key": "ui_f_year",
    "section": "common",
    "uk": "Рік випуску",
    "ru": "Год выпуска",
    "pl": "Rok produkcji",
    "en": "Year of manufacture"
  },
  {
    "key": "ui_f_taxi",
    "section": "common",
    "uk": "Чи є вже в техпаспорті відмітка TAXI?",
    "ru": "Есть ли уже в техпаспорте отметка TAXI?",
    "pl": "Czy auto ma już wpis TAXI w dowodzie?",
    "en": "Does the car already have a TAXI entry?"
  },
  {
    "key": "ui_t_shop2",
    "section": "common",
    "uk": "Майстерня зі знижками",
    "ru": "Автосервис со скидками",
    "pl": "Warsztat ze zniżkami",
    "en": "Discounted workshop"
  },
  {
    "key": "ui_t_help",
    "section": "common",
    "uk": "Допомога з формальностями",
    "ru": "Помощь с формальностями",
    "pl": "Pomoc w formalnościach",
    "en": "Help with paperwork"
  },
  {
    "key": "ui_d1",
    "section": "common",
    "uk": "Мені вже є 18 років",
    "ru": "Мне уже есть 18 лет",
    "pl": "Mam ukończone 18 lat",
    "en": "I'm at least 18"
  },
  {
    "key": "ui_d2",
    "section": "common",
    "uk": "Маю польські водійські права",
    "ru": "У меня есть польские права",
    "pl": "Mam polskie prawo jazdy",
    "en": "I have a Polish driving licence"
  },
  {
    "key": "ui_d3",
    "section": "common",
    "uk": "Маю довідку про несудимість (дійсна 30 днів)",
    "ru": "У меня есть справка о несудимости (действительна 30 дней)",
    "pl": "Mam zaświadczenie o niekaralności (ważne 30 dni)",
    "en": "I have a no-criminal-record certificate (valid 30 days)"
  },
  {
    "key": "ui_d4",
    "section": "common",
    "uk": "Маю медичну та психологічну довідку",
    "ru": "У меня есть медицинское и психологическое заключение",
    "pl": "Mam orzeczenie lekarskie i psychologiczne",
    "en": "I have medical and psychological certificates"
  },
  {
    "key": "ui_c1",
    "section": "common",
    "uk": "Моє авто є в списку застосунків",
    "ru": "Моё авто есть в списке приложений",
    "pl": "Moje auto jest na liście aplikacji",
    "en": "My car is on the apps' list"
  },
  {
    "key": "ui_c2",
    "section": "common",
    "uk": "Маю відмітку TAXI в техпаспорті",
    "ru": "Есть отметка TAXI в техпаспорте",
    "pl": "Mam adnotację TAXI w dowodzie",
    "en": "I have the TAXI entry in my registration"
  },
  {
    "key": "ui_c3",
    "section": "common",
    "uk": "Маю чинну страховку OC і техогляд",
    "ru": "Есть действующая страховка OC и техосмотр",
    "pl": "Mam ważne OC i przegląd",
    "en": "I have valid OC insurance and inspection"
  },
  {
    "key": "ui_rd_all_t",
    "section": "common",
    "uk": "Усе готово!",
    "ru": "Всё готово!",
    "pl": "Wszystko gotowe!",
    "en": "All set!"
  },
  {
    "key": "ui_rd_all_p",
    "section": "common",
    "uk": "Надішли заявку – підключимо твоє авто до застосунків.",
    "ru": "Отправь заявку – подключим твоё авто к приложениям.",
    "pl": "Wyślij zgłoszenie – podłączymy Twoje auto do aplikacji.",
    "en": "Send your application – we'll connect your car to the apps."
  },
  {
    "key": "ui_rd_most_t",
    "section": "common",
    "uk": "Майже готово!",
    "ru": "Почти готово!",
    "pl": "Już prawie!",
    "en": "Almost there!"
  },
  {
    "key": "ui_rd_most_p",
    "section": "common",
    "uk": "Бракує ще {n} з {t} – з рештою допоможемо.",
    "ru": "Не хватает ещё {n} из {t} – с остальным поможем.",
    "pl": "Brakuje jeszcze {n} z {t} – z resztą pomożemy.",
    "en": "{n} of {t} still missing – we'll help with the rest."
  },
  {
    "key": "ui_rd_some_t",
    "section": "common",
    "uk": "Гарний початок",
    "ru": "Хорошее начало",
    "pl": "Dobry początek",
    "en": "Good start"
  },
  {
    "key": "ui_rd_some_p",
    "section": "common",
    "uk": "Бракує ще {n} з {t}. Пройди кроки вище або подзвони.",
    "ru": "Не хватает ещё {n} из {t}. Пройди шаги выше или позвони.",
    "pl": "Brakuje jeszcze {n} z {t}. Przejdź kroki powyżej albo zadzwoń.",
    "en": "{n} of {t} still missing. Follow the steps above or give us a call."
  },
  {
    "key": "ui_rd_none_t",
    "section": "common",
    "uk": "Познач, що вже маєш",
    "ru": "Отметь, что уже есть",
    "pl": "Zaznacz, co już masz",
    "en": "Tick what you have"
  },
  {
    "key": "ui_rd_none_p",
    "section": "common",
    "uk": "Кожен пункт наближає тебе до першої поїздки.",
    "ru": "Каждый пункт приближает тебя к первой поездке.",
    "pl": "Każdy punkt przybliża Cię do pierwszego kursu.",
    "en": "Every item brings you closer to your first ride."
  },
  {
    "key": "ui_q1",
    "section": "common",
    "uk": "Чи потрібна мені власна ліцензія таксі?",
    "ru": "Нужна ли мне своя лицензия такси?",
    "pl": "Czy potrzebuję własnej licencji taxi?",
    "en": "Do I need my own taxi licence?"
  },
  {
    "key": "ui_a1",
    "section": "common",
    "uk": "Ні. Ти їздиш у межах ліцензії SOBI – це ми оформлюємо виписки з ліцензії для твого авто.",
    "ru": "Нет. Ты ездишь в рамках лицензии SOBI – это мы оформляем выписки из лицензии для твоего авто.",
    "pl": "Nie. Jeździsz w ramach licencji SOBI – to my występujemy o wypisy z licencji dla Twojego auta.",
    "en": "No. You drive under SOBI's licence – we apply for the licence extracts for your car."
  },
  {
    "key": "ui_q2",
    "section": "common",
    "uk": "У яких містах я можу їздити?",
    "ru": "В каких городах я могу ездить?",
    "pl": "W jakich miastach mogę jeździć?",
    "en": "Which towns can I drive in?"
  },
  {
    "key": "ui_a2",
    "section": "common",
    "uk": "Маємо виписки на 7 міст і гмін: Гданськ, Гдиня, Сопот, Румія, Реда, Косаково та Прушч-Гданський.",
    "ru": "У нас есть выписки на 7 городов и гмин: Гданьск, Гдыня, Сопот, Румия, Реда, Косаково и Прущ-Гданьский.",
    "pl": "Mamy wypisy na 7 miast i gmin: Gdańsk, Gdynię, Sopot, Rumię, Redę, Kosakowo i Pruszcz Gdański.",
    "en": "We hold extracts for 7 towns and municipalities: Gdańsk, Gdynia, Sopot, Rumia, Reda, Kosakowo and Pruszcz Gdański."
  },
  {
    "key": "ui_q3",
    "section": "common",
    "uk": "Скільки коштує внести відмітку TAXI в техпаспорт?",
    "ru": "Сколько стоит внести отметку TAXI в техпаспорт?",
    "pl": "Ile kosztuje wbicie TAXI do dowodu?",
    "en": "How much does the TAXI entry cost?"
  },
  {
    "key": "ui_a3",
    "section": "common",
    "uk": "Додатковий техогляд на станції техогляду коштує бл. 43 zł (офіційна плата) – це єдина витрата на старт. З маркуванням авто допомагаємо.",
    "ru": "Дополнительный техосмотр на станции техосмотра стоит ок. 43 zł (официальная плата) – это единственный расход на старт. С маркировкой авто помогаем.",
    "pl": "Dodatkowe badanie techniczne na stacji kontroli pojazdów kosztuje ok. 43 zł (opłata ustawowa) – to jedyny wydatek na start. Z oznakowaniem auta pomagamy.",
    "en": "The additional inspection at a vehicle inspection station costs approx. 43 zł (statutory fee) – that's the only start-up cost. We help with the car markings."
  },
  {
    "key": "ui_q4",
    "section": "common",
    "uk": "Як швидко я можу почати?",
    "ru": "Как быстро я могу начать?",
    "pl": "Jak szybko mogę zacząć?",
    "en": "How soon can I start?"
  },
  {
    "key": "ui_a4",
    "section": "common",
    "uk": "Протягом 48 годин після внесення відмітки TAXI. Управа видає виписку з ліцензії протягом 30 днів, але чекати не треба – до того часу їздиш на підставі поданої заяви.",
    "ru": "В течение 48 часов после внесения отметки TAXI. Учреждение выдаёт выписку из лицензии в течение 30 дней, но ждать не нужно – до этого ездишь на основании поданного заявления.",
    "pl": "W ciągu 48 godzin od zrobienia wpisu TAXI. Urząd wydaje wypis z licencji w ciągu 30 dni, ale nie musisz czekać – do tego czasu jeździsz na podstawie złożonego wniosku.",
    "en": "Within 48 hours of getting the TAXI entry. The office issues the licence extract within 30 days, but you don't have to wait – until then you drive based on the submitted application."
  },
  {
    "key": "ui_q5",
    "section": "common",
    "uk": "Мого авто немає в списку застосунків – що робити?",
    "ru": "Моего авто нет в списке приложений – что делать?",
    "pl": "Moje auto nie jest na liście aplikacji – co teraz?",
    "en": "My car isn't on the apps' list – what now?"
  },
  {
    "key": "ui_a5",
    "section": "common",
    "uk": "Можеш орендувати авто з нашого автопарку. Подзвони – підберемо авто під твій режим роботи.",
    "ru": "Можешь арендовать авто из нашего автопарка. Позвони – подберём авто под твой режим работы.",
    "pl": "Możesz wynająć auto z naszej floty. Zadzwoń – dobierzemy samochód do Twojego trybu pracy.",
    "en": "You can rent a car from our fleet. Give us a call – we'll match a car to the way you work."
  },
  {
    "key": "ui_opt_yes",
    "section": "common",
    "uk": "Так",
    "ru": "Да",
    "pl": "Tak",
    "en": "Yes"
  },
  {
    "key": "ui_opt_notyet",
    "section": "common",
    "uk": "Ще ні",
    "ru": "Ещё нет",
    "pl": "Jeszcze nie",
    "en": "Not yet"
  },
  {
    "key": "ui_opt_dk",
    "section": "common",
    "uk": "Не знаю",
    "ru": "Не знаю",
    "pl": "Nie wiem",
    "en": "Not sure"
  },
  {
    "key": "ui_ph_photo",
    "section": "common",
    "uk": "Фото незабаром",
    "ru": "Фото скоро",
    "pl": "Zdjęcie wkrótce",
    "en": "Photo coming soon"
  },
  {
    "key": "ui_err_city",
    "section": "common",
    "uk": "Обери місто",
    "ru": "Выбери город",
    "pl": "Wybierz miasto",
    "en": "Choose a city"
  },
  {
    "key": "ui_err_taxi",
    "section": "common",
    "uk": "Обери одну відповідь",
    "ru": "Выбери один ответ",
    "pl": "Zaznacz jedną odpowiedź",
    "en": "Pick one answer"
  },
  {
    "key": "ui_sending",
    "section": "common",
    "uk": "Надсилаємо…",
    "ru": "Отправляем…",
    "pl": "Wysyłanie…",
    "en": "Sending…"
  },
  {
    "key": "ui_interest_car",
    "section": "common",
    "uk": "Мене цікавить авто:",
    "ru": "Меня интересует авто:",
    "pl": "Interesuje mnie auto:",
    "en": "I'm interested in:"
  }
]

async function importAllTranslations() {
  const axios = require('axios');
  const HOST = process.env.STRAPI_HOST;
  const PORT = process.env.STRAPI_PORT;
  const API_URL = `http://${HOST}:${PORT}/api/translations`;

  try {
    console.log(`📚 Starting unified import of ${allTranslations.length} translations...`);
    console.log('━'.repeat(60));

    let created = 0;
    let updated = 0;
    let errors = 0;

    for (const translation of allTranslations) {
      try {
        // Map sections that don't exist in Strapi to allowed ones
        const sectionMapping = {
          'fleet': 'common',
          'form': 'common',
          'privacy-policy': 'common',
          'navigation': 'common',
          'hero': 'common',
          'benefits': 'common',
          'requirements': 'common',
          'cta': 'common',
          'contact': 'common',
          'footer': 'common',
          'header': 'common',
          'apps': 'common',
          'legal': 'common'
        };

        const mappedTranslation = {
          ...translation,
          section: sectionMapping[translation.section] || translation.section
        };

        // Check if translation with this key already exists
        const checkResponse = await axios.get(API_URL, {
          params: { 'filters[key][$eq]': translation.key }
        });

        if (checkResponse.data.data && checkResponse.data.data.length > 0) {
          // Update existing translation
          const existingId = checkResponse.data.data[0].documentId || checkResponse.data.data[0].id;
          await axios.put(`${API_URL}/${existingId}`, {
            data: mappedTranslation
          });

          console.log(`✅ Updated: ${translation.key}`);
          updated++;
        } else {
          // Create new translation
          await axios.post(API_URL, {
            data: mappedTranslation
          });

          console.log(`✅ Created: ${translation.key}`);
          created++;
        }

        // Small delay to avoid overwhelming the API
        await new Promise(resolve => setTimeout(resolve, 50));

      } catch (error) {
        console.error(`❌ Error processing ${translation.key}:`, error.response?.data?.error?.message || error.message);
        errors++;
      }
    }

    console.log('━'.repeat(60));
    console.log(`\n🎉 Import completed!`);
    console.log(`📊 Results: ${created} created, ${updated} updated, ${errors} errors`);
    console.log('\n📝 Note: You may need to publish the translations in Strapi admin panel if draft mode is enabled.');

  } catch (error) {
    console.error('❌ Import failed:', error);
    process.exit(1);
  }
}

// Check if Strapi is running
async function checkStrapiHealth() {
  const axios = require('axios');
  const HOST = process.env.STRAPI_HOST;
  const PORT = process.env.STRAPI_PORT;

  try {
    const response = await axios.get(`http://${HOST}:${PORT}/api/translations`);
    return response.status === 200;
  } catch {
    return false;
  }
}

// Main execution
async function main() {
  console.log('🔍 Checking if Strapi is running...');

  const isRunning = await checkStrapiHealth();

  if (!isRunning) {
    console.error('❌ Strapi is not running. Please start Strapi first with:');
    console.error('   Development: make dev');
    console.error('   Production: make prod');
    console.error('   Or: npm run develop');
    process.exit(1);
  }

  console.log('✅ Strapi is running. Starting unified import...');
  await importAllTranslations();
}

main();